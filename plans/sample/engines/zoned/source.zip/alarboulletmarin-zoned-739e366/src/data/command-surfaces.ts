// src/data/command-surfaces.ts
// Static registry of navigable product surfaces (tools, guides, pages) surfaced
// in the Command Palette. Each entry is a directly-navigable destination, no
// heuristics. Titles/subtitles are stored inline FR/EN (same pattern as
// CALCULATEURS and collections data) so this module stays light and free of
// page-component imports.
//
// Le français est au tutoiement ici comme partout ailleurs : ce fichier était
// au vouvoiement et a été basculé entièrement, en une fois, comme le veut la
// règle du dépôt. Ne pas remélanger les deux.

import { normalizeSearch } from "@/lib/search-utils";

export type SurfaceSection = "calculator" | "guide" | "page";

export interface CommandSurface {
  id: string;
  section: SurfaceSection;
  title: string;
  titleEn: string;
  subtitle: string;
  subtitleEn: string;
  url: string;
  /** FR + EN terms so users can type a product need (e.g. "nutrition", "trail"). */
  keywords: string[];
  /** Surfaced in the empty-state "quick access" list. */
  featured?: boolean;
}

export const COMMAND_SURFACES: CommandSurface[] = [
  // --- Calculateurs (titles mirror CALCULATEURS in CalculateursPage) ---
  {
    id: "calculators",
    section: "calculator",
    title: "Calculateurs",
    titleEn: "Calculators",
    subtitle: "Tous les outils de calcul et de conversion",
    subtitleEn: "All calculation and conversion tools",
    url: "/calculators",
    keywords: ["calculateur", "calculator", "outils", "tools", "convertir", "convert"],
    featured: true,
  },
  {
    id: "calc-zones",
    section: "calculator",
    title: "Zones d'entraînement",
    titleEn: "Training Zones",
    subtitle: "Pose tes zones FC et tes allures depuis ta VMA ou ta FCmax",
    subtitleEn: "Calculate your HR and pace zones from VMA or max HR",
    url: "/calculators/zones",
    keywords: ["zones", "fc", "fcmax", "vma", "heart rate", "frequence cardiaque", "allures"],
  },
  {
    id: "calc-vma",
    section: "calculator",
    title: "VMA depuis un chrono",
    titleEn: "VMA from Race Time",
    subtitle: "Estime ta VMA à partir d'un résultat de course",
    subtitleEn: "Estimate your VMA from a race result",
    url: "/calculators/vma",
    keywords: ["vma", "vo2max", "vitesse maximale aerobie", "chrono", "race time"],
  },
  {
    id: "calc-ftp",
    section: "calculator",
    title: "Test FTP vélo",
    titleEn: "FTP Cycling Test",
    subtitle: "Estime ta FTP depuis un test 20 minutes ou un ramp test",
    subtitleEn: "Estimate your FTP from a 20-minute or ramp test",
    url: "/calculators/ftp",
    keywords: ["ftp", "velo", "cycling", "cyclisme", "watts", "puissance", "power", "ramp test"],
  },
  {
    id: "calc-css",
    section: "calculator",
    title: "Test CSS natation",
    titleEn: "CSS Swimming Test",
    subtitle: "Estime ta CSS depuis un test 400 m + 200 m",
    subtitleEn: "Estimate your CSS from a 400m + 200m test",
    url: "/calculators/css",
    keywords: ["css", "natation", "swimming", "swim", "critical swim speed", "nage"],
  },
  {
    id: "calc-allures",
    section: "calculator",
    title: "Convertisseur d'allures",
    titleEn: "Pace Converter",
    subtitle: "Convertissez entre min/km, km/h et min/mile en temps réel",
    subtitleEn: "Convert between min/km, km/h and min/mile in real time",
    url: "/calculators/convertisseur",
    keywords: ["allure", "pace", "convertisseur", "converter", "min/km", "km/h", "mile"],
  },
  {
    id: "calc-table-allures",
    section: "calculator",
    title: "Table de référence",
    titleEn: "Pace Reference Table",
    subtitle: "Toutes les allures de 3:00 à 10:00/km avec temps estimés",
    subtitleEn: "All paces from 3:00 to 10:00/km with estimated times",
    url: "/calculators/table-allures",
    keywords: ["table", "allures", "pace table", "reference", "temps", "splits"],
  },
  {
    id: "calc-tapis",
    section: "calculator",
    title: "Convertisseur tapis roulant",
    titleEn: "Treadmill Converter",
    subtitle: "Convertissez vitesse et inclinaison en allure équivalente",
    subtitleEn: "Convert speed and incline to equivalent pace",
    url: "/calculators/tapis-roulant",
    keywords: ["tapis", "treadmill", "inclinaison", "incline", "vitesse", "indoor"],
  },
  {
    id: "calc-splits",
    section: "calculator",
    title: "Générateur de splits",
    titleEn: "Split Generator",
    subtitle: "Planifie tes passages pour tenir ton objectif chrono",
    subtitleEn: "Plan your splits to reach your target time",
    url: "/calculators/splits",
    keywords: ["splits", "passages", "objectif", "chrono", "negative split", "pacing"],
  },
  {
    id: "calc-equivalence",
    section: "calculator",
    title: "Équivalence entre distances",
    titleEn: "Race Equivalence",
    subtitle: "Prédis tes temps sur toutes les distances depuis un résultat",
    subtitleEn: "Predict your times across all distances from one result",
    url: "/calculators/equivalence",
    keywords: ["equivalence", "prediction", "distances", "5k", "10k", "semi", "marathon", "predict"],
  },
  {
    id: "calc-race-simulator",
    section: "calculator",
    title: "Simulateur jour de course",
    titleEn: "Race Day Simulator",
    subtitle: "Plan complet jour de course : horaires, allures, nutrition, mental",
    subtitleEn: "Complete race day plan: schedule, pacing, nutrition, mental cues",
    url: "/race-simulator",
    keywords: ["course", "race", "simulateur", "simulator", "objectif", "chrono", "pacing", "negative split", "jour j"],
    featured: true,
  },

  // --- Guides ---
  {
    id: "guides",
    section: "guide",
    title: "Guides",
    titleEn: "Guides",
    subtitle: "Guides pratiques : nutrition, préparation course, échauffement",
    subtitleEn: "Practical guides: nutrition, race prep, warmup",
    url: "/guides",
    keywords: ["guide", "guides", "pratique", "how to", "tutoriel"],
    featured: true,
  },
  {
    id: "guide-nutrition",
    section: "guide",
    title: "Guide nutrition",
    titleEn: "Nutrition Guide",
    subtitle: "Alimentation, hydratation et ravitaillement en course",
    subtitleEn: "Fueling, hydration and race-day nutrition",
    url: "/guides/nutrition",
    keywords: ["nutrition", "alimentation", "hydratation", "glucides", "ravitaillement", "carbs", "fueling", "gels"],
  },
  {
    id: "guide-race-prep",
    section: "guide",
    title: "Guide préparation course",
    titleEn: "Race Prep Guide",
    subtitle: "Checklist, stratégie et récupération autour de la course",
    subtitleEn: "Checklist, strategy and recovery around race day",
    url: "/guides/race-prep",
    keywords: ["preparation", "course", "race prep", "checklist", "strategie", "taper", "affutage"],
  },
  {
    id: "guide-warmup",
    section: "guide",
    title: "Guide échauffement",
    titleEn: "Warmup Guide",
    subtitle: "Routines d'échauffement et retour au calme",
    subtitleEn: "Warmup routines and cool-down",
    url: "/guides/warmup",
    keywords: ["echauffement", "warmup", "warm up", "retour au calme", "cool down", "mobilite", "etirements"],
  },
  {
    id: "nutrition-hub",
    section: "guide",
    title: "Nutrition",
    titleEn: "Nutrition",
    subtitle: "Tout sur la nutrition du coureur",
    subtitleEn: "Everything about runner nutrition",
    url: "/nutrition",
    keywords: ["nutrition", "alimentation", "hydratation", "glucides", "carbs", "energie"],
  },

  // --- Pages / outils ---
  {
    id: "settings",
    section: "page",
    title: "Paramètres",
    titleEn: "Settings",
    subtitle: "Langue, thème, unités et préférences",
    subtitleEn: "Language, theme, units and preferences",
    url: "/settings",
    keywords: ["parametres", "settings", "preferences", "langue", "language", "theme", "unites", "units", "reglages"],
    featured: true,
  },
  {
    id: "contribute",
    section: "page",
    title: "Contribuer",
    titleEn: "Contribute",
    subtitle: "Propose du contenu, signale un bug, donne ton avis",
    subtitleEn: "Suggest content, report a bug, share feedback",
    url: "/contribute",
    keywords: ["contribuer", "contribute", "github", "feedback", "suggestion", "bug", "avis", "proposer"],
    featured: true,
  },
  {
    id: "plans",
    section: "page",
    title: "Mes plans",
    titleEn: "My Plans",
    subtitle: "Tes plans d'entraînement",
    subtitleEn: "Your personalized training plans",
    url: "/plans",
    keywords: ["plan", "plans", "entrainement", "training", "programme"],
    featured: true,
  },
  {
    id: "plan-new",
    section: "page",
    title: "Créer un plan",
    titleEn: "Create a Plan",
    subtitle: "Démarrez un nouveau plan d'entraînement",
    subtitleEn: "Start a new training plan",
    url: "/plan/new",
    keywords: ["nouveau plan", "creer", "create", "new plan", "assisted", "prebuilt", "generer"],
  },
  {
    id: "plan-methodology",
    section: "page",
    title: "Méthodologie des plans",
    titleEn: "Plan Methodology",
    subtitle: "Comment nos plans d'entraînement sont construits",
    subtitleEn: "How our training plans are built",
    url: "/plans/methodology",
    keywords: ["methodologie", "methodology", "plans", "periodisation", "construction"],
  },
  {
    id: "methodology",
    section: "page",
    title: "Méthodologie",
    titleEn: "Methodology",
    subtitle: "La science derrière Zoned",
    subtitleEn: "The science behind Zoned",
    url: "/methodology",
    keywords: ["methodologie", "methodology", "science", "references", "sources"],
  },
  {
    id: "compare",
    section: "page",
    title: "Comparatifs",
    titleEn: "Compare",
    subtitle: "Compare Zoned aux autres outils d'entraînement",
    subtitleEn: "Compare Zoned to other training tools",
    url: "/compare",
    keywords: ["comparer", "compare", "comparatif", "vs", "alternative", "concurrents"],
  },
  {
    id: "profile",
    section: "page",
    title: "Profil coureur",
    titleEn: "Runner Profile",
    subtitle: "Tes données, ton niveau et tes records",
    subtitleEn: "Your data, levels and personal records",
    url: "/profile",
    keywords: ["profil", "profile", "coureur", "runner", "records", "niveau"],
  },
  {
    id: "favorites",
    section: "page",
    title: "Favoris",
    titleEn: "Favorites",
    subtitle: "Tes séances et tes contenus enregistrés",
    subtitleEn: "Your saved workouts and content",
    url: "/favorites",
    keywords: ["favoris", "favorites", "enregistres", "saved", "bookmarks"],
  },
  {
    id: "quiz",
    section: "page",
    title: "Quiz",
    titleEn: "Quiz",
    subtitle: "Teste tes connaissances en entraînement",
    subtitleEn: "Test your training knowledge",
    url: "/quiz",
    keywords: ["quiz", "test", "connaissances", "questions"],
  },
  {
    id: "changelog",
    section: "page",
    title: "Nouveautés",
    titleEn: "Changelog",
    subtitle: "Les dernières mises à jour de Zoned",
    subtitleEn: "The latest Zoned updates",
    url: "/changelog",
    keywords: ["changelog", "nouveautes", "updates", "releases", "versions", "what's new"],
  },
  {
    id: "about",
    section: "page",
    title: "À propos",
    titleEn: "About",
    subtitle: "En savoir plus sur Zoned",
    subtitleEn: "Learn more about Zoned",
    url: "/about",
    keywords: ["a propos", "about", "zoned", "qui", "projet"],
  },

  // ── Les destinations que les quatre portes ne tiennent plus ──────────
  // Mesuré avant d'écrire ces entrées : le registre couvrait 32 destinations
  // sur ~64 routes, et ces treize-là n'y étaient pas. Reléguer une page hors
  // de la navigation sans l'inscrire ici, c'est la rendre introuvable, donc
  // la supprimer sans le dire. `nav-coverage.test.ts` échoue si ça se
  // reproduit.
  {
    id: "today",
    section: "page",
    title: "Aujourd'hui",
    titleEn: "Today",
    subtitle: "Ta séance du jour, et les deux raccourcis",
    subtitleEn: "Today's session, and the two shortcuts",
    url: "/today",
    keywords: ["aujourd'hui", "today", "accueil", "home", "reprendre", "resume", "cockpit"],
    featured: true,
  },
  {
    id: "library",
    section: "page",
    title: "Bibliothèque",
    titleEn: "Library",
    subtitle: "Toutes les séances, par pratique",
    subtitleEn: "Every session, by discipline",
    url: "/library",
    keywords: ["bibliotheque", "library", "seances", "sessions", "catalogue", "route", "trail", "ultra"],
    featured: true,
  },
  {
    id: "library-draw",
    section: "page",
    title: "Tire-moi une séance",
    titleEn: "Draw me a session",
    subtitle: "Le hasard choisit pour toi",
    subtitleEn: "Let chance pick for you",
    url: "/library/draw",
    keywords: ["tirage", "hasard", "aleatoire", "random", "draw", "surprise", "quiz"],
    featured: true,
  },
  {
    id: "collections",
    section: "page",
    title: "Collections",
    titleEn: "Collections",
    subtitle: "Des séances regroupées par objectif",
    subtitleEn: "Sessions grouped by goal",
    url: "/collections",
    keywords: ["collections", "series", "progressions", "objectif", "goal"],
  },
  {
    id: "weeks",
    section: "page",
    title: "Ma semaine",
    titleEn: "My week",
    subtitle: "Composer une semaine sans s'engager sur un plan",
    subtitleEn: "Build a week without committing to a plan",
    url: "/weeks",
    keywords: ["semaine", "week", "hebdo", "weekly", "composer", "build"],
    featured: true,
  },
  {
    id: "weeks-new",
    section: "page",
    title: "Nouvelle semaine",
    titleEn: "New week",
    subtitle: "Composer ou partir d'une semaine prête",
    subtitleEn: "Compose one, or start from a ready-made week",
    url: "/weeks/new",
    keywords: ["nouvelle semaine", "new week", "creer", "create", "generer", "generate"],
  },
  {
    id: "weeks-prebuilt",
    section: "page",
    title: "Semaines prêtes à l'emploi",
    titleEn: "Ready-made weeks",
    subtitle: "Dix semaines déjà écrites",
    subtitleEn: "Ten weeks already written",
    url: "/weeks/new/prebuilt",
    keywords: ["semaines pretes", "ready weeks", "prebuilt", "catalogue"],
  },
  {
    id: "workout-builder",
    section: "page",
    title: "Créer une séance",
    titleEn: "Build a session",
    subtitle: "Écrire ta propre séance, bloc par bloc",
    subtitleEn: "Write your own session, block by block",
    url: "/workout/builder",
    keywords: ["creer", "build", "editeur", "builder", "personnalisee", "custom"],
  },
  {
    id: "my-zones",
    section: "page",
    title: "Mes zones",
    titleEn: "My zones",
    subtitle: "Tes six zones, depuis ta VMA ou ta FCmax",
    subtitleEn: "Your six zones, from your vVO2max or max HR",
    url: "/my-zones",
    keywords: ["mes zones", "my zones", "vma", "fcmax", "personnalisees", "personal"],
    featured: true,
  },
  {
    id: "learn",
    section: "page",
    title: "Comprendre",
    titleEn: "Learn",
    subtitle: "Les articles de fond",
    subtitleEn: "The long-form articles",
    url: "/learn",
    keywords: ["comprendre", "learn", "articles", "apprendre", "lire", "read"],
  },
  {
    id: "glossary",
    section: "page",
    title: "Lexique",
    titleEn: "Glossary",
    subtitle: "Le vocabulaire de l'entraînement, défini",
    subtitleEn: "Training vocabulary, defined",
    url: "/glossary",
    keywords: ["lexique", "glossaire", "glossary", "definition", "vocabulaire", "terme"],
  },
  {
    id: "calc-converter-alt",
    section: "calculator",
    title: "Calculateur d'allures",
    titleEn: "Pace calculator",
    subtitle: "Tes chronos sur cinq distances, depuis ta VMA",
    subtitleEn: "Your times over five distances, from your vVO2max",
    url: "/calculators/allures",
    keywords: ["allures", "pace", "chrono", "prediction", "vma", "temps"],
  },
  {
    id: "activities",
    section: "page",
    title: "Activités complémentaires",
    titleEn: "Complementary activities",
    subtitle: "Ton vélotaf et tes séances hors plan",
    subtitleEn: "Your bike commutes and off-plan sessions",
    url: "/activities",
    keywords: ["velotaf", "commute", "activite", "activity", "journal", "log", "deplacement", "velo"],
  },
];

/** Surfaces shown in the empty-state quick-access list, in registry order. */
export const FEATURED_SURFACES: CommandSurface[] = COMMAND_SURFACES.filter(
  (s) => s.featured,
);

/**
 * Filter navigable surfaces by query (diacritic-insensitive), matching against
 * title, subtitle and keywords in both languages.
 */
export function searchSurfaces(query: string): CommandSurface[] {
  const q = normalizeSearch(query.trim());
  if (!q) return [];
  return COMMAND_SURFACES.filter((s) => {
    const haystack = normalizeSearch(
      [s.title, s.titleEn, s.subtitle, s.subtitleEn, ...s.keywords].join(" "),
    );
    return haystack.includes(q);
  });
}
