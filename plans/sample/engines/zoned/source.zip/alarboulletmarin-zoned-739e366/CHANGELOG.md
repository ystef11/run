# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-09-19

### Added
- A shared session link shows the session. All 250 `/workout/<id>` URLs served the same card, the library one: sending a 30/30 into a conversation and sending the whole library produced exactly the same preview, with neither the session's name nor what it asks of you. Each session now has its own 1200 × 630 card, its title as the headline, its duration, its dominant zone and its level, drawn in the house style, paper, ink, the ground rule and the two runners. The cards reuse the template of the six section cards through a variant, so the house style stays in one place, and a session's name takes the ink and the room the wordmark takes elsewhere. They are painted at build time by a headless Chrome, never on demand, the app having no server: `generate-route-meta` points a route at its card only when the PNG exists and falls back to the library card otherwise, so adding a session without repainting degrades instead of serving a 404. The 250 files sit outside the service worker's precache, since only the social crawlers read them and precaching them added 16MB to every install

## [1.0.0] - 2026-09-19

Thirty-six of the commits in this release are a redesign: the app keeps every
feature it had and changes almost everything about how it looks and how it is
reached. The rest is a cockpit that reads the month, a log of complementary
activities, a standalone week that composes, shares and prints, and every PDF
set in the house style.

### Added
- A session shares as an image in the house style, in the four sizes the week already has, first in the picker. The forty pastiches stay, but the sheet drawn in the app's own language, paper, ink, every edge ruled, the ramp for the zones and the wordmark's one vermillon dot, was one portrait template with a drawing and no structure. The four new sheets print what a session is, and no more: the name, its facts in mono (category, difficulty, duration, dominant zone, load), the profile large on the ramp with its axis, then three ruled lines, one per phase, each block a chip on its zone's tint carrying its duration and its code (`2' Z5`, `15' Z1-Z2`, a range kept as a range), a repeat written the way the page's summary writes it (`2 × ( 12 × 30" Z5 / 30" Z1 ) + 3' Z1`, the recovery dashed), the phase's duration on the right and, under a phase of three blocks at most, the blocks' words. The time in zones follows as a ruled bar, and the first tip with the two runners take the room a short session leaves. `Sheet` (1080 × 1350), `Square` (1080 × 1080), `Landscape` (1200 × 675, chips alone) and `Story` (1080 × 1920). A sheet cannot grow, so a dense session takes its room from the chips' type in steps. Verified on a one-block recovery ride, a four-block endurance run, a 30/30 with nested sets, a mixed tempo and VMA session and a thirteen-block fartlek, in the four sizes
- A week shares as an image, in four sizes, from the share button of its page: the same Strava-style sheet the sessions use (carousel, save, copy, native share, copy the link), with four sheets drawn in the house style, paper, ink, every edge ruled, the ramp for the zones and the wordmark's one vermillon dot. `Sheet` (1080 × 1350, the one to send to someone who will read it) prints Monday to Sunday as rows with every name in full and a ruled bar under each session, the rhythm read down the page; `Square` (1080 × 1080) and `Landscape` (1200 × 675) fuse the rhythm and the board into one object, seven bars and under each bar the day's cards; `Story` (1080 × 1920) puts the rhythm first and tall, then the sessions. Every sheet carries the week's name, its facts (sessions, hours against the budget, load) and the 80/20 split in words, and the portrait ones the two runners in ink. The rhythm's figures come from one helper the page's chart now reads too, so the image shows the week the board shows. The share sheet itself became generic (`ShareSheet`), the workout dialog being its first instance; its track now pads to centre the last slide, which with four templates on offer could never be selected
- The cockpit says when it is not on today, and brings you back. A page named `Today` could show the 2nd of September with only a three-pixel dot to say where today was: the date line now carries the gap (`15 days ago`) on a reserved second line with a `Back to today` link, blank on today so nothing moves at the first pick, and today in the month grid wears a ring around its number, the convention of every calendar, stronger than the rule under the picked day. The grid gains a one-line legend under it (done, planned, skipped, rest, off plan) drawn with the real marks, enlarged to ten pixels, since filled against hollow at eight pixels was below what a scan can tell apart. The two periods on the screen are named, `22 sessions planned` in the grid header for the whole month and `Review to 17 Sept.` for the month lived so far, and the review's legend names its rule by origin rather than merit: `from the plan` and `as complement`, since strength counted as done while cycling counted as extra and nothing said the line was plan against journal, not running against the rest. The cockpit's gauge drops its verdict: the 80/20 badge judged seventeen days with an hour of strength outside the zones, and the one place the screen passed judgement is the one place it must not be wrong, so it shows the split as numbers and says apart what has no zone (strength, nothing to qualify) from what has no known template. On a wide screen the review and the gauge sit side by side under the two columns instead of lengthening the left one
- Under the month's review on the cockpit, what the month lived weighed in INTENSITY: easy, tempo, intense, in the polarisation gauge the standalone week already uses. It is computed the way that week computes it and for the same reason, PER SESSION by its characteristic zone rather than by time in zone, since a VO2 session is intensity even when most of its minutes are warm-up. A completed session takes its template's dominant zone at its actual minutes, a week activity takes its planned effort, and a journal entry takes its perceived effort (given, or deduced from its purpose: a commute without an RPE reads easy), on the same bands the session close uses. Strength and an unloaded template are not guessed: their minutes are counted apart and the gauge says so. The advice line stays off, this is the past and the verdict word is enough
- The cockpit (`/today`) gains a MONTH, beside the week, with nothing else changed. A `Week / Month` switch sits above the seven-day strip; the month is the same instrument one step further, a grid of dates whose pick reloads the stack below it exactly as the strip does, so a session of any week of the plan can be read and closed from here. Each cell carries what the strip's column already carries, scaled down: the sport glyphs, one mark per session whose SHAPE says its status (outline planned, filled done, hatched skipped, a rule for rest) and the complement tick under the ground rule, with the same two marks for the picked day (ink on the number) and today (a round dot). The grid always reserves six rows, so leafing from a five-row month to a six-row one moves nothing under the thumb; the arrows are bounded to the plan's months, and cells outside the plan are inert. Under the grid, the month's review reuses the week review verbatim, bounded to TODAY for the month being lived: a month in progress carries sessions that have not happened yet, and counting them as unclosed would accuse wrongly (twelve unclosed on the 17th, eleven of them simply ahead); what the month plans in full, the grid header says (`22 sessions · 20h48`), what it lived so far, the review says. Kilometres stay per sport, as everywhere. The mode is not remembered: the arrival screen is the week, every morning, and switching back to it returns to today. From 900px the month lays out in TWO COLUMNS, the grid and its review on the left and the picked day on the right, so the month and the session read without scrolling: the cockpit is a 620px column drawn for the phone and kept as such on desktop, which is right for a ten-second screen and wrong for a consultation that stacked a six-row grid, a review and a gauge in it, 2100px tall with half the width empty. Under 900px the grid keeps the single column and the order validated on the phone; the week mode does not change shape
- A session of a standalone week says how it counts: loose or fixed. The model froze a duration on every session placed, even the ones nobody had decided, so a template week carried the same false figure as a week actually lived. A LOOSE session keeps the range of its template and the week counts it at the middle of that range, with kilometres as an estimate at its pace and never as data; a FIXED one counts the duration and kilometres set on it, the shape of a week lived or shared with someone who must follow it. Absent, the precision reads fixed, which is what every stored session was without saying so. The default at placement follows what is really decided: a Z4+ session is planned at the stopwatch and lands fixed, an easy or long run is run by feel and lands loose, strength stays fixed. The share link carries the precision and the kilometres in two more tuple positions, appended, so older links decode unchanged
- A session sheet on the standalone week: a tap on a card opens the session's own sheet from the bottom of a phone (from the side on a wider screen), instead of a context menu at the finger, which is a mouse gesture. It holds the one decision a week session asks, loose or fixed with the duration and kilometres, or the duration and effort of an activity, and under it the menu's gestures: view, re-draw, lock, move to another day, remove
- The session picker reaches every catalog and the builder. Cycling and swimming sessions could not be added to a week from its page at all, only activities could; the picker's `<select>` becomes a row of chips, one per catalog (easy runs, quality, long, strength, cycling, swimming, activities, mine), it chooses the day when opened from the dock, and `Create a session` sits first: the builder opens with the way back, and the session it saves lands on the chosen day
- A week activity carries a duration and a planned effort, so a bike commute weighs something in a standalone week. The activity log is dated, which is its strength and what makes it mute on a `Ma semaine` template: there is no Tuesday to log against. Three `Vélo` cards on the board therefore announced 3 sessions, 3.1 h, a flat rhythm on the three commuting days and a `too much intensity 65 / 35` verdict, because three cards without a duration weigh zero. Placing or tapping an activity now asks the two things a template can honestly say, how long (the same `h:mm` field as the log) and how hard, in three words rather than ten steps, since one PLANS a commute easy and does not plan it at 3/10. The effort becomes a zone (easy Z2, moderate Z3, hard Z4) and the zone does the rest through the paths that already existed: the polarisation classes the activity like any session, the rhythm gives it a height and a colour, the load is the zone's TSS, the same unit as the running sessions. Strength, yoga and active rest keep no zone and count in time only. A `Vélotaf` entry sits first in the picker, pre-filled from the profile's commute pattern as declared, never doubled for a return trip nobody announced; a card without a duration says `Duration to set` and weighs nothing until it has one. Shared links carry the effort in a sixth tuple slot, and activities now travel with a shared week instead of being dropped as unknown workouts
- A log of complementary activities: bike commutes, trips, and sessions done outside the plan. It answers a fault the app had no way of even seeing: someone preparing a marathon who rides to work four times a week was living six hours of training while their plan announced four, and the load it computed was wrong in the one direction that hurts. An activity is a dated RECORD in its own key, not a session in the plan: it exists without a plan, it survives the plan, and a plan finds it back by its dates. The only required field is the DURATION, deliberately, it is the one metric that always exists and the only one load is computed from; distance, elevation and average watts refine and never demand. A `commute | trip | training` purpose sits in first class because it is a training fact, not a filing label: a commute is volume and fatigue without being a stimulus, and counting it as a session would be the mirror image of the lie being fixed
- A Sunday week review, on the cockpit and at the head of the log. It is DRAWN, not written: the ratio is the title (3/4, at display size), and the volume is a bar putting three quantities on one axis, what was done, what was done on top, and a graduation at what was planned, so a week that ran past its target is seen rather than computed from three numbers. Overshooting the mark is exactly the week the app could not describe before: four hours announced, six hours lived. A sentence survives only where there is no number to show, nothing closed yet, or no plan that week. It has no screen of its own and wants none: the seven-day strip already picks a day, so picking Sunday is the gesture that asks for the review. Two honesties it pays for, an unclosed session is not a skipped one (it has its own count, and the review refuses to judge a week where nothing was closed), and adherence is measured against what was PLANNED, not against what was closed. With no plan running it falls back to the calendar week, since commuting does not wait for a plan to count
- Plan statistics carry the complementary volume, over the plan's dates: time, load, elevation, and the share of total time it represents. Time is summed across disciplines because time is the one thing that sums; kilometres stay inside their discipline, and no function anywhere totals them, since 30 km of cycling and 10 km of running do not make 40 km. Load is duration times perceived effort (session-RPE, Foster 2001), which is the method the repository already uses for its sessions and the only one that spans sports without an invented conversion factor
- Ground prepared for triathlon, without pretending to deliver it: the activity record carries the repository's own `Discipline` union, so the day the goal is a triathlon the same record holds swim, bike and run with no change of shape, and `purpose` keeps telling a commute from a session. `PRACTICE_META.triathlon` stays `announced`, and the test that guards it still fails if anyone flips it without the plans
- The session structure saves as an image of its own, whole or one phase at a time. The phase cards, step by step, are the block people screenshot to take to a session or send to someone, and the existing session PNG renders the whole card instead: the title, the profile and the zone table, but not that breakdown. A `Download the structure` menu sits under the phases. The whole block captures what is LIVE on the page, personalised paces included; a single phase renders an off-screen copy at a phone's width instead, in the narrow presentation (badges without their label, no 96px profile), so the portrait card is the same image whether it is asked for from a desktop or a phone
- A generator for the three "In motion" thumbnails of the README (`video/scripts/readme-gifs.ts`, `bun run gifs`). They had none, which is exactly why they rotted: one redesign later they still carried the old wordmark, the orange accent and the six zone colours, under captions quoting a version of `copy.tsx` that no longer existed, and nothing could flag it because nothing knew where they came from. They are now the 9:16 cuts of `Feature-Polarise`, `Feature-Zones` and `Feature-Library`, end card trimmed, in English like the README. The weight budget drives the encoding: the films' ground drifts on purpose, a drifting gradient is the worst thing a GIF can compress, so 6fps, 300px, 64 colours and no dithering at all — dithering manufactures noise exactly where the film is flat
- The session profile reaches the two dense formats of the library. The grid card has drawn the shape of a session since the redesign, a ZoneBar 36px tall; the compact card and the list row said nothing but words, so two thirty-minute Z2 sessions looked identical whether they were a steady run or a 30/30. Both now carry the same bar and the same condensing, in an 18px thumbnail: under the title in a compact card, and between the facts and the favourite in a list row, on a fixed 56px column (72px once the fact columns come back) so the widths, which are time, line up down the list. A strength session carries its intensity ramp at the same size and in the same place, since the two disciplines share the grid and the list
- Practices become a real axis: every session, collection, plan and route declares whether it is road, trail or ultra, and the whole app filters on it. The axis is DERIVED from the catalogue rather than stored, so it cannot drift out of sync with what is actually there
- Eight sessions written for ultra distance, TRL-013 to TRL-020: time on feet, power hiking, back-to-back days, technical descent, race-day fuelling
- A ready-made trail plan. The ready-made shelf was empty for trail and ultra, so a third of the practices opened onto a dead end. It is a 30 km short trail, the distance the engine actually models, rather than a 40 km label matching no volume, phase or taper table
- Practice cards say what is behind them: how many sessions and plans are waiting, derived from the same index the library uses. They used to announce a property of the model rather than of the content. An empty shelf now says so instead of implying otherwise
- The fifteen collections carry their practice, and lose a dead field. Curation like Ultra goal was invisible in the new axis. No practice means cross-cutting, so valid everywhere, which is the case for ten of the fifteen
- One figure per practice, reused across the library, the plan and the empty states. Three of the four already existed: a drawing replaces, it does not accumulate
- The wordmark is the word itself, vectorised. The drawn sign that was planned got built, looked at, and dropped: every pose within reach of the doodle rig produced a person running, where the brief asked for sport in general
- The shell runs while the app boots: six frames per stride, two strides, held for one stride so nothing flashes. A setting turns the opening off
- Settings that hide instead of deleting: two lists, the practices you follow and the surfaces you want to see. The app has 61 pages and nobody wants 61. They are opt-out lists, so a settings object written before this release picks up the new fields on read, with no migration code
- A storage layer that no longer takes the app down when it fails
- The session menu in the plan's list view: view, find a route, close out, replace, substitute, remove. It is the menu the week board already opened, now shared by both views instead of written twice
- Drag-to-close moves into the primitive and now serves all five bottom sheets: simulator settings, week generator, unavailability, session close-out, add a session. It only existed on the last one
- A typography gate in CI, next to the FR/EN parity check

### Changed
- Every PDF the app writes is set in the house style, on one kit. The session sheet, the race-day plan and the training plan were three Roboto documents with black table heads, a slate banner, blue stat tiles and a red race row, each with its own fonts, footer and page geometry; the week's PDF had just been redrawn as paper and ink and the other three read like another product. They now share `pdfHouse`: the app's own type (Bricolage Grotesque and JetBrains Mono, embedded from `public/fonts/pdf` and fetched only when a PDF is asked for, Roboto as the fallback), the wordmark and a mono kicker at the head of every page, the title in display type with a facts line under it, ruled tables with mono heads and hairlines between rows, the zones on the ink ramp, and a footer with the page count. The session sheet draws its profile as the same frieze the app shows, its three phases as ruled tables and its tips and mistakes as ruled lines. The race plan prints the distance as its title and the target pace, start and finish as its facts, then the timeline, splits, fuelling, breakfast, cues and checklists. The plan's phases are one table, each week a ruled table under a mono line (`S1 · Base · 2h24 · 11 km · SL 5 km`) with the day, the session, its type, zone, duration and summary, a `key` mark on the key sessions and the pace note under its row; the lexicon at the end prints every session's structure the way the week's PDF does, running and strength alike, and the superscripts that pointed to it are gone. A standalone week keeps its own document
- The standalone week page puts the board first on every screen, and the generator away. On a desktop the board shared its column with a 340px rail that always held the generator, which left each of the seven days 95px, three words of a name and the hover actions printed over the zone mark, while half the viewport stayed empty; and someone composing a week by hand edited it beside a form they never used. The board now takes the whole column, widened to the 1360px measure, alone by default; the generator and the session picker are TOOLS, opened from two toggles in the header (`Generate`, and `Add a session` in the one vermillon fill) into a rail that closes when the tool is put away, with the accent moving to the open tool's own call. The summary folds to the same one-line strip the phone already had, the figures, the 80/20 verdict and the rhythm thumbnail, with the full bar behind `Details`, so the week begins above the fold. The intensity scale is printed once, folded under the board, instead of once above and once below. The hover actions on a card are backed with the card's own paper, so on a narrow card they cover the zone mark cleanly instead of colliding with it. On a phone the dock keeps `Add a session` and ONE draw pill, which opens the settings whose own call generates, in place of two, one that drew on the spot with settings nobody had seen and one that opened them. Between 768 and 900px the picker opened nothing at all, the rail being folded and the sheet already hidden: the sheet now holds until the rail exists. Reloading a week no longer reopens the generator, the navigation state that asked for it is consumed on arrival
- The week's rhythm takes half the summary on a wide screen. The phone strip already puts the shape of the week beside the figures; from 1024px the full bar gave the chart an 18rem column against the rest for the figures and the 80/20 gauge, and it read as a footnote to the zones. The bar now splits in two equal halves, the figures and the gauge on one side, the rhythm on the other, with the chart taller and its columns wider to fill its half; the folded strip splits its line the same way between the figures and the thumbnail
- The volume budget belongs to the week, and is optional. The `6 h` the summary measured every week against was the generator's slider, a setting of a form, so a week composed by hand read `12.1 / 6 h` and `Over the 6 h budget` against a figure nobody had chosen, and the only way to change or silence it was the generator's settings. The budget is now stored on the week itself: a week built by hand has none, and its summary prints the volume alone, with no bar and no warning; the generator records the target it composed to, as do the ready-made weeks; and it is set where the week's category is, from a `Budget` badge beside it in the page header (none, or so many hours), from which the generator starts next time; the summary only reads it. Stored plans keep the field through normalisation
- Week creation offers three doors instead of two. The first door served both the generator and composing by hand, and always opened on the generator's settings: `From scratch` (by hand) now creates the empty week and opens the board alone, `Generate a week` creates it and opens the generator, `Pre-built week` is unchanged
- A shared week is previewed on the editor's own board, read-only, instead of a list. The list put the session's name at one edge of a 1070px row and its marks at the other, printed `0s` for an activity without a duration, and never showed the shape of the week, which is what a shared week is for; the page also spent a full summary card on it. It now shows the folded summary strip and the same seven days as the editor, cards, zone marks and folded legend included, with a rest day named `Rest`; a card opens the workout it names. `Add to my weeks` is unchanged
- The complementary activity form no longer offers `Bike commute` under running or swimming. The purpose row was one fixed list, `Bike commute / Trip / Training`, whatever the discipline: a cycling word on a run to work, and a commute by swimming, which was not only absurd but a wrong number one tap away, since a swim logged as a trip weighs 3/10 instead of 5/10 in the load. The purposes now follow the discipline, from the same table that already says there is no elevation in the pool: cycling, running and other keep the three, with the discipline's own word (`Bike commute` on a bike, `Commute` on foot), and swimming drops the row altogether, training being the only thing a length can be. Switching a draft to swimming brings its purpose, and the default effort that follows it, back to training; a stored swim carrying a trip reads as training when edited and is saved that way. The log and the cockpit label a purpose through the same function as the form
- The standalone week page on a phone puts the board first. The full summary took the first screen entire and the week began a screen and a half lower; the board is the object and the summary its consequence, so under 900px the summary folds to one strip (the figures, the 80/20 verdict, a thumbnail of the rhythm) and opens on demand. The dock carries the action of the moment, `Add a session` in the one vermillon fill with the draw and the settings as pills beside it, since once a week is on the board the thing one does is add or adjust a session, not draw it again. The intensity scale is printed once, under the board, where it was printed twice. A rest day is one dashed slot the width of its row, and the small `+` at the end of a filled day goes, the dock states it in words and covered it on the last rows. The desktop layout, board beside its rail, is unchanged
- The week summary counts the session's own duration, not its template's: a session fixed at 32 min weighed its 45 min of catalog in the volume, the rhythm and the load. The slot carries the session's duration and the load is the template's TSS scaled to it
- The complementary activity form asks its one required question in one gesture. The duration was a single field in MINUTES, which demanded a mental conversion before the first keystroke: nobody thinks of their bike commute as 85 minutes, they think 1h25. It becomes ONE field under an `h:mm` mask, with a digits-only keypad, and the digits enter from the RIGHT the way a stopwatch fills: the last two typed are always the minutes, so 45 reads 0:45 and 125 reads 1:25. Filling hours first would have made the short entry both ambiguous and expensive, 45 meaning 45h as much as 45min and a half-hour trip costing 0030, and a sub-hour duration is the most frequent case on this screen. The parsing stays tolerant rather than strict, 0:90 is a valid duration and normalises to 1:30 on blur instead of being refused. Storage does not move: `durationMin` is still minutes, the conversion lives at the form's edge and nowhere else
- The form's optional fields fold away. Distance, elevation, watts and the note sat at the same visual weight as the duration, under a line announcing that only the duration was required, so the screen contradicted the sentence right above it. They move behind an `Add details` disclosure, which opens on its own in the two cases where keeping it shut would lie: editing an activity that already carries them, and a recall chip that has just filled them. Nothing is saved that the screen does not show
- The form answers from the log rather than asking again. A bike commute repeats, and the duration being asked for was already three lines up in the journal: a row of up to three already-recorded durations, same discipline and same purpose, puts one back with a single tap, along with the distance, elevation and watts that came with it. They are ranked by FREQUENCY and not by date, so the trip made every morning comes before Sunday's exceptional ride. A recall is offered, never pre-filled: a record placed by the machine and saved without being read is an invented number that then counts towards load
- Opening the form points at the duration only where pointing costs nothing. Focus started on the date, which is already right, so the focus ring posted a second vermillon call opposite the save button to designate the one thing there was nothing to do about; moving it to the duration, the screen's one empty field, was right on a mouse and wrong under a thumb. A soft keyboard rose over the sheet at the second the sheet opened, covering its lower half — the discipline, the purpose, the save button — and putting the date and both rows of choices out of reach until it was dismissed, so the gesture the form asked for first was getting rid of a keyboard rather than answering its question. Focus is now posted under `pointer: fine` only: on touch the panel opens whole and the keypad comes up when the duration is tapped, one tap that was never the expensive part. Editing focuses nothing on either pointer, since one comes to correct a precise field and the keyboard would cover the ones being re-read
- Logging an activity looks like an action, because it is one. The control carried the cockpit's EXIT mark, a line of text followed by an arrow, and that row teaches its own rule: its arrow says two things at once, this is a gesture AND it takes you elsewhere. Drawing a workout holds both, it navigates to `/library/draw`. Logging holds only the first: it opens a panel in place and writes. So the arrow promised a page that never came, and a line of arrowed text between two links read as a caption rather than a control. It becomes an outlined button with a `+` on both surfaces, the same `+` the log's own button carries, which leaves the cockpit row with three distinct marks for its three distinct promises: a frame and a plus acts here and writes, text and an arrow is a gesture that takes you away, underlined text is a place. The words stay in the first person (`I did something else`) where they answer the day's session printed right above; the frame is what says control, the words no longer have to
- Logging a complementary activity reaches the plan's own page, where it was missing: the cockpit had the door and the plan did not, so the one screen where you notice your volume is wrong was the one screen that could not fix it. Two ways in now, and each answers a different moment: `I did something else` sits in the current-week block, next to the day's session, and targets today (the week's Monday when you are looking at a week you are not living); `Add an activity` sits in the statistics tab, in the complementary block itself. That block also stops vanishing when it is empty: hiding a DATUM that does not exist is right, hiding a DOOR because nothing came through it yet is not, so with logging offered it stays and the invitation takes the room the figures have not claimed. On a prebuilt plan's preview, which is not yours, it disappears exactly as before
- One activity log in memory instead of one per component. `useActivities` kept its own `useState` and re-read `localStorage` on every mount, which worked while a single component per screen used it. The plan page has two, the week block that WRITES and the statistics block that DISPLAYS: logging a commute from the first would not have moved the second, and the screen would have said both 1h25 and nothing at all. It is a module store behind `useSyncExternalStore` now, so every write wakes every reader and two components of one render cannot read different lists
- The three ways into the activity form share their plumbing (`useActivityLog`): holding the panel open, the day being targeted, telling a new record from a correction, writing, reporting, closing, and reading the recurring commute pattern that pre-fills. Two screens each carried their own copy and a third would have been the one too many, since the first divergence would have meant logging from the plan no longer asked what logging from the cockpit asks
- The week review no longer looks like it contradicts itself. It showed `KM 0/56` directly above a line reading `Cycling 1h25 . 26.6 km`: both figures were right, but the first never said it counted RUNNING kilometres only (`plannedSessionKm` returns zero as soon as a session is not one), and nothing said why the cycling kilometres stayed out. Time sums across sports because an hour of cycling and an hour of running are two hours of training; kilometres do not, because 30 km of cycling and 10 km of running do not make 40 km, and 40 is exactly the kind of total that gets remembered and repeated. Two fixes, neither of them a sentence: the fact carries its sport (`run km`), and the complement's half-list becomes a real TABLE of the week's volume, the plan's own sessions included, one row per sport and one column per quantity, biggest first. Sessions and activities of the SAME sport add up inside a row, which is precisely what the rule allows. The table has no total row: the total time is already in the facts above, and kilometres are totalled nowhere, so the rule lives in the shape rather than in a footnote. It stays hidden for the runner who only ran, on the flat, with a plan, since the facts above already carry those two numbers
- The complementary activities page carries a way out. It is reached from four places (the menu, the cockpit, the command palette, a plan's statistics), so the exit cannot be a link to one fixed destination without being wrong for three people in four: it returns the PREVIOUS page, whatever it was. It only shows when there is an in-app previous page, and the test is the router's location key rather than `history.length`, which lies in both directions, counting entries from sites visited before this one and already reading 2 in a fresh tab on several engines. Opened from a bookmark, a search result or an installed app's home screen, a Back that leads nowhere, or worse out of the app, is less than no Back at all
- Perceived effort reads with a word, not a bare number: the head shows `Easy 3/10` rather than `3/10`, off the same table the session close uses (`rpeWordKey`), because a bare 7 on a scale of ten forces you to remember what a 7 is worth. The scale itself also moves BELOW the duration: its value is already correct by default, so it has no business delaying the one empty field on the screen
- The cockpit's seven-day strip gains a second channel, under the ground rule: what happened OUTSIDE the plan. It only ever drew the plan, so a day spent riding to work read as REST, the opposite of what happened, and that is the one lie a seven-day strip can tell. The complement goes BELOW the rule rather than onto the stack, for two reasons and the second is the real one: sharing the column's budget would shrink the plan's blocks on commuting days, and seven heights that no longer measure the same thing stop being comparable; and it is not the same quantity, an hour of commuting is not an hour of session, and stacking them would say it is. Above the rule, what the plan asks; below it, what life added. The channel has its own scale, so complements compare to each other and never to a session
- The recurring commute pattern in the profile now says what it is, an HABIT and not a record, and points at the log. It was the closest thing the app had to counting a commute, and it could only ever state what usually happens: it now serves as the default values of the log form instead of standing in for it
- The marketing films run on the app's design layer. The video package carried its own palette, left over from before the redesign: a blue slate, an orange accent, six zone colours, three families' worth of Google-hosted fonts. `video/src/theme.ts` now mirrors `src/styles/design/` — paper, ink and vermillion from `colors.css`, the effort ramp from `zones.css`, the three families from `fonts.css`, and, most visibly, the ink outline and the HARD offset shadow from `borders.css`. The hairline grey cards and the 110px blur under the screenshots were the single thing that most dated the films
- The effort ramp in the films goes from six hues to one ink ramp, like the app. Not a swap of values: six colours said "six categories", the ramp says "one axis, and you are somewhere on it". Three places printed white on a zone, which worked while every hue was dark and now prints pale on pale, so `zoneInk()` carries the app's threshold rule — ink up to Z3, cream from Z4. The polarised model's big figure goes back to ink and lets the rule above it carry the zone: a figure printed in pale grey is a figure nobody reads
- Two effects leave the films, because the system refuses them: the white sheen sweeping the zone list, and the blurred shadows. What they were answering — a panel that has finished animating must keep some life — still holds, and is still answered, by each row's own phase-shifted breath, which is what `bun run qa:motion` checks
- The films' fonts leave Google. They were fetched on every render, and a cut network does not fail a render: it ships it in the fallback face, forty-eight films in the wrong typography, without a word. `bun run sync` copies the app's own three files and `video/src/fonts.ts` serves them from the package
- The render's screenshot preflight asks only for what the selected films read (`FILM_SHOTS`), so rendering three films no longer waits on a capture of the route generator, which needs a live routing service to say anything
- The architecture goes from five doors to four: the cockpit, sessions, plans, figures. Navigation asked for 28 decisions before the first session. The 35 destinations that left KEEP every route, stay indexed, prerendered and shareable, and land in the footer, the palette and the mobile menu list
- The cockpit at Today is the answer rather than a menu: five boxes of the same shape became the shape of the week, the day's session is one tap from the strip, and its profile is previewed in place. The column is centred, and the headline IS the answer
- The library sorts by PRACTICE first, with modality below. Someone training thinks in practices, not disciplines. Modality stays, and that is a choice: dropping it would have orphaned the 10 cycling sessions, the 10 swimming ones, the 17 strength ones and the two calculators built on the FTP and CSS engines
- The random draw comes out of the menu, the library controls go from five rows to three, and the help toasts are gone. They raised themselves on four pages, a second and a half after arrival, and landed on the page kicker
- The filter rail fits on one line, and the formats go from four to three. Focus mode was not a mode: its attribute was styled nowhere, and on a phone it differed from the grid by 20px of gutter
- A plan page opens on THIS WEEK rather than four counters about the whole plan: the day's session with its full name and its close-out box, sessions done out of the total, time logged against time planned, and the next key session
- The plan wizard asks for the PRACTICE first. It used to show all seven distances flat in a single grid, with the whole trail treatment held in a boolean that governed one hint sentence: you could choose ultra and be asked for a pace per kilometre, never for elevation
- Elevation is asked only of those who run it. The field existed, but it sat on the pace screen and rendered UNCONDITIONALLY: someone preparing a road 5K was asked for a climb
- The plan wizard, 1,609 lines in one file, becomes a step registry. No behaviour changes: same steps, same order, same labels, same plan produced. That is what makes the next batch readable
- The wizard's calendar opens as a drawer, and the Next button leaves the closed questions. Capped to the space measured between the field and the window edge, it came to 293px for a grid that needs 356: a month was read through a window six rows out of seven
- A plan's calendar goes to one row per day below 640px, and the seven-column grid retires. Seven columns in 390px gave cards of 42 to 60px. Measured at 320, 375 and 390px: no truncated titles left, against 5, 4 and 3 before
- Vermillon says one thing now, and only one: now. A chosen card takes an ink ring, an open tab takes an ink pill, and a plan phase gets no colour of its own
- Six cards carried a coloured edge on one side, running along a rounded corner then dying against a grey rule. All move to an inset ring on four sides, which follows the corner radius without moving a pixel. The current week was marked by colour alone, so its number now goes bold
- Bands are separated by space alone. The rules between them are gone, and four boundaries stopped paying the gap twice
- Tables of contents lose their vermillon edge. The nutrition hub already marked the current heading with an ink pill: two vocabularies for one thing, and the second wins. The simulator was worse, it changed language when it changed width
- The footer folds into groups below 900px: 1.65 screens down to 0.59. Twelve links at the 44px touch floor made 1,100px of footer on a phone. The floor does not move, the number of rows does
- The footer's ink bar loses 90px on a phone, the footer 128. It measured 219px, 31% of a screen for five lines of legal notices
- One gesture per step on a phone: date fields open on the first month that holds a selectable day rather than on the current month, filters stick, and the calendar opens where it should
- The add-a-session panel comes in front of the MENU pill instead of being pierced by it, breathes, and closes with a finger
- The dominant-zone stride leaves the session screen: the badge, the facts row and the distribution table already said the zone. Its sole was aligned to a point on the time axis, where a mark reads as a cursor, and that one measured nothing. The figure that points takes its place
- A session in the list view is a line, not a card inside a card inside a card. The type badge becomes a quiet mono caption, and on a phone the four action glyphs become one button that names them
- A day on the week board is a line too. Nineteen drawn rectangles for five sessions became nine, and the only framed row left on the screen is today
- Ultra becomes announced: what the generator produces at that distance is not judged reliable enough to offer. An announced practice is now visible before it can be chosen, instead of a silently empty shelf
- The display steps drop one step on mobile. Body text, mono and the spacing grid do not move, so line lengths and hit targets are unchanged
- Final review pass: on the three screens that carry the work, the question becomes the title, and the informal voice is applied throughout
- Typography: no guillemets, no em dash, no en dash, in visible text and in the source alike

### Fixed
- Opening `Add a session` on a standalone week no longer gives the page a scrollbar. The rail beside the board held a picker sized to the viewport, `100vh - 160px`, and a grid row is as tall as its tallest item: on a screen where the board fit, the row grew past the fold and the one screen about composing a week scrolled for a panel that scrolls itself. The rail now takes the height of the row and nothing more, the board or the screen when the board is shorter, and the tool inside it, picker or generator, sticks under the header while a tall board scrolls and never runs past the rail or the viewport. Between 768 and 900px the picker already opened as a sheet, but the scrim left at 768 and the scroll lock with it, so the sheet rose over a page that was neither dimmed nor held; both now follow the sheet's own 900px
- A standalone week exports to its own PDF, in the house style. It went out through the plan's document, drawn for a programme of many weeks: a slate banner reading "Plan libre", a phase table reading "S1-S1", blue stat tiles, a note about superscripts, a lexicon, and the activities printed by their internal ids (`__activity_commute__`, `0min`), since the export looked the names up in the catalogue and a bike commute is not in it. The week's sheet is paper and ink, set in the app's own type (Bricolage Grotesque and JetBrains Mono, embedded from `public/fonts/pdf` and fetched only when a PDF is asked for): the wordmark, the week's name, its facts (category, sessions, hours against the budget, load), the rhythm drawn as seven bars, the seven days as ruled rows with each session's zone, duration and structure in one line, a `key` mark on the key sessions, the 80/20 split with its verdict, then a second page with the structure of every catalogue session, running and strength, for the coach who reads it. The names the page hands the export now win over the catalogue's, so the activities are named in the PDF and the calendar alike
- The week's share images hold a week of several sessions a day. The four sheets were drawn for one session per day and clipped everything past that: a second card fell off the bottom of the square and the landscape sheets, and the rows of the sheet and the story ran under the split. A sheet cannot grow, so it shrinks in steps instead, by what the week holds: with two or three sessions on one day the bars give up height and the cards go to two lines, then one, ending in an ellipsis rather than a broken word; past eight rows the list prints smaller type and thinner bars, past fourteen the bars go, and the two runners take only the room that is left. Verified at two and three sessions every day, twenty-one in all, in the four sizes
- The reschedule and adaptation preview dialogs had the same two scrollbars, for the same reason: the dialog caps itself at 85vh and scrolls, and the list of affected sessions carried a hard 40vh cap of its own, so a long list engaged both. Two bars side by side, and the dialog's title out of the top while the list scrolled on its own. The 40vh is a maximum, not a floor: the list now shrinks under it when the dialog runs out of room, which is the rule the picker dialogs next door (`.zn-pdialog--list`) already applied to their own lists. Reproduced on a plan with 25 blocked days at 390x600, on an iPhone 13 and on a 1280x700 desktop; one scrollbar on all three after
- The plan's start-date dialog could not be scrolled to its own save button. It carried no height cap and no scroll (a dialog is `overflow: visible` on purpose, so the date picker's popover is not clipped), and measured 710px: 46px past the bottom of an iPhone 13, and 110px at 390x600, where the title left through the top and `Save` through the bottom with no way back, since the page behind a modal is scroll-locked. It only showed on a past start date, whose warning banner is what pushes the panel over. The cap goes on the dialog and the scrollbar on its body, never the reverse: `popover.tsx` mounts the date popover inside the dialog, so a dialog that scrolls would clip the calendar, while the body is not the popover's parent. Checked on four sizes: nothing cut, title and buttons in place, and the desktop dialog unchanged
- The complementary activity form had two scrollbars inside the sheet. The sheet is a scroll container capped at 82% of the screen (`sheet.css`), and the form's body carried a cap of its own, `min(56vh, 520px)`, written for the desktop dialog, which has no cap at all. Both engaged: two bars side by side, the middle of the form scrolling on its own, and the title, the grab handle and the close button sliding out of the top. The drag-to-close grip is the panel's top 64px (`useSheetDrag.ts`), so once the sheet had slid it sat on the fields rather than on the head, and a thumb reaching for the form pulled the panel. The body now takes the room its host leaves it and gives the rest back, so the head and the foot stay put and the body is the one thing that scrolls; the cap survives only where the host has none, the desktop dialog
- The toast banner sat behind the top bar on a phone. Two faults, and the first is the older: the layer that carries the toasts is `position: fixed`, which opens a stacking context whether or not a z-index is named, so sonner's `z-index: 999999999` was sealed inside it and what actually competed with the page was the layer itself, at `auto`. It lost to the sticky top bar's 40. It now carries 1300, above everything this document stacks. And the top offset was set through sonner's `offset` prop, which the library ignores below 600px in favour of `mobileOffset`: on a phone the toast fell back to the default 16px, so neither the bar nor the notch was cleared. The placement moves into `toast.css`, where it can also say the one thing props cannot — that a toast fired while a modal sheet is open must NOT clear a bar that sheet is covering, or it lands on the sheet's own title
- Exporting an image did nothing at all on a phone. `toPng` returns a data URL and that is what was handed to the download anchor: a desktop browser accepts it, a phone does not, and refuses a few-hundred-kilobyte data URL without an error or a message. The button said "Image exported" and nothing happened. The capture becomes a blob, like the eight other exports. On a handheld it also goes through the native share sheet rather than a download, because a downloaded file never reaches the camera roll: `Save image` in that sheet is the only door to it
- Every PNG export rendered in the system's fallback font. `skipFonts: true` promised to avoid errors over undefined fonts; what it did was drop the app's three faces from the capture, so the text re-flowed inside the image: phase titles wrapped onto two lines and collided with their summary. The faces are served by the app itself (130 KB in `public/fonts/`), so there is no third-party request to fear, and they are embedded now
- Two of the three phase tables in a workout PDF printed their header as a blank black bar. The three tables shared one header row, built once and handed to pdfmake three times, and pdfmake writes its layout measurements *into* the cells it is given: the warm-up consumed them, the main set and the cool-down got back objects already measured and drew no column titles at all. A fresh header row is built per table now
- Characters the PDF font cannot draw came out as empty boxes in the middle of a sentence. pdfmake embeds Roboto, which stops at extended Latin: the key-session star on every week of a plan, the arrows in RP-013's coaching tips, the ordinal superscript in TRL-018. Every string now goes through `pdfText()` on its way to pdfmake, which translates what has a readable equivalent (an arrow becomes `->`, `20e` keeps its `e`) and drops what does not, such as an emoji in a custom session's name. `pdfText.test.ts` interrogates the shipped font with fontkit over the whole catalogue and both locales, so a tip written tomorrow with an arrow in it fails CI rather than a reader's PDF
- Garmin workouts exported without their heart-rate zone. Every step declared a heart-rate target and carried no target value, because the zone was written as `targetHrZone`, which is a *sub-field* of `target_value` in the FIT profile: the SDK encoder accepted the key and wrote nothing. Steps now carry `target_value`, and a Z6 sprint clamps to Z5, the highest zone the format knows
- An image exported in dark mode was illegible. Both capture paths painted a fixed light background under whatever was on screen, so a dark card's pale title and text came out white on white. The background now follows the theme actually painted
- The backup on the settings screen and a plan exported as JSON did nothing in Firefox. Both clicked an anchor that was never inserted into the document, which Firefox ignores. All nine download sites now go through one `triggerDownload()`, which also stops revoking the blob URL in the same tick as the click (Safari cancels the transfer under it) and makes the filename safe for a filesystem
- A plan's calendar file was named after its UUID while its PDF and JSON were named after the plan. The three formats share one name now
- The splits table saved as `splits-10-workout.png`, and said nothing at all when it had finished, or failed. `exportToPNG` no longer appends a suffix meant for sessions to the name its caller gives, and the export reports success and failure like every other export in the app
- Every screenshot and demo GIF in the README and in the PWA manifest showed the app as it was in July, before the redesign: the blue slate, the six-hue zones, the old wordmark. All thirteen are re-recorded against the repository rather than production, so a capture shows what the repository contains. The demo scenarios had to be rewired first — the library's filters left the page for a right-hand sheet whose primary button carries the result count and closes the panel, the phone menu became a full-screen dialog of `<details>` doors, and the VMA calculator's distance became a listbox
- `bun run qa:motion` caught a real fault while the films were being ported: the session timeline's track was a grey wash, and on an ink ramp a Z1 block IS a grey wash, so the first two seconds of the sweep came out invisible. The track is a card now, like in the app, and recovery inside it is hatched rather than faded — a recovery block is not a weaker effort on the ramp, it is off the ramp
- Chrome's rich install prompt showed the app from before the redesign, with a hint toast stuck in one of the frames. Those screenshots were also meant to be English, like the manifest strings, but the language was seeded under `i18nextLng` while the app reads `zoned-language`. The preparation the three capture scripts had each copied — and diverged on — now lives once, in `scripts/lib/capture-prep.ts`, and the language goes through `?lang=`, which is what the detection chain reads first
- A missed capture no longer passes silently. It left the previous run's file in place, so a half-failed pass quietly put an old image back in the README
- The README's catalogue counts had drifted behind the app: 230 running sessions, 10 plans, 16 collections and 116 glossary terms. The refreshed screenshots sat next to a table contradicting them
- The mobile menu stops sliding as it opens. Its content carried an 8px rise on top of the panel's own fade, so the six doors were still travelling under the thumb while the ink was settling. A side sheet slides because it comes in from an edge, and a dialog rises 8px because it detaches from the page; this panel has neither edge nor page behind it, it IS the screen, so it now just settles. The fade stays
- The library's practice rail only scrolls on one axis on a phone. `overflow-x: auto` does not restrict scrolling to x: the other axis computes from `visible` to `auto`, so the rail was also a vertical scroll container, 44px of viewport for 44px of content, and a vertical gesture starting on a pill was caught by the rail instead of reaching the page. The vertical axis is closed, the gesture goes back to the page, and 6px of inner padding (taken back as a negative margin, so the band's height does not move) keeps the focus ring inside the scrollport instead of clipped by it. A horizontal swipe no longer chains to the browser's back gesture either
- The home-screen icon, again, and this time on the manifest rather than on the drawing. The previous fix redrew the icon correctly but listed `app-icon.svg` first among the manifest `icons`, and that made the tile vanish entirely: since iOS 16.4 a manifest that declares `icons` is *preferred* to `<link rel="apple-touch-icon">` instead of being a fallback for it, and an iOS home screen does not lay down a vector. `sizes: "any"` answers every size Safari asks for, so Safari elected the SVG, failed to rasterise it, and installed a grey placeholder stamped with the `<title>`'s first letter — never reaching the PNG below. The manifest now declares raster icons only, and `src/lib/pwaIcons.test.ts` fails the build if a vector is put back. `public/app-icon.svg` is still generated and still checked by CI: it is the reference drawing the PNG come out of, not an icon a platform can serve
- The home-screen icon. Installed as a PWA, Zoned landed on the home screen as a near-blank white tile: the PWA asset generator took `favicon.svg`, a paper `#F6F5F2` plate meant for a browser tab, padded it by 30% and set it on pure white. Measured on the apple-touch-icon: 52% of the tile was `#FFFFFF` and the mark spanned 52% by 38%. The app icon is now its own drawing, `public/app-icon.svg`, produced by the same script as the wordmark: the same `z.`, in paper on an ink square, full bleed, no inner rounding since the system applies its own mask
- Icons carry no transparency any more. The old `pwa-*.png` were 13% transparent in the corners left free by the rounded plate, and iOS paints transparency black
- The maskable icon stays inside its safe zone, and the generator now proves it rather than assuming it: the mark is a lying rectangle, so it is its DIAGONAL that has to fit the circle inscribed at 80% of the side, and the check runs from the real outlines on every run, `--check` included
- `favicon.svg` and `logo.svg` were stale against their generator since the typography pass. Only a comment differed, but `--check` was failing on main
- The complementary activity form dragged sideways on a phone. Its body caps its height so the title and the buttons stay put while the fields scroll, and `overflow-y: auto` alone does not close the other axis: CSS turns the `visible` on x into `auto`, so the body was also a horizontal scroller. Ten pixels of travel, exactly the bleed the `Add details` summary pulls outside its text for its hover band, and a thumb finds ten pixels: any slightly diagonal swipe carried the whole form off square, labels cut on the left and the date field on the right, under a header that did not move. The bleed keeps its overhang, paid for INSIDE the container now (inline padding, taken back with a negative margin), so the fields stay aligned with the header and footer and the band even regains its symmetry, its left overhang having until now fallen outside the scroll area and been clipped. The axis stays shut for whatever overflows next
- The plan's list view fitted 388px of content into a 350px card. The session's name was crushed to 3px and painted over the badge beside it: two of five sessions were unreadable on a 390px phone
- The session menu unfurled 8px per frame from the right edge instead of appearing, and opened half off-screen when tapped near the right of a phone
- Changing a filter sent you back to the top of the page. A navigation that rewrites its own state is not a page change: the glossary, the collections and the routes all benefit from the same fix
- Nine scrolling columns crushed what they carried
- Cards inside a sheet were squashed and escaped their frame
- The floating MENU pill covered the thumb bar
- The two PWA banners stacked instead of overlapping
- Opening the menu moved focus to the first door rather than to the panel
- The vendor-radix chunk named packages that are not installed
- Three ultra sessions that duplicated the catalogue were removed

## [0.8.0] - 2026-07-29

### Added
- Adjust a catalogue workout: a button opens an editable copy where repetitions, sets, effort and recovery durations are set with a slider or typed in, with a preview that recomputes live. The source workout is never touched, the copy lands in My Workouts and links back to where it came from
- Parameter bounds read from the template itself: the range its `scaling` declares, or half to one and a half times what it prescribes. The slider spans that recommendation, the field beside it takes any value, and only the absurd is refused

### Changed
- Dragging a slider no longer floods the undo stack: one gesture is one step, however long the drag
- Sliders announce what they control and the value they hold to screen readers, which the thumb never did
- An Edit button on a personal workout's page. Reached from favourites or a bookmark, the editor was otherwise only accessible by going back through My Workouts

### Fixed
- A personal workout's link led nowhere for its recipient: the copy-link action, the QR codes on the four share visuals and the Strava footer all pointed at an id that exists only in its author's browser. The link now carries the workout itself
- A copied workout's English name is no longer wiped by the first keystroke in the name field

## [0.7.6] - 2026-07-29

### Added
- Third-party licence notices at `/licenses.txt`, linked from the footer and regenerated at every build from the 209 packages the bundle actually ships
- A validator for the workout format that fails the build and CI on a malformed session, with a `--file` mode so a contributor gets an answer in two seconds instead of a failed deploy
- A pull request gate running typecheck, the test suite, FR/EN parity and the workout schema; nothing checked a contribution before it reached `main`
- A full format reference in `docs/workout-format.md`: file shapes, id prefixes, the three axes, the step tree, zone specs, trail fields and a worked example

### Changed
- All 239 workouts now carry a machine-readable structure on their three phases, up from 34 on the main set alone; the timeline no longer has to re-read a French sentence to know what a session is
- The multiplier reads `7 × 400m` everywhere, where two competing conventions were in use
- Third-party terms are documented, including the Garmin FIT SDK, which is proprietary rather than open source and restricts redistribution

### Fixed
- Recovery texts rendered in French on English pages: `recovery` was a French-only field, and the derived structure had no English twin
- The zone distribution kept its labels until a reload when switching FR/EN, while the page title changed immediately
- `/licenses.txt` and other static files were swallowed by the single-page routing fallback
- Seven workouts announced a repetition range their own data contradicted, `6-8x` against a stored 7
- `END-022` ran to 76min against a declared 60-75: its 20-second strides were stored as a full minute
- Elevation, gradient, terrain and English descriptions were dropped when a custom workout was saved
- Language is now derived from the URL and every page canonicalises to itself
- The advertised catalogue counts no longer matched the real one

## [0.7.5] - 2026-07-26

### Added
- Social previews for crawlers that never run JavaScript, with metadata specific to each key route; links to zoned.run previewed as a bare URL on X, LinkedIn, Slack, Facebook and Discord
- Six English share cards, one per section: site-wide, library, calculators, plans, learn and race simulator
- Community health files: security policy with private vulnerability reporting, code of conduct, Sponsor button and a contact-link issue chooser
- PWA install screenshots for both desktop and mobile form factors, plus manifest categories, so Chrome shows its rich install prompt

### Changed
- Icon set migrated to Material Symbols Sharp at weight 600, with a single source of truth for category glyphs and a graded gauge for difficulty
- PWA manifest and README screenshots switched to English; the app still follows the browser locale
- README counts and feature list brought back in line with the product: 219 running sessions, share-by-link, the ten curated weeks, the race-day run sheet and the comparison pages
- The build now fails on a stale or hand-edited generated icon file instead of shipping it

### Fixed
- Social crawlers saw no metadata at all: `<SEOHead>` only runs client-side, and the prerender pass does not run on Vercel
- The sitemap listed slugs by hand and they had drifted. Two dead URLs were submitted to Google while nine real pages never were
- Curated weeks, the workout draw, the route generator and the track finder were missing from the sitemap
- `llms.txt` pointed at two plan slugs that do not exist, still described the retired quiz, and undercounted the catalogue
- The week board hint named a gesture nothing implements, and picked its wording from viewport width rather than pointer capability
- Icons: solid star and heart states, the dropdown radio indicator, and the fartlek and upper-body glyphs

## [0.7.4] - 2026-07-25

### Added
- Four curated weeks: first steps, hill block, peak week and race-pace week, filling the previously empty "peak" category
- Nine catalogue sessions: volume endurance for advanced and elite, negative-split and strides endurance, recovery for advanced and elite, and the first two beginner trail sessions
- GitHub Releases are now published automatically when a version tag is pushed, using the matching changelog section as the release notes

### Changed
- The plan generator drives weekly volume from its own model instead of summing whatever sessions were drawn, so the planned progression reaches the runner
- Quality work is weighted by race distance: VO2max for 5K and 10K, threshold and race pace for half marathon and marathon, hills for trail
- Four-day plans schedule two quality sessions per week instead of one, which a single session could not cover
- The marathon plan moves to five sessions per week, what an 80 km peak alongside a 31 km long run requires
- Return-to-running plans now progress across their cycle instead of starting at their own peak
- Curated weeks declare the volume their sessions actually add up to

### Fixed
- VO2max sessions were annotated and costed at easy pace: zone strings such as "Z5+" silently fell back to Z2
- The session page contradicted itself on zones, durations and headings; a single zone parser now backs all of them (166 of 230 templates affected)
- Peak weeks could not carry their volume and ended up lighter than base weeks
- Race week no longer prescribes 9-minute jogs, and no week repeats the same session twice
- Plan audit checks weekly volume in kilometres instead of a model percentage that progressed smoothly whatever the plan delivered

## [0.7.3] - 2026-07-25

### Added
- URL sharing for custom workouts, training plans, race simulations and calculators
- Lock a session and re-roll the rest of the week; session removal made discoverable
- "Race day" view on the race simulator: chronological run sheet, next-up card with countdown, and a "now" marker in the timeline
- Anchor navigation with scroll-spy on the race simulator
- Pace curve for negative and positive split strategies
- Kit bag checklist on the race simulator (it was generated for the PDF only)

### Changed
- Race simulator reworked into two columns: sticky settings folding into a summary bar, plan in a card grid, PDF export promoted to the primary action
- Split table adapts to the strategy: one summary line for even pacing, table plus curve for negative and positive
- Race simulator warm-up is now a timed checklist; per-exercise durations added and the block total corrected from 18 to 28 min
- Single target-time field (mm:ss / h:mm:ss) replacing three native steppers
- Nutrition states the no-carb case as advice instead of "0 g / 0 gels"; hydration rounded to 50 ml
- Desktop week board reworked: natural column heights, explicit Rest cards, zone and load on every session card
- Intensity colours unified into one table shared by the week board, the plan calendar and the workout picker
- Coach copy on the race simulator unified on tutoiement

### Fixed
- Split table sticky header no longer covers the first rows
- Warm-up was scheduled at a hardcoded -30 min that did not match its real duration
- Mental cues no longer repeat their km range in the text
- Desktop week generator CTA stays anchored at the bottom of the rail instead of falling off screen
- Plan generation is now seeded from its config, so a shared plan regenerates identically for every recipient

## [0.7.2] - 2026-07-20

### Added
- Categories on saved weeks (inherited from prebuilt weeks) with a badge and filter chips on My weeks
- Duplicate a saved week from the list (completion tracking reset on the copy)
- Share a week as a compact encoded link with a preview page and "Add to my weeks"
- Import a week from a JSON file on My weeks

### Changed
- Week card actions grouped into an overflow menu; week page header reworked around a category badge

### Fixed
- Multiple sessions on the same day now count in weekly stats and stack in the rhythm chart
- Duplicated or imported weeks appear immediately without a page refresh

## [0.7.1] - 2026-07-20

### Added
- "Share on Strava" copy-to-clipboard button on session pages
- Command Palette extended to more product surfaces
- Multi-scenario demo GIFs in the README (plans, calculators, mobile)

### Changed
- Homepage reordered around plan generation: benefit-led hero copy, "Generate my plan" as primary CTA, Plans section moved right after the entry points
- Plans dashboard separates ended plans from active ones
- Card grids gain mobile-first interactive motion (tap feedback, hover lift and glow)
- Keyboard shortcut hints follow the OS (Ctrl on Windows/Linux, Cmd on macOS)
- Retired quiz and dead workout-of-the-day/onboarding code removed

### Fixed
- Top bar no longer overflows at mid-size viewports: it collapses to the hamburger below 1024px, with an adaptive search trigger
- Homepage calculator cards share equal heights, explore link pinned to the bottom
- Mobile-first audit issues resolved (#96-#106)
- Sticky table headers pin inside their card instead of the viewport

### Performance
- Space Grotesk self-hosted, render-blocking Google Fonts chain removed
- Entry bundle split: locales, react-dom and command palette in separate chunks
- Library fetch deferred out of the LCP window, all animations composited
- Lighthouse CI performance budgets, footer CLS fixed on short pages

## [0.7.0] - 2026-06-03

### Added
- "My week" mode: a polarised 80/20 week generator composing 3-6 complementary sessions, with a week editor (7-day board, 80/20 balance gauge, week rhythm) and an animated automatic generation
- Pre-built weeks: sourced template weeks (aerobic base, threshold block, VO2 sharpening, recovery, high volume, easy return) with pedagogical "why this week" and "why this session" notes
- "Draw a session" page: random session draw from filters (discipline, zones, duration, level) with a searching animation

### Changed
- Weeks page (/weeks) and its creation flow now match the plans design (cards, badges, mini-stats, View/Export actions)
- Mobile-first week editor: summary strip above the board, settings always accessible, board never compressed
- Learn and Collections pages aligned with the Calculators hub layout
- Session detail page given more breathing room for better mobile readability
- FR/EN i18n and SEO finalised on the week pages

### Fixed
- Library duration filter no longer hides long sessions
- Drawn session kept across navigation
- Sidebar footer links no longer overflow on mobile (2x2 grid)

## [0.6.1] - 2026-05-28

### Added
- Share dialog with Strava-style template carousel and 17 workout templates (bilingual PNG export)
- Editorial OG share card with live stats in a square format optimised for social previews
- SEO: enriched JSON-LD across all pages plus `llms.txt` for AI crawlers
- React 19 native meta hoisting (replaces `react-helmet-async`)
- Sitemap generator rewritten and prerender hardened for React 19

### Changed
- Home hero CTA swaps to "View my plans" when the user has saved plans
- Deploy strategy: Vercel builds at runtime instead of serving a committed `dist/`
- Dropped `react-helmet-async` dependency (lighter bundle)

### Fixed
- Toast position pinned top-center on mobile so it no longer overlaps action buttons
- Vercel SPA rewrite `/(.*)` → `/` so client routes stop returning 404
- Share on iOS Safari: `Promise<Blob>` in `ClipboardItem` and dropped title from native share (Instagram)
- PWA: `skipWaiting` + `clientsClaim` so mobile clients receive fresh content immediately
- Accessibility: heading order, aria labels and WCAG AA contrast tweaks
- Learn page: stagger grid remounts on filter change so cards stay visible
- Build: sitemap generated before `vite build` so it ships in `dist/`
- Prerender no longer hits a retry storm on Vercel (trusts captured HTML instead of `waitForFunction`)

## [0.6.0] - 2026-05-27

### Added
- Editorial landing rewrite: home redesigned as a "training journal" with full-bleed sections, real researcher sources, accordion FAQ, and reusable card primitives
- Daily rotating quote on home from real athletes & coaches (deterministic by day)
- Top navigation rework with hover dropdowns + redesigned mobile sheet
- Sidebar with collapsible groups + persisted open/closed state across sessions
- Global Footer promoted from the landing page (FR/EN switcher visible on mobile, compact 3-column layout)
- Open-source README with live GitHub stats (stars, issues, last commit) and badge

### Changed
- Editorial header propagated across the whole app in 6 waves: calculator pages, hub pages (wave 1), article-like pages (wave 3), detail pages (wave 4), utility pages (wave 5), forms/builders
- Workout detail page refactored with progressive disclosure (editorial tone, less visual noise)
- Home colour pass: punchier hero, signalled cards, decorative borders removed
- Calculators hub grouped into 3 sections with an airy single-column layout on mobile
- HomePage atoms extracted and reused on LibraryPage for consistency
- Home mobile compaction: §04/§05 now match the §06 grid pattern
- Home: subtle motion + readability polish, trailing periods dropped on section titles, em dashes adopted

### Fixed
- About workouts count now includes cycling + swimming sessions (not only running)
- About page live stats wired to the actual catalogue counts
- Footer 3-column layout no longer breaks on narrow mobile screens

## [0.5.4] - 2026-05-11

### Added
- New `trail` workout category with 10 sessions (TRL-001 → TRL-010): hill sprints, VO2max hills, power hills, sustained tempo climb, controlled downhill repeats, sustained climbing endurance, rolling endurance, specific long run, back-to-back day 1 and day 2
- `elevationGainM`, `gradientPercent`, `terrainType` fields on `WorkoutBlock` (terrain: road / trail_runnable / trail_technical / mountain)
- `MiniElevationProfile` SVG component with smart oscillation detection for hill repeats
- `workoutMetrics.ts` helper (D+, D−, avg gradient, dominant terrain, vertical density, trail metrics)
- D+/gradient/terrain backfill on all 15 hills workouts and 10 other hilly endurance workouts (END-004, END-009, SL-005, SL-006, LR-016 ultra time-on-feet, TMP-010, RP-005, MIX-002, FAR-005, THR-011)
- Trail stats banner on WorkoutDetailPage (D+ total · D− total · vertical density · avg gradient · dominant terrain)
- D+/terrain badges on WorkoutCard (Grid + Focus), D+ on WorkoutCardCompact and WorkoutListItem
- Bilingual i18n trail keys (categories.trail, trail.elevationGain, trail.elevationLoss, trail.verticalDensity, trail.gradientAvg, trail.terrainType.*)

### Changed
- Plan generator prioritises `category === "trail"` workouts (+100 priority) for `trail_short` / `trail` / `ultra` race distances
- Quiz `environment: hills` answer now includes both `hills` and `trail` categories
- Route generator detects `category === "trail"` and overrides surface, terrain preference, and elevation target accordingly
- Recovery strings on hills + mixed workouts updated with parsable durations (e.g. "Descente en marchant" → "2-3 min descente en marchant")
- WorkoutDetailPage no longer shows "Hills required" environment label when trail metrics are visible (deduplication)

### Fixed
- Library infinite scroll stuck at 24 items when sentinel mounts after isLoading
- D+/km and avg gradient now count all blocks (warmup/cooldown estimated via duration × zone-pace) for honest values
- D− (elevation loss) displayed on WorkoutDetailPage, WorkoutCard, WorkoutListItem, WorkoutCardCompact for downhill or oscillating sessions
- HIL-015 descents zoned Z2 (instead of Z3) so SessionTimeline visually distinguishes climbs (orange) from descents (green)
- HIL-011 main block missing `distanceM`; added 250 m so D− computes correctly
- TRL-005 recovery "Remontée trottée souple" now carries an explicit "12 min" duration so the structure renders timing

## [0.5.3] - 2026-05-10

### Added
- Plan wizard autosave with "Resume / Start fresh" banner on reload
- Undo/Redo in workout builder with Cmd+Z / Shift+Cmd+Z keyboard shortcuts
- Reusable hooks: useZoneColors (multi-discipline), useUndoRedo, usePlanDraft
- ResponsiveTable component (desktop table → mobile cards) and PageContainer layout primitive
- Contextual skeleton composites (WorkoutCard, PlanWeek, Table, Article) with shimmer effect
- EmptyState variants (no-results, not-started, error, offline)
- Tailwind `tablet:` breakpoint (900px) plus CSS vars for cycling/swimming zones and discipline accents

### Changed
- HomePage hero accent words migrated to framer-motion (smoother rotation, no setTimeout jank)
- Library and glossary search runs non-blocking via useDeferredValue
- PDF / PNG / FIT / ICS exports show toast.loading during generation
- Sidebar entry "Create" → "Create workout" for clarity
- WCAG touch targets: icon buttons reach 44×44 px on coarse-pointer devices
- `index.css` split into 5 focused modules (tokens / themes / palettes-a11y / animations / overrides)
- Sticky thead on scrollable tables; VMA and race-equivalence tables render as cards on mobile

### Fixed
- Plan draft was wiped on mount under React Strict Mode (silent data loss)
- Hardcoded cycling/swimming hex colors migrated to CSS vars (multisport-ready)
- iOS input auto-zoom mitigated architecturally via pointer:coarse media query
- "Zoned" logo now visible from tablet width (md:inline) instead of ≥ 1024 px
- Removed orphan `Header.tsx` (537 lines, no importers)

### Performance
- Shimmer skeletons via react-loading-skeleton (~5 kB gz)
- No LCP regression: /library at 1572 ms, CLS 0.00

## [0.5.2] - 2026-05-10

### Added
- Nutrition hub at `/nutrition` with 14 beginner-friendly sections (1:0.8 carb ratio, protein 1.8 g/kg, AIS-classified supplements, cramps science, heat acclimation, female-specific needs, 10 debunked myths, FAQ)
- 17 supplements ranked by Australian Institute of Sport framework (A through D) with dose, timing and rationale
- 10 false beliefs dismantled in an interactive accordion (30-min window, 4:1 ratio, magnesium for cramps, coffee dehydrates, etc.)
- "Nutrition" sidebar entry under Learn, between Articles and Glossary
- New visual primitives: RatioGauge, MythBuster, ProteinTimingChart, GutTrainingTimeline, SupplementGrid with AIS badges, CrampsScience, WomenInsightGrid, HeatGrid
- Coffee, Pill, Wheat, Snowflake icons added to inline icon library

### Changed
- Protein recommendations updated: 1.4-2.2 g/kg/day based on training volume (Witard 2025, Sports Medicine); previously 1.2-1.8
- Glucose:fructose ratio modernized: 1:0.8 above 60 g/h (Rowlands 2020); previously 2:1
- Carb loading: 36-48 h at 10-12 g/kg (modern protocol); 3-day method obsolete
- Post-effort recovery window debunked in calculator and guide: real window is 4-6 h glycogen / 24-48 h protein, not 30 min
- 4:1 carb:protein recovery ratio noted as myth (Margolis 2021): the apparent benefit comes from added calories
- Calculator caffeine guidance: cite genotype CYP1A2 sensitivity

### Fixed
- Fueling calculator gel count now realistic: split 60% gels / 40% sports drink (previously counted 14 gels for a 3h30 marathon at 80 g/h, now 7)
- Sources updated across guide and FAQ to cite Rowlands 2020, Witard 2025, Aragon 2013, Margolis 2021, Schwellnus, Paulsen, Trommelen 2023

## [0.5.1] - 2026-05-10

### Added
- On-line trace editor: drag waypoints, click to insert/remove, denser handles and distinct start/end markers for out-and-back vs loop
- Track Finder page: lists nearby athletics tracks and routes a there-and-back leg, with VMA-aware boost in the recommendation engine
- Map editing affordances: direction chevrons, click-to-pick start, compass bearing, expand and reverse
- Elevation target with discipline-aware recommendation engine and athletics tracks as POI for VO2max/VMA sessions
- Launch the route generator from a planned session or workout with the discipline preset already filled
- Swipeable news spotlight on the homepage (touch + mouse drag, sliding strip, pointer events)
- How-it-works details on the route generator page

### Changed
- Premium desktop one-page layout for routes (Strava-style strip, collapsible details, sticky CTA, dense top toolbar); no scroll, footer hidden
- Mobile UX rebuilt around a map-first persistent card with candidate cards, slim 3-row top bar (chips + address + CTA) and Strava-style search row
- Discipline-aware duration estimate replaces Brouter total-time, with a 200 km cap on cycling
- Single distance chip, action bar split, h3 stats, elevation tooltip and sidebar sub-items in the route generator UI

### Fixed
- Reject sea-bound legs and surface a specific error when Brouter returns 400 on an unreachable waypoint
- Restore Leaflet tile sizing under Tailwind v4 preflight
- iOS input zoom hardened across mobile route forms; address dropdown lifted above the map
- Exact preset distance on tap so 21.1 km and 42.2 km stay marked active
- Select-all on focus for distance and elevation inputs
- Elevation chart stays proportional via CSS aspect-ratio instead of stretching flat on wide containers
- Missing i18n keys on the about page and `view.findWeekRoute`
- Bike icon used consistently for cycling tabs and slides; `?type=` filter routing fixed

### Performance
- Parallelize route candidates with Brouter timeout/retry and runtime validation; debounce drag re-route (123 s → 10 s)
- Brouter LRU cache and Overpass dedup with `idb-keyval` persistence (TTL 7 days)
- Routes storage migrated to IndexedDB; desktop map column capped to viewport
- Extract convergence/PRNG/scoring helpers and `useRouteEditor` hook (RouteGeneratorPage 1100 → 952, recommendation 669 → 560)

## [0.5.0] - 2026-05-06

### Added
- **Route Generator**: build a real-world loop or out-and-back from your position with Brouter routing, GPX export, and locally saved routes
- POI-aware routing: waypoints picked from parks, promenades, greenways, beaches and trails via Overpass API (with triangulation fallback for rural areas)
- 3 route candidates per request: pick the trace you prefer with named POI markers and elevation profile
- Privacy toggle in Settings to opt-out of the route generator entirely
- Multi-discipline foundation: cycling and swimming workouts, FTP/CSS zones, cross-discipline substitution in plans
- 10 cycling templates and 10 swimming templates spanning long endurance, sweet spot, threshold, intervals, technique work and pyramids
- Cycling/swimming pace engines and cross-discipline TSS in plan generator
- Discipline-aware filters and color palette in library and timeline
- Commute (vélotaf) settings tab in profile
- FTP and CSS guided test pages with Coggan / CSS zone previews

### Changed
- Multi-trace overlay on the route map: candidates render in distinct colours and dash patterns so they stay distinguishable when their tracks overlap
- Route candidates sorted by distance accuracy (best match first); off-target results (>20% deviation) are rejected
- Discipline filter tabs in library wrap on mobile to avoid horizontal scroll

### Fixed
- Route candidates were all falling on the same waypoints; diversification by seed now ensures distinct proposals
- Geolocation errors surface clear messages when blocked, denied or timed out
- Z>6 zones clamp to Z6 and use sport-specific paces for distance-only segments
- Substitute session preserves discipline through localStorage round-trip
- Running-only filters and stats scoped to running discipline
- Hide running-pace footer on cycling/swimming sessions

## [0.4.4] - 2026-04-13

### Added
- Intermediate race goals in training plans with priority A/B/C and distance-aware coaching (#44)
- One-click auto-fix for audit warnings (key session spacing, volume jumps, recovery weeks, taper)
- Duplicate day session detection in plan audit
- Post-recovery volume jump detection (compares to last non-recovery week)
- Structured workout phases with nested interval details in session view
- Race duration estimation for intermediate races (distance + runner level + trail penalty)

### Fixed
- False positives in plan audit (race sessions counted as key sessions)
- Recovery week volumePercent showing 65% regardless of progression (now relative to peak)
- Volume jump threshold too strict due to integer rounding (20% -> 21%)
- Volume jump warning on low-volume plans like return-from-injury (skip when both weeks < 55%)
- Weekly km not rounded in stats chart (showed raw floats like 37.346...)
- Emoji replaced with colored dot icons in audit panel

## [0.4.3] - 2026-04-12

### Added

- **Guided free plans** with phase-aware checklist, contextual tips, and week navigation across all views (#52)
- **Runner profile page** with unified training history, personal records, and fitness overview (#71)
- **Session completion sheet** with 3 choices (as planned / modified / skipped), actual duration/distance/RPE tracking (#50)
- **Unavailabilities** (blocked days) with date range picker and automatic skip-based rescheduling (#42)
- **One-click undo** for major plan changes via LastChangePanel banner and toast action (#57)
- **Multi-week adaptation engine** with preview dialog and 3-week sliding window analysis (#48)
- **Automatic plan coherence audit** with 8 checks: spacing, volume jumps, recovery/taper integrity (#58)
- **Accent-insensitive search** across library and command palette (#62)
- **Custom workouts in favorites** with add, display, and cleanup on delete (#59)
- **PWA UX** install prompt, offline indicator, and update notification (#70)

### Changed

- Session completion replaced with anchored popover (desktop/tablet) and compact bottom sheet (mobile) for less intrusive UX
- RPE and distance badges hidden on mobile session cards to prevent overflow
- Stats now use actual duration/distance when available instead of planned values
- Blocked days visible across all views (calendar, weekly, monthly, list) with hatched background
- Adaptation shows a preview dialog before applying instead of silent auto-apply

### Fixed

- Block add/move/drop on unavailable days across all plan views
- French accents in unavailability/reschedule translations
- Unavailabilities persisting correctly after rescheduling and undo
- Race simulator timeline order for early morning or late-night race starts (#63)
- Date display and input aligned with app language using custom DatePicker (#73)

## [0.4.2] - 2026-04-11

### Added

- **Explicit start date in assisted plan creation**: choose between "Start now" or a specific date, properly honored end-to-end from generation to exports
- **Complete backup/restore** with explicit Merge/Replace choice, covering race simulations and what-if scenarios
- **Unresolved sessions recap** when validating a week, with an explicit "Mark as skipped" / "Leave unresolved" choice (no more silent auto-skip)

### Changed

- Removed the 5-plan cap and tightened import validation with schema domain guards (volume percent bounds, max 104 weeks)
- Weekly mileage stats now prefer the most reliable distance data available (actual > target > estimation)
- **i18n architecture overhaul**: full migration from `isEn` ternaries to i18next `t()` / `pickLang` helpers, extraction of `homepage`, `content` and `calculators` namespaces from `common.json`, and a new FR/EN parity check script (`bun run check:i18n`)

### Fixed

- Assisted plan generator now respects the chosen start date when computing total weeks (previously used today's date)
- Week validation modal is now responsive across mobile/tablet/desktop; buttons no longer overflow on narrow or medium viewports
- Skipped sessions no longer inflate weekly mileage stats
- Backup restore now rolls back atomically on failure (e.g. localStorage quota) instead of leaving a partial state and showing a misleading success toast
- Plan save handles localStorage quota errors gracefully with a clear error toast instead of silently failing

## [0.4.1] - 2026-04-10

### Added

- **Professional plan PDF export**: compact 6-column weekly tables with colored zone cells, workout deduplication appendix with clickable internal links, dark title banner, and structured metadata
- Display distance (km) alongside duration in plan sessions

### Changed

- Use h:mm duration format (e.g., "1h59") for durations >= 60 minutes across the entire app (plan views, workout cards, stats, search results, PDF export)
- Multi-select chip filters with progressive disclosure in library

### Fixed

- Incorrect volumePercent scaling in workout duration calculations
- Plan generator volume adjustment for days/week and reduced progression rate
- ICS plan export day mapping and strength session handling
- Toggle + week change interaction bug
- Sidebar separator and plan methodology page renamed to guide

## [0.4.0] - 2026-04-06

### Added

- **Strength training for runners**: 46 exercises across 5 categories (lower body, core, plyometrics, mobility, upper body) with A/B position images, muscle group maps, and form cues
- **17 structured strength sessions**: full body, legs, core, plyometrics, mobility, and prehab; science-based periodization (Beattie 2017, Rønnestad 2014, Lauersen 2014)
- **Library toggle**: Course / Renforcement / Tout filter with adaptive sidebar filters per activity type
- **Strength workout detail page**: exercise list with images, muscle timeline visualization, interactive body muscle map, intensity badges, and scientific references
- **Plan integration**: auto-suggested strength sessions with phase-appropriate periodization (opt-in toggle + frequency selector in plan creation wizard)
- **Prebuilt plans**: all 9 plans now include periodized strength sessions (143 sessions total)
- **3 strength collections**: Force pour coureurs, Core stability, Prévention blessures
- **Strength section on homepage** with 3 featured sessions
- **Strength in plan panel**: dedicated "Renforcement" tab with all 17 sessions for manual addition
- **Favorites support** for strength sessions
- **Exercise image zoom**: click-to-enlarge modal with keyboard navigation
- Exercise illustrations credited to free-exercise-db (Public Domain / Unlicense)

### Fixed

- Scrollbar styling
- Sticky filter bar removed on library page
- Plan stats infinite loader when plan contains strength sessions
- Zone distribution computation skips non-running sessions

## [0.3.4] - 2026-04-04

### Added

- SEO: structured data (Organization, FAQPage, HowTo, ExercisePlan), enriched meta descriptions, BreadcrumbList on all pages, nginx bot prerendering
- Sticky mini-timeline on workout detail page: compact zone bar follows scroll with workout name and duration
- Prebuilt plan "Reprise après longue pause": 10-week progressive plan for returning after months off
- Cross-content links on workout, article, and glossary detail pages (related articles, workouts, glossary terms)
- Unified search in command palette: search workouts, articles, and glossary terms with section headers
- Plan progress sparkline: SVG weekly volume chart colored by training phase on plan cards
- Interactive zone legend on calculator: expandable accordion with sensations, benefits, and example workouts per zone
- Contextual breadcrumb trail on workout detail page with zone-colored accent and journey awareness
- Card peek preview: always-visible compact session timeline on workout cards
- Post-completion RPE feedback with zone-colored gradient bar (1-10 scale)
- Skeleton loading states with zone-shimmer animation
- Animated empty states for Plans, Favorites, and Library pages

## [0.3.3] - 2026-04-03

### Added

- Plan methodology page: explains the 7 evidence-based principles behind plan generation (periodization, 80/20, recovery weeks, volume progression, long run, session types, taper)
- What-if training scenario simulator: compare two training scenarios side by side with volume, zone distribution, and qualitative insights
- Inline plan name editing and refactored plan export menu (#39)

### Fixed

- Session timeline visualization now correctly estimates duration from distance-based blocks (distanceM), fixing 69 blocks across 6 workout files
- Normalize plan start date to Monday in getCurrentWeek

## [0.3.2] - 2026-03-28

### Added

- Finish time input mode in plan creation: toggle between target pace (min/km) and target finish time (H:MM:SS), with automatic conversion (#29)
- Level descriptions across the app: each difficulty level (beginner, intermediate, advanced, elite) now shows concrete frequency and weekly volume expectations (#28)
- Plan context banner on workout detail page: when viewing a session from a plan, shows the scaled duration based on the week's volume percentage (#32)

### Changed

- Plan duration warning redesigned: now shows specific risks (mental fatigue, overtraining) and suggests alternatives instead of a vague "not recommended" message (#27)
- Stats section: "Distance par semaine" renamed to "Kilométrage hebdomadaire" and "Volume par semaine" renamed to "Temps d'entraînement hebdomadaire" with descriptive subtitles (#30)

### Fixed

- Navigating back from a workout detail page now returns to the correct week in the weekly plan view instead of resetting to week 1 (#31)
- Workout detail page now displays the plan-scaled duration when accessed from a plan, instead of always showing the base session duration (#32)

## [0.3.1] - 2026-03-28

### Added

- "Why it works" science section on each workout detail page showing physiological rationale, zone explanations, expected adaptations and scientific references (Billat, Seiler, Daniels, etc.)
- Coaching tips moved to sidebar for better content hierarchy
- SEO comparison pages (Zoned vs Runna, Kiprun Pacer, Campus Coach)
- Calculators added to header navigation and mobile menu
- Library page: responsive grid, compact/focus view modes and quick filters
- Unsaved changes warning before leaving workout builder

### Fixed

- Improved touch targets, mobile responsiveness and interaction consistency
- scaledReps only applies to blocks with repetitions, prevents duration explosion
- Mobile tap opens context menu correctly, prevented text selection on long-press, show RPE in weekly view

## [0.3.0] - 2026-03-26

### Added

- Plan generator v2: Daniels-based pace engine, Pfitzinger long run progression, Mujika exponential taper model
- Session completion tracking: planned/completed/skipped cycle with RPE input, week validation and automatic volume adaptation
- 5 new prebuilt plans: 5K beginner, 5K intermediate, 10K beginner, 10K intermediate, return from injury
- Non-race plans: base building, return from injury and beginner start with adapted goals
- Enhanced statistics: weekly distance chart, 80/20 easy/hard split, training load, long run progression, completion rate
- Pace annotations (paceNotes) on each session with Daniels zones and min/max ranges in min/km
- Progressive scaling (intensityType, weeklyFrequencyMax, minimumRecoveryDays) across all 200 workout templates
- 4 plan view modes: Calendar (full table), Weekly (navigable agenda), Monthly (real-date calendar) and List
- Day-of-month numbers and inline month boundary markers in calendar cells with current day highlighting

### Changed

- Plan creation wizard redesigned with dynamic steps based on goal (race, base building, injury return, beginner)
- Marathon, half-marathon and base building prebuilt plans enriched with paces, load scores and distance targets
- Performance optimization: memo() on heavy components, theme managed via ref + custom event
- View mode selector persisted in localStorage and responsive-aware (Calendar and Monthly desktop only)

### Fixed

- Fixed invalid sessionType values in workout data (vma, mixed, hills, race_pace)
- Weekly km now updates dynamically when sessions are added, deleted or moved
- Fixed date anchoring: calendar days align to the Monday of the plan start week

## [0.2.3] - 2026-03-22

### Added

- Race day simulator: enter distance, target time and start time to get a complete race day plan (wake-up, breakfast, warmup, km-by-km pacing, nutrition, checklists) with PDF export
- Mobile onboarding reworked: inline card replaces broken positioned bubbles, contextual toast hints on first visit to library, plan calendar and workout builder
- Long press (mobile) and right-click (desktop) context menu on plan calendar sessions with "View session" and "Delete" actions, haptic vibration on mobile
- Glossary terms auto-linked (clickable) in methodology page and nutrition recommendation sections
- Delete button with confirmation dialog on workout list view in builder
- Import/export custom workouts as JSON files, "Create" button renamed for clarity
- App automatically reloads when a new version is available (PWA service worker update)

### Changed

- Sidebar navigation restructured into task-oriented groups: Discover, Training, Sessions, Plan

### Fixed

- Recovery section open by default in race simulator
- Favorites page header size aligned with other listing pages
- Improved plan PDF and ICS export quality

## [0.2.2] - 2026-03-20

### Added

- Data export and import in settings: backup all your data (favorites, plans, settings, zones) as JSON, restore from a backup file
- Storage persistence warning: first-time dialog when saving favorites or creating a plan, explaining that data is stored locally
- Privacy-first positioning: visible badges on homepage hero, privacy note in footer, dedicated privacy section in settings
- Ko-fi support link in footer and about page
- SEO: H1 heading, intro text and JSON-LD WebApplication schema on Zones and Pace calculator pages
- SEO: 53 new routes in sitemap: collections, prebuilt plans, calculators, methodology, guides (318 → 371 URLs)
- SEO: JSON-LD WebApplication schema on all 9 calculator pages
- SEO: BreadcrumbList JSON-LD on Article, Collection and Prebuilt Plan detail pages
- SEO: enriched Article JSON-LD with author, publisher, datePublished and dateModified
- SEO: updated default OG image with current stats (200 workouts, 9 calculators, "No Account Needed")
- SEO: prerender English pages and hreflang alternate links in sitemap
- About page redesigned with personal section, updated stats, contact links (Strava, GitHub)
- Custom workout builder: create, edit, save and export your own workouts with warm-up, main set and cool-down blocks
- Custom workouts integrated into library, search, favorites and training plans
- FIT export guide: step-by-step transfer instructions modal after Garmin export, with OS detection and non-Garmin alternatives
- Quiz improved from 3 to 5 questions: added experience level and weakness, now shows 6 results
- Cross-training activities (strength, cycling, swimming, yoga, rest) available in plan workout panel as regular sessions
- First-visit onboarding: 3-step guided bubbles highlighting library, quiz, and plans with progress indicator

### Changed

- README updated to reflect 200 workouts, 9 calculators, privacy-first philosophy, and current feature set

### Fixed

- Date inputs on mobile: larger touch targets (44px minimum), text-base font to prevent iOS zoom, locale-aware lang attribute, "Start now" / "Choose a date" toggle on free plan creation
- Duration filter range extended to 0-240min to include all workouts (previously 10-180min excluded ultra sessions)
- Workout builder: export and delete buttons now appear immediately after first save

## [0.2.1] - 2026-03-19

### Added

#### Workouts
- 19 new science-based workouts to reach 200 total: Norwegian 4×4 (Helgerud), Tabata, R-Pace (Daniels), CV Tinman, Over/Under, Canova Progressive, Hanson Strength Run, Tempo with surges, heat acclimatization, Train Low, DFA alpha1, cardiac drift durability, ultra time-on-feet, broken race, Canova extensive, plyometric circuit, Hudson 1-2-3-2-1, 3-min all-out test, lactate step test

#### Glossary
- 2 new glossary terms: Critical Velocity (CV) and Surge, with auto-linking in workout descriptions

#### Plans
- Interactive calendar view for training plans with week × 7 days grid, mobile week navigation, and colored phases
- Native drag & drop to move sessions between days (desktop and mobile with visual ghost)
- Workout library side panel to add sessions via drag (desktop/tablet) or tap (mobile) with search and category filters
- Free plan mode: create a blank plan (name + week count) and place workouts manually
- Plan import/export as JSON to share or backup your plans
- Delete sessions from both calendar and list views with trash button
- 8 pre-built ready-to-use plans: 5K beginner/intermediate, 10K beginner/intermediate, half-marathon, marathon, base building, return from injury
- Optional start/end dates on free and pre-built plans, editable at creation and afterwards
- Enhanced statistics section with 8 metrics, weekly volume chart, zone distribution (Z1-Z6), target system breakdown, and collapsible accordion

#### UX
- Inline "+" buttons in each day cell (mobile) and each week (list) to quickly add sessions
- Contextual hints in library panel: drag, click or tap depending on display mode
- Click on a session in calendar view navigates to workout detail (with "Back to plan" link)
- Compact mobile layout for plan creation cards (no scroll) and prebuilt plan grid (2×4)

### Changed

- Quiz and plan creation refactored to full-viewport steps (one question per view, no scrolling on mobile)
- Delete plan button replaced by action menu (export JSON + delete)
- Homepage section spacing reduced for better visual rhythm
- Background preloading of sidebar pages for instant navigation
- 5-plan limit indicator with hidden creation buttons when limit is reached

### Fixed

- Dark mode compatibility: timeline colors, segments without zones, and recovery sessions
- Mobile navigation flash eliminated by deferring sidebar close to after page render
- Fixed session index in sorted list view (delete/replace targeted the wrong element)

## [0.2.0] - 2026-03-19

### Added

- Methodology page: scientific foundations of the 6-zone system with 8 researchers, 6 studies (PubMed links), reference books, blogs and podcasts
- New editorial design inspired by Google Stitch: homepage with asymmetric hero, bento grid stats, cards with zone-colored top border
- Workout detail page: bento header with metrics grid (duration, difficulty, target system, environment), prominent export buttons, favorite in top right
- Redesigned Workout of the Day: bento layout with large duration, coaching tips in right column, fully clickable card
- Enlarged session timeline visualization (h-40/h-56) with zone labels on hover and better segment contrast

### Changed

- Replaced zone-stripe (left colored border) with colored top borders on all cards (workouts, collections, articles)
- Mobile responsive: reduced sizes on mobile for hero, stats, buttons and workout of the day
- Removed redundant Details card from workout page sidebar

### Fixed

- Display recovery between repetitions in phase details (3x30s, fartlek, etc.) without redundancy with description
- Inter-series rest indication for multi-set blocks (e.g. 2x(10x 45s VO2max / 15s recovery) → ~3 min jog between sets)
- Missing 'Mythic Workouts' collection on homepage (missing accent in slug)
- Segments without zone (drills, transitions) invisible in timeline; fallback color fixed

## [0.1.7] - 2026-03-18

### Added

- Wikipedia-style auto-linking: all 200+ glossary terms and 12 articles become clickable throughout the entire app with hover previews
- Automatic links to learning articles (periodization, supercompensation, warm-up…) with inline preview
- Unified preview popover for desktop and mobile: close button, link to full page
- Callout blocks in all 12 articles: tips, warnings, key takeaways and statistics
- Reading progress bar and table of contents (desktop sidebar, mobile dropdown) in articles

### Changed

- Replaced dangerouslySetInnerHTML in articles with secure React components

### Fixed

- Back button on glossary pages now returns to the previous page (not always to the glossary)
- Mobile button touch targets enlarged to 44px (Apple HIG standard) without visual overflow
- Comprehensive French accent and spelling corrections across the entire application
- Improved footer and sidebar layout (alignment, responsive)

## [0.1.6] - 2026-03-17

### Added

#### Glossary
- 3 new glossary categories: Biomechanics (12 terms), Injuries & Prevention (10 terms), Nutrition (17 terms)
- 39 new bilingual glossary terms covering stride mechanics, common running injuries, and sports nutrition
- Nutrition terms include: isotonic drinks, maltodextrin, glucose-fructose ratio, BCAAs, caffeine, vitamin D, iron deficiency

#### Calculators
- New `/calculateurs` hub page with 7 running calculator tools
- Race equivalence calculator (predict times across distances)
- Age-graded performance calculator (compare performances across ages)

#### SEO
- Post-build prerendering of all 318 pages via Puppeteer for non-JS crawlers
- Enriched JSON-LD structured data on workout pages (ExercisePlan + BreadcrumbList)
- Enriched JSON-LD on glossary term pages (DefinedTerm + BreadcrumbList)
- WebSite schema with SearchAction on homepage (enables Google sitelinks search box)
- CollectionPage and DefinedTermSet schemas on listing pages
- SEOHead component now supports multiple JSON-LD blocks
- New `build:seo` script combining build + sitemap generation + prerendering

#### Features
- Copy link button on workout detail page

### Fixed

- Sitemap generator now correctly reads glossary `.ts` files (was looking for `.json`, finding 0 terms)
- Sitemap expanded from 175 to 318 URLs (added guides, collections, calculators, all glossary terms)
- Workout of the day: hash-based seed for stable selection across catalog changes
- Workout of the day: selection no longer shifts when workouts are added/removed
- Plan generation: limit check now runs before generation instead of after

## [0.1.5] - 2026-03-14

### Added

#### Navigation
- New collapsible sidebar navigation (Notion/Linear-style) with 3 states: expanded, collapsed, mobile sheet
- Minimal top bar with logo, centered search, and quick actions
- Sidebar with grouped sections (Training, Discover, Tools) and tooltips in collapsed mode
- Smooth collapse/expand animation with unified CSS transitions
- Sidebar state persistence (collapsed/expanded) in localStorage

#### Community Contribution
- Community contribution form with two modes (quick idea / full workout)
- 4-step wizard to create detailed workouts with real-time preview
- Automatic generation of pre-filled GitHub issues from the form
- GitHub issue templates for workout submissions (quick idea and detailed)
- Contribution guide (CONTRIBUTING.md) with conventions and instructions

#### Training Plans
- Personalized training plan generator with multi-step wizard, phase management, and progressive volume
- Training plan export to PDF and ICS (calendar)
- Training plan CTA on homepage with adaptive behavior (links to create or list)
- Trail race support: short trail (30km), trail (60km), ultra trail (100km) with terrain-adapted training
- Plan statistics overview: total sessions, hours, avg/week, key sessions, session type distribution bar
- Swap/replace any session in a plan with another workout from the library (search + type filters)
- ICS export dialog: choose your training days and long run day before calendar export
- Enriched PDF export with full workout blocks (warm-up, main set, cool-down, coaching tips)
- Enriched ICS export with full session details and coaching tips
- Pace target notes generated for tempo/threshold/VO2max/long run sessions
- Elevation notes for long run sessions when race has elevation gain
- Delete plans directly from the plans list page with confirmation dialog
- Volume adjustment indicator on session duration (explanatory tooltip and percentage)

#### Guides
- 3 bilingual practical guides: runner's nutrition, race preparation, and warm-up routines

#### Library
- 17 new scientifically-grounded workouts (181 total)
- 4 new assessment tests: Cooper, Conconi, Yasso 800s, MAF Maffetone
- 5 new fartleks: Kenyan 1/1, descending, long distance 2/1, ascending ladder, whistle
- 4 new recovery sessions: barefoot, aqua jogging, joint mobility, nature regeneration
- 4 new hill sessions: explosive sprints, progressive gradient, rolling hills, downhill technique
- Infinite scroll on library replacing "Show more" button

#### Features
- Changelog page (`/changelog`) with version timeline and "What's New" indicator
- Custom 404 page with navigation suggestions
- Toast notifications for action feedback (exports, favorites, etc.)
- Error Boundary component for graceful error handling

### Changed

- Replaced horizontal navigation with responsive vertical sidebar
- Removed theme/language toggles from sidebar (already present in top bar)
- Reduced logo size in top bar for better visual balance
- Collections pages unified with flat minimal design
- Dynamic imports for all pages (lazy loading)
- Improved zone calculator validation
- Pagination added to library
- Removed day-of-week assignment: runners are free to choose their own training days
- Sessions displayed by priority (long run → key → endurance → recovery) without day labels

### Fixed

- Center search bar and logo in top bar (correct alignment on mobile, tablet and desktop)
- Center icons in collapsed sidebar (removed ghost gap)
- Fixed "Base — Base" duplicate label in week headers (phase shown twice)
- Duration calculation now uses actual workout blocks instead of inaccurate `typicalDuration` metadata
- Trail workouts no longer selected for road races (even with elevation)
- Main set duration scaled by volume %, warm-up/cool-down kept at full duration
- Improved variety in easy/recovery session selection
- Contextual back navigation: returns to plan (not library) when coming from a plan
- Fixed spacing in plan weekly view sessions

## [0.1.4] - 2026-02-13

### Added

#### Collections
- 12 curated thematic workout collections (beginner, anti-stress, injury comeback, pre/post-race, 5K/10K/half/marathon/ultra goals, legendary workouts, VO2max progression)
- Collections listing page with responsive grid layout
- Collection detail page with gradient hero, step numbering for progression paths
- Featured collections section on homepage
- Navigation link in header (desktop + mobile)

#### PWA
- Progressive Web App support with offline caching via Workbox
- Service worker with auto-update strategy
- App manifest with icons and theme colors

#### Workout Detail
- Dynamic nutrition recommendations based on workout duration and intensity
- Hydration guidelines adapted to session type
- Recovery recommendations with timeline and tips

### Changed

- Header actions consolidated with grid layout and dropdown menu
- Updated README with new features and tech stack

## [0.1.3] - 2026-01-31

### Added

#### Educational Content
- Knowledge hub with 12 bilingual articles on training principles
- Glossary page with 50+ training terms and definitions
- Educational tips system with 69 contextual tips (shown on homepage and workout details)
- New articles: zones, testing-vma, warmup, recovery, nutrition, faq, periodization, supercompensation, tapering, polarized-training, progressive-overload, consistency

#### Random Workout
- Random workout button in header with dice icon
- Random workout CTA card on homepage
- Quick access to discover new workouts

#### Settings & Personalization
- Settings page with theme and unit preferences
- Color blind accessible palettes (deuteranopia, protanopia, tritanopia)
- Unit conversion between metric (km/h, min/km) and imperial (mph, min/mi)
- Pace and zone calculators with unit support

#### Library Enhancements
- View mode selector (grid/list views)
- Command palette search with Cmd+K / Ctrl+K
- 14 new workout sessions (150 total)
- Mobile filter button with active filter badge

#### UI/UX Improvements
- Compact mobile layout for homepage CTAs (Quiz and Random side by side)
- Tips banner without dismiss button (always visible)
- Animated navigation underline
- Heart bounce animation on favorite button
- View transitions between pages
- Responsive header with intermediate breakpoint
- Zone detail modal with clickable workout links

#### SEO & Analytics
- Comprehensive SEO infrastructure with meta tags
- Structured data (JSON-LD) for workouts
- Vercel Analytics integration
- About page with project information

### Changed

- Homepage CTAs use compact 2-column grid layout on mobile
- Replaced lucide-react with inline SVG icons (65 icons)
- Zone colors now use CSS variables for theming
- Personalized zones displayed on workout detail page
- Quiz results integrate with library filters

### Fixed

- Language detection handles locale variants (en-US, fr-CA)
- Glossary cards re-render on language change
- Mobile menu closes on route change
- Interval parsing improved for recovery zone extraction
- Duration calculations aligned between timeline and metadata
- PDF export uses async blob download
- Various modal/dialog background fixes
- Minimum filter duration lowered to 10 minutes

### Performance

- Lazy-load articles and glossary data
- Code-splitting for workout data by category
- Main bundle reduced from 1MB to 88KB gzip
- Dead code elimination

## [0.1.2] - 2026-01-26

### Added

#### Branding
- Project logo with pulse design integrated in header
- Optimized favicon variants (16x16, 32x32, 180x180, 192x192, 512x512)
- SVG import support for logo assets

#### UI Components
- Empty state component with i18n support
- Scroll-to-top floating button
- Loading spinner on export button for better feedback

#### Accessibility
- Keyboard shortcuts for search functionality
- ARIA modal attributes to filter drawer for screen readers
- ARIA label to search input for accessibility
- Increased touch targets in mobile header for easier interaction

#### Mobile Experience
- Modal filter system with apply/cancel actions on mobile
- Search bar moved outside filter drawer for better discoverability

#### User Experience
- Quick wins UI improvements integrated in library
- Real-time system theme preference listener
- Automatic scroll to top on page navigation

### Changed

- Renamed mobile filter drawer to "Filters" for clarity

### Fixed

#### Mobile Layout
- Prevented mobile overflow in workout detail header
- Prevented mobile overflow by reorganizing header actions

#### Internationalization
- Translated workout not found error message
- Added translations for modal filter actions (apply/cancel)

### Chores

- Ignore Serena config directory in version control

## [0.1.1] - 2026-01-26

### Added

#### Export System
- Export workouts to 4 formats from detail page
- **ICS (Calendar)**: Add workout to Google Calendar, Apple Calendar, Outlook
- **PNG (Image)**: High-resolution export with full workout card (name, description, timeline, zones, blocks)
- **PDF (Document)**: Printable document with workout structure, coaching tips, and common mistakes
- **Garmin FIT**: Native workout file for Garmin devices with HR zones and step intensity

#### UI Components
- Dropdown menu component (Radix-based)
- Date/time picker for calendar export
- Exportable workout card with complete workout summary

### Changed

- Footer now displays dynamic workout and category counts
- Added GitHub repository link in footer

### Chores

- Clean up TypeScript cache files

## [0.1.0] - 2026-01-26

### Added

#### Core Application
- Initial React 19 + Vite + Tailwind 4 project setup
- 6-zone training system with scientific basis (Z1-Z6)
- 136 workout templates across 11 categories
- Multi-page routing: Home, Library, Workout Detail, Settings, Favorites
- Docker deployment configuration

#### Workout Library
- Categories: recovery, endurance, tempo, threshold, VMA, long run, hills, fartlek, race pace, mixed, assessment
- Assessment category with Cooper test, VAMEVAL, half-Cooper, and Léger-Boucher tests
- Norwegian double threshold sessions
- Bangsbo 10-20-30 method sessions
- Billat 30/30, SET and NRRs VMA sessions
- Yasso 800s, Rosario, and cutdown sessions
- Long regeneration and yoga-run sessions

#### Visualization
- Interactive timeline showing workout structure
- Zone distribution display
- Intensity bar indicator
- Support for complex interval patterns (e.g., 2x12x30s)

#### Personalization
- Zone calculator with FCmax/VMA inputs
- Personal zone preferences with localStorage persistence
- Favorites system with dedicated /favorites page
- Advanced filters: terrain type, target system, favorites only

#### Discovery
- Workout recommendation quiz based on goals and constraints
- Pace calculator for target times
- Workout of the Day with deterministic daily selection

#### Internationalization
- French-first with full English support
- All workout blocks translated in both languages
- Language detection via localStorage, navigator, or HTML tag

#### UI/UX
- shadcn/ui components with Radix primitives
- Lucide icons throughout (replaced emoji icons)
- CategoryIcon components for visual categorization
- Tap-to-reveal tooltips for mobile accessibility

### Fixed

- Multi-set interval pattern parsing (2x12x30s)
- Quiz fallback results sorted by closest duration
- Message display when no exact duration match in quiz
- Duration estimates using typicalDuration field
- French titles in visualization translations
- Category type mappings (vma → vma_intervals)

### Documentation

- README with project overview and commands
- Docker deployment instructions
