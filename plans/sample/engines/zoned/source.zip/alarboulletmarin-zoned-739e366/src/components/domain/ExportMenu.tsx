/**
 * ExportMenu - Dropdown menu for workout export options
 *
 * Provides 4 export formats:
 * - Calendar (ICS)
 * - Image (PNG) - Full workout card with all info
 * - Document (PDF)
 * - Garmin (FIT)
 */

import { useState, useRef, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { Download, Calendar, Image, FileText, Watch, Loader2 } from "@/components/icons";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ExportDatePicker } from "./ExportDatePicker";
import { ExportableWorkoutCard } from "./ExportableWorkoutCard";
import { FitTransferGuide } from "./FitTransferGuide";
import { exportToICS, exportToPNG, exportToPDF, exportToFIT } from "@/lib/export";
import { toast } from "@/components/ui/toast";
import type { WorkoutTemplate } from "@/types";

interface ExportMenuProps {
  workout: WorkoutTemplate;
  /** Applied to the trigger button, e.g. to stretch it as a primary CTA. */
  className?: string;
  size?: "sm" | "default" | "lg";
  /** "outline" when another action owns the primary slot. */
  variant?: "default" | "outline";
}

export function ExportMenu({ workout, className, size = "sm", variant = "default" }: ExportMenuProps) {
  const { t } = useTranslation("common");
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showFitGuide, setShowFitGuide] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [renderForExport, setRenderForExport] = useState(false);
  const exportCardRef = useRef<HTMLDivElement>(null);

  const handleICSClick = () => {
    setShowDatePicker(true);
  };

  const handleICSExport = async (dateTime: Date) => {
    setShowDatePicker(false);
    setIsExporting(true);
    const toastId = toast.loading(t("export.loading.calendar", t("export.title")));
    try {
      await exportToICS(workout, dateTime);
      toast.success(t("export.success.calendar"), { id: toastId });
    } catch (error) {
      toast.failure(t("export.error.calendar"), error, { id: toastId });
    } finally {
      setIsExporting(false);
    }
  };

  const handlePNGExport = useCallback(async () => {
    setIsExporting(true);
    setRenderForExport(true);
    const toastId = toast.loading(t("export.loading.image", t("export.title")));

    // Wait for next frame to ensure component is rendered
    await new Promise((resolve) => requestAnimationFrame(resolve));
    // Additional delay for complex components
    await new Promise((resolve) => setTimeout(resolve, 100));

    try {
      if (exportCardRef.current) {
        const { method } = await exportToPNG(exportCardRef.current, `${workout.id}-workout`);
        toast.success(
          t(method === "native" ? "export.success.imageShared" : "export.success.image"),
          { id: toastId },
        );
      } else {
        throw new Error("Export card not rendered");
      }
    } catch (error) {
      // Une feuille de partage refermee sans rien choisir n'est pas un echec :
      // `toast.failure` le sait et ne dit rien dans ce cas.
      toast.failure(t("export.error.image"), error, { id: toastId });
    } finally {
      setRenderForExport(false);
      setIsExporting(false);
    }
  }, [workout.id, t]);

  const handlePDFExport = async () => {
    setIsExporting(true);
    const toastId = toast.loading(t("export.loading.pdf", t("export.title")));
    try {
      await exportToPDF(workout);
      toast.success(t("export.success.pdf"), { id: toastId });
    } catch (error) {
      toast.failure(t("export.error.pdf"), error, { id: toastId });
    } finally {
      setIsExporting(false);
    }
  };

  const handleFITExport = async () => {
    setIsExporting(true);
    const toastId = toast.loading(t("export.loading.garmin", t("export.title")));
    try {
      await exportToFIT(workout);
      toast.success(t("export.success.garmin"), { id: toastId });
      setShowFitGuide(true);
    } catch (error) {
      toast.failure(t("export.error.garmin"), error, { id: toastId });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant={variant}
            size={size}
            disabled={isExporting}
            className={className}
          >
            {isExporting ? <Loader2 className="zn-spin" /> : <Download />}
            {t("export.title")}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={handleICSClick}>
            <Calendar />
            {t("export.calendar")}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handlePNGExport}>
            <Image />
            {t("export.image")}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handlePDFExport}>
            <FileText />
            {t("export.pdf")}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleFITExport}>
            <Watch />
            {t("export.garmin")}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {showDatePicker && (
        <ExportDatePicker
          onSelect={handleICSExport}
          onCancel={() => setShowDatePicker(false)}
        />
      )}

      <FitTransferGuide
        open={showFitGuide}
        onOpenChange={setShowFitGuide}
        workout={workout}
      />

      {/* Hidden export card for PNG capture */}
      {renderForExport && (
        <div
          style={{
            position: "fixed",
            left: "-9999px",
            top: 0,
            zIndex: -1,
          }}
        >
          <ExportableWorkoutCard ref={exportCardRef} workout={workout} />
        </div>
      )}
    </>
  );
}
