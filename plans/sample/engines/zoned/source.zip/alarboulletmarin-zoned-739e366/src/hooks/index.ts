export { useFavorites, FavoritesProvider } from "./useFavorites";
export { useKeyboardShortcuts } from "./useKeyboardShortcuts";
export { useViewMode, type ViewMode } from "./useViewMode";
export {
  useWorkouts,
  useWorkout,
  useCategoryWorkouts,
  useRelatedWorkouts,
  useFilteredWorkouts,
} from "./useWorkouts";
export { useTips } from "./useTips";
export { usePWA } from "./usePWA";
export { useTheme, ThemeProvider } from "./useTheme";

// NOTE: useArticles and useGlossary are NOT exported here to avoid
// pulling their data into the main bundle. Import them directly:
// import { useArticle } from "@/hooks/useArticles";
// import { useGlossary } from "@/hooks/useGlossary";
