export { auth as proxy } from "@/auth";

export const config = {
  matcher: ["/dashboard/:path*", "/plans/:path*", "/onboarding/:path*"],
};
