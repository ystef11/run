module github.com/KenShabby/run_plan_generator

go 1.26

require (
	github.com/a-h/templ v0.3.1020
	github.com/go-chi/chi/v5 v5.3.2
	github.com/gorilla/sessions v1.4.0
	github.com/jackc/pgx/v5 v5.9.1
	golang.org/x/crypto v0.50.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	github.com/go-chi/httprate v0.16.0 // indirect
	github.com/gorilla/csrf v1.7.3 // indirect
	github.com/gorilla/securecookie v1.1.2 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	github.com/klauspost/cpuid/v2 v2.2.10 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/rogpeppe/go-internal v1.14.1 // indirect
	github.com/zeebo/xxh3 v1.0.2 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/sys v0.43.0 // indirect
	golang.org/x/text v0.36.0 // indirect
)
