import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useLocation,
  useNavigationType,
} from "react-router-dom";
import { useState, useEffect, useRef, lazy, Suspense, type ComponentType } from "react";
import { useTranslation } from "react-i18next";
import { Analytics } from "@vercel/analytics/react";
import { Toaster } from "sonner";
import { toast } from "@/components/ui/toast";
import { TopBar, Footer } from "@/components/layout";
import { ModuleGate } from "@/components/layout/ModuleGate";
import { getAllPlans } from "@/lib/planStorage";
import { isPlanEnded } from "@/lib/planUtils";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { FavoritesProvider } from "@/hooks";
import { SettingsProvider } from "@/hooks/useSettings";
import { CommandPaletteProvider, useCommandPalette } from "@/components/search";
import { GlossaryMatcherProvider } from "@/contexts/GlossaryMatcherContext";
import { StorageWarning } from "@/components/domain/StorageWarning";
import { PWAInstallPrompt } from "@/components/domain/PWAInstallPrompt";
import { UpdatePrompt } from "@/components/domain/UpdatePrompt";
import { usePWA } from "@/hooks/usePWA";
import { ThemeProvider } from "@/hooks/useTheme";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import { useIdleAfterLoad } from "@/hooks/useIdleAfterLoad";
import { i18nReady } from "@/i18n";

/** React.lazy that also waits for the active language's translation bundles
 *  (loaded in parallel with the page chunk). The page renders only once both
 *  are ready, behind the same Suspense fallback, no flash of raw i18n keys.
 *  After the first page, i18nReady is resolved and this is free. */
function lazyPage<T extends ComponentType<unknown>>(
  loader: () => Promise<{ default: T }>
) {
  return lazy(() =>
    Promise.all([loader(), i18nReady]).then(([module]) => module)
  );
}

// All pages lazy loaded for optimal code-splitting
const HomePage = lazyPage(() => import("@/pages/HomePage").then(m => ({ default: m.HomePage })));
const TodayPage = lazyPage(() => import("@/pages/TodayPage").then(m => ({ default: m.TodayPage })));
const LibraryPage = lazyPage(() => import("@/pages/LibraryPage").then(m => ({ default: m.LibraryPage })));
const DrawSessionPage = lazyPage(() => import("@/pages/DrawSessionPage").then(m => ({ default: m.DrawSessionPage })));
const WeeksListPage = lazyPage(() => import("@/pages/WeeksListPage").then(m => ({ default: m.WeeksListPage })));
const WeekViewPage = lazyPage(() => import("@/pages/WeekViewPage").then(m => ({ default: m.WeekViewPage })));
const WeekNewPage = lazyPage(() => import("@/pages/WeekNewPage").then(m => ({ default: m.WeekNewPage })));
const PrebuiltWeeksPage = lazyPage(() => import("@/pages/PrebuiltWeeksPage").then(m => ({ default: m.PrebuiltWeeksPage })));
const PrebuiltWeekDetailPage = lazyPage(() => import("@/pages/PrebuiltWeekDetailPage").then(m => ({ default: m.PrebuiltWeekDetailPage })));
const SharedWeekPage = lazyPage(() => import("@/pages/SharedWeekPage").then(m => ({ default: m.SharedWeekPage })));
const WorkoutDetailPage = lazyPage(() => import("@/pages/WorkoutDetailPage").then(m => ({ default: m.WorkoutDetailPage })));
const SharedWorkoutPage = lazyPage(() => import("@/pages/SharedWorkoutPage").then(m => ({ default: m.SharedWorkoutPage })));
const SharedPlanPage = lazyPage(() => import("@/pages/SharedPlanPage").then(m => ({ default: m.SharedPlanPage })));
const MyZonesPage = lazyPage(() => import("@/pages/MyZonesPage").then(m => ({ default: m.MyZonesPage })));
const FavoritesPage = lazyPage(() => import("@/pages/FavoritesPage").then(m => ({ default: m.FavoritesPage })));
const ContributePage = lazyPage(() => import("@/pages/ContributePage").then(m => ({ default: m.ContributePage })));
const AboutPage = lazyPage(() => import("@/pages/AboutPage").then(m => ({ default: m.AboutPage })));
const LearnPage = lazyPage(() => import("@/pages/LearnPage").then(m => ({ default: m.LearnPage })));
const MethodologyPage = lazyPage(() => import("@/pages/MethodologyPage").then(m => ({ default: m.MethodologyPage })));
const ArticlePage = lazyPage(() => import("@/pages/ArticlePage").then(m => ({ default: m.ArticlePage })));
const GlossaryPage = lazyPage(() => import("@/pages/GlossaryPage").then(m => ({ default: m.GlossaryPage })));
const GlossaryTermPage = lazyPage(() => import("@/pages/GlossaryTermPage").then(m => ({ default: m.GlossaryTermPage })));
const SettingsPage = lazyPage(() => import("@/pages/SettingsPage").then(m => ({ default: m.SettingsPage })));
const CollectionsPage = lazyPage(() => import("@/pages/CollectionsPage").then(m => ({ default: m.CollectionsPage })));
const CollectionDetailPage = lazyPage(() => import("@/pages/CollectionDetailPage").then(m => ({ default: m.CollectionDetailPage })));
const ChangelogPage = lazyPage(() => import("@/pages/ChangelogPage").then(m => ({ default: m.ChangelogPage })));
const PlansPage = lazyPage(() => import("@/pages/PlansPage").then(m => ({ default: m.PlansPage })));
const PlanCreatePage = lazyPage(() => import("@/pages/PlanCreatePage").then(m => ({ default: m.PlanCreatePage })));
const FreePlanCreatePage = lazyPage(() => import("@/pages/FreePlanCreatePage").then(m => ({ default: m.FreePlanCreatePage })));
const PlanViewPage = lazyPage(() => import("@/pages/PlanViewPage").then(m => ({ default: m.PlanViewPage })));
const PrebuiltPlansPage = lazyPage(() => import("@/pages/PrebuiltPlansPage").then(m => ({ default: m.PrebuiltPlansPage })));
const PrebuiltPlanDetailPage = lazyPage(() => import("@/pages/PrebuiltPlanDetailPage").then(m => ({ default: m.PrebuiltPlanDetailPage })));
const PlanMethodologyPage = lazyPage(() => import("@/pages/PlanMethodologyPage").then(m => ({ default: m.PlanMethodologyPage })));
const NutritionGuidePage = lazyPage(() => import("@/pages/NutritionGuidePage").then(m => ({ default: m.NutritionGuidePage })));
const NutritionHubPage = lazyPage(() => import("@/pages/NutritionHubPage").then(m => ({ default: m.NutritionHubPage })));
const GuidesPage = lazyPage(() => import("@/pages/GuidesPage").then(m => ({ default: m.GuidesPage })));
const CalculateursPage = lazyPage(() => import("@/pages/CalculateursPage").then(m => ({ default: m.CalculateursPage })));
const ZonesCalculatorPage = lazyPage(() => import("@/pages/ZonesCalculatorPage").then(m => ({ default: m.ZonesCalculatorPage })));
const PaceCalculatorPage = lazyPage(() => import("@/pages/PaceCalculatorPage").then(m => ({ default: m.PaceCalculatorPage })));
const TreadmillConverterPage = lazyPage(() => import("@/pages/TreadmillConverterPage").then(m => ({ default: m.TreadmillConverterPage })));
const SplitGeneratorPage = lazyPage(() => import("@/pages/SplitGeneratorPage").then(m => ({ default: m.SplitGeneratorPage })));
const VmaCalculatorPage = lazyPage(() => import("@/pages/VmaCalculatorPage").then(m => ({ default: m.VmaCalculatorPage })));
const FtpTestPage = lazyPage(() => import("@/pages/tests/FtpTestPage").then(m => ({ default: m.FtpTestPage })));
const CssTestPage = lazyPage(() => import("@/pages/tests/CssTestPage").then(m => ({ default: m.CssTestPage })));
const RaceEquivalencePage = lazyPage(() => import("@/pages/RaceEquivalencePage").then(m => ({ default: m.RaceEquivalencePage })));
const RacePrepGuidePage = lazyPage(() => import("@/pages/RacePrepGuidePage").then(m => ({ default: m.RacePrepGuidePage })));
const WarmupGuidePage = lazyPage(() => import("@/pages/WarmupGuidePage").then(m => ({ default: m.WarmupGuidePage })));
const PaceConverterPage = lazyPage(() => import("@/pages/PaceConverterPage").then(m => ({ default: m.PaceConverterPage })));
const PaceTablePage = lazyPage(() => import("@/pages/PaceTablePage").then(m => ({ default: m.PaceTablePage })));
const WorkoutBuilderPage = lazyPage(() => import("@/pages/WorkoutBuilderPage").then(m => ({ default: m.WorkoutBuilderPage })));
const RaceSimulatorPage = lazyPage(() => import("@/pages/RaceSimulatorPage").then(m => ({ default: m.RaceSimulatorPage })));
const CompareHubPage = lazyPage(() => import("@/pages/CompareHubPage").then(m => ({ default: m.CompareHubPage })));
const CompareDetailPage = lazyPage(() => import("@/pages/CompareDetailPage").then(m => ({ default: m.CompareDetailPage })));
const RunnerProfilePage = lazyPage(() => import("@/pages/RunnerProfilePage").then(m => ({ default: m.RunnerProfilePage })));
const ActivitiesPage = lazyPage(() => import("@/pages/ActivitiesPage").then(m => ({ default: m.ActivitiesPage })));
const NotFoundPage = lazyPage(() => import("@/pages/NotFoundPage").then(m => ({ default: m.NotFoundPage })));

// Command palette body: lazy so its search index (workout structures,
// collections, command surfaces, unified search) stays out of the entry
// chunk. Mounted on first open; the chunk is also preloaded at idle below,
// so by the time a human presses Cmd+K it is already in cache.
const LazyCommandPalette = lazy(() =>
  Promise.all([
    import("@/components/search/CommandPalette").then(m => ({ default: m.CommandPalette })),
    i18nReady,
  ]).then(([module]) => module)
);

function DeferredCommandPalette() {
  const { isOpen } = useCommandPalette();
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    if (isOpen) setMounted(true);
  }, [isOpen]);
  if (!mounted) return null;
  return (
    <Suspense fallback={null}>
      <LazyCommandPalette />
    </Suspense>
  );
}

// Preload sidebar pages after initial render to eliminate navigation latency
function preloadSidebarPages() {
  const pages = [
    () => import("@/pages/TodayPage"),
    () => import("@/pages/HomePage"),
    () => import("@/pages/LibraryPage"),
    () => import("@/pages/PlansPage"),
    () => import("@/pages/FavoritesPage"),
    () => import("@/pages/CalculateursPage"),
    () => import("@/pages/CollectionsPage"),
    () => import("@/pages/LearnPage"),
    () => import("@/pages/GlossaryPage"),
    () => import("@/pages/MethodologyPage"),
    () => import("@/components/search/CommandPalette"),
  ];
  // Stagger preloads to not block the main thread. The caller already waits
  // for load+idle, so no extra base delay is needed.
  pages.forEach((load, i) => setTimeout(load, i * 200));
}

/** Routes that take over the full viewport (Strava-style map experiences,
 *  immersive editors). The Zoned Footer is hidden so the page can claim
 *  the entire vertical space without the user being pushed past the
 *  fold to satisfy a footer below the map. */
const FULLSCREEN_ROUTES = ["/routes"];

/** Un seul pied de page, le même sur toutes les routes.
 *
 *  Il y avait ici une table de variantes : le cockpit n'avait qu'une ligne de
 *  licence en encre claire, tout le reste portait quatre colonnes de liens
 *  surmontant une barre de cinq éléments. Deux pieds de page pour la même
 *  signature, et sur téléphone celui des pages publiques se dépliait en cinq
 *  rangées. Le pied de page ne dépend plus de la route : une ligne, partout,
 *  et les quatre colonnes repliées derrière Plan du site (voir Footer.tsx).
 *
 *  Reste la seule exception qui n'est pas une question de style :
 *  FULLSCREEN_ROUTES, où la carte revendique le viewport entier. */
function ConditionalFooter() {
  const { pathname } = useLocation();
  if (FULLSCREEN_ROUTES.includes(pathname)) return null;
  return <Footer />;
}

/**
 * La racine : la landing pour qui découvre, le cockpit pour qui s'entraîne.
 *
 * Sur trente et un jours, `/` était la page la plus vue (192 vues pour 79
 * visiteurs) et `/today` celle où l'on revenait le plus (3,3 vues par
 * visiteur). Quelqu'un qui a un plan en cours et ouvre l'app arrivait donc
 * sur une landing de 6 300 px avant de trouver sa séance. Dès qu'un plan non
 * terminé existe dans ce navigateur, la racine mène au cockpit. Les robots
 * n'ont pas de localStorage : la landing reste ce qu'ils voient et ce que le
 * prérendu écrit.
 *
 * Sauf quand on la demande. Le logo de la barre et la ligne Accueil du menu
 * portent `HOME_LINK_STATE` : depuis l'app, appuyer dessus veut dire la
 * landing, pas le cockpit, et la redirection rendait la page inaccessible à
 * qui s'entraîne. L'état ne vit que dans l'historique du navigateur, donc
 * une arrivée directe sur `/` n'en a pas et suit la règle d'ouverture.
 */
function RootPage() {
  const location = useLocation();
  const wantsLanding = (location.state as { landing?: boolean } | null)?.landing === true;
  const hasLivePlan = getAllPlans().some((plan) => !isPlanEnded(plan));
  return hasLivePlan && !wantsLanding ? <Navigate to="/today" replace /> : <HomePage />;
}

function ScrollToTopOnNavigate() {
  const location = useLocation();
  const navigationType = useNavigationType();
  const [announcement, setAnnouncement] = useState("");

  useEffect(() => {
    // Un REPLACE, c'est une page qui réécrit son propre état dans l'URL
    // (les filtres de la bibliothèque, la semaine d'un plan), pas un
    // changement de page : la position de lecture reste.
    if (navigationType === "REPLACE") return;
    const state = location.state as { returnScrollY?: number } | null;
    if (state?.returnScrollY != null) return;
    window.scrollTo(0, 0);
  }, [location.pathname, location.search, location.state, navigationType]);

  // Announce page change for screen readers
  useEffect(() => {
    const title = document.title || location.pathname;
    setAnnouncement(title);
  }, [location.pathname]);

  return (
    <div aria-live="polite" aria-atomic="true" className="sr-only">
      {announcement}
    </div>
  );
}

function App() {
  const { t } = useTranslation("common");
  const { canInstall, promptInstall, dismissInstall, isOnline } = usePWA();
  // Toaster placement: bottom-right covers the share-sheet action row on
  // mobile (Copier / Partager / Télécharger). On small viewports we surface
  // the toast at the top instead so it never overlaps a button the user just
  // tapped.
  //
  // How long a toast stays is not decided here either: `components/ui/toast`
  // holds one duration per kind (a confirmation leaves, an error stays long
  // enough to be read), the same on every screen. The drawing is ours too,
  // through `toast.custom`, so sonner gets no `richColors`, no `closeButton`
  // and no theme: it only places and times what we hand it.
  //
  // Ou il se pose exactement, c'est `toast.css` qui le dit : il doit franchir
  // la barre du haut, sauf quand une feuille modale occupe deja l'ecran, et
  // cette nuance ne se passe pas en props. Le `offset` qui vivait ici ne
  // servait d'ailleurs a rien : sonner tient DEUX decalages et bascule sur
  // `mobileOffset` sous 600px, donc sur un telephone il n'etait jamais lu.
  const isMobile = useMediaQuery("(max-width: 767px)");

  // Preload main pages in background once the window has loaded and the
  // main thread is idle, a fixed 1s timer used to fire while the LCP page
  // chunk and fonts were still downloading on slow connections.
  const preloadReady = useIdleAfterLoad();
  useEffect(() => {
    if (preloadReady) preloadSidebarPages();
  }, [preloadReady]);

  // Theme lives in ThemeProvider (mounted below). Nothing here needs to know
  // it: the TopBar button and the settings card read it from context, so a
  // theme change never re-renders this tree.

  // PWA: toast on offline / back-online
  const prevOnline = useRef(true);
  useEffect(() => {
    if (!isOnline) {
      toast.warning(t("pwa.offline"), { id: "offline", duration: Infinity });
    } else if (!prevOnline.current) {
      toast.dismiss("offline");
      toast.success(t("pwa.backOnline"));
    }
    prevOnline.current = isOnline;
  }, [isOnline]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <SettingsProvider>
      <ThemeProvider>
        <FavoritesProvider>
          <BrowserRouter>
          <GlossaryMatcherProvider>
          <CommandPaletteProvider>
            <a href="#main-content" className="zn-skip">
              {t("accessibility.skipToContent")}
            </a>
            <ScrollToTopOnNavigate />
            <div className="zn-app">
              {/* Below 1024px navigation is a full-screen menu opened by a
                  glyph at the start of the bar; the bar mounts both itself
                  (TopBar.tsx). Desktop keeps the five doors in the header. */}
              <TopBar />

              <div className="zn-app__body">
                <ErrorBoundary>
                {/* The Suspense boundary wraps BOTH the page and the footer:
                    with the footer outside, it sat just below the
                    viewport-tall fallback during the initial load, then
                    jumped up into the viewport when a shorter page (e.g. a
                    calculator) resolved, a real CLS hit. Inside, footer and
                    page appear together (appearance is not a shift), and
                    later navigations never show this fallback because
                    react-router wraps them in startTransition. */}
                <Suspense
                  fallback={
                    <main id="main-content" className="zn-main">
                      <div className="zn-page">
                        <div className="zn-page__hold" />
                      </div>
                    </main>
                  }
                >
                <main id="main-content" className="zn-main">
                  <div className="zn-page">
                    <ErrorBoundary>
                        <Routes>
                          <Route path="/" element={<RootPage />} />
                          {/* Le cockpit. `/` reste la landing publique et
                              indexée ; celle-ci est l'écran privé, donc hors
                              sitemap et hors prérendu, comme /plans et
                              /weeks, exclus pour la même raison. */}
                          <Route path="/today" element={<TodayPage />} />
                          <Route path="/library" element={<LibraryPage />} />
                          <Route path="/library/draw" element={<DrawSessionPage />} />
                          <Route path="/weeks" element={<WeeksListPage />} />
                          <Route path="/weeks/new" element={<WeekNewPage />} />
                          <Route path="/weeks/new/prebuilt" element={<PrebuiltWeeksPage />} />
                          <Route path="/weeks/prebuilt/:slug" element={<PrebuiltWeekDetailPage />} />
                          <Route path="/weeks/shared" element={<SharedWeekPage />} />
                          <Route path="/weeks/:id" element={<WeekViewPage />} />
                          <Route path="/library/weekly" element={<Navigate to="/weeks" replace />} />
                          <Route path="/workout/builder" element={<WorkoutBuilderPage />} />
                          <Route path="/workout/builder/:id" element={<WorkoutBuilderPage />} />
                          <Route path="/workout/shared" element={<SharedWorkoutPage />} />
                          <Route path="/workout/:id" element={<WorkoutDetailPage />} />
                          <Route path="/my-zones" element={<MyZonesPage />} />
                          <Route path="/calculators" element={<CalculateursPage />} />
                          <Route path="/calculators/zones" element={<ZonesCalculatorPage />} />
                          <Route path="/calculators/allures" element={<PaceCalculatorPage />} />
                          <Route path="/calculators/convertisseur" element={<PaceConverterPage />} />
                          <Route path="/calculators/table-allures" element={<PaceTablePage />} />
                          <Route path="/calculators/tapis-roulant" element={<TreadmillConverterPage />} />
                          <Route path="/calculators/splits" element={<SplitGeneratorPage />} />
                          <Route path="/calculators/vma" element={<VmaCalculatorPage />} />
                          <Route path="/calculators/ftp" element={<FtpTestPage />} />
                          <Route path="/calculators/css" element={<CssTestPage />} />
                          <Route path="/calculators/equivalence" element={<RaceEquivalencePage />} />
                          <Route path="/settings" element={<SettingsPage />} />
                          <Route path="/profile" element={<RunnerProfilePage />} />
                          <Route path="/activities" element={<ActivitiesPage />} />
                          <Route path="/favorites" element={<FavoritesPage />} />
                          <Route path="/quiz" element={<Navigate to="/library/draw" replace />} />
                          <Route path="/contribute" element={<ContributePage />} />
                          <Route path="/about" element={<AboutPage />} />
                          <Route path="/learn" element={<ModuleGate module="learn" canonical="/learn"><LearnPage /></ModuleGate>} />
                          <Route path="/methodology" element={<MethodologyPage />} />
                          <Route path="/learn/:slug" element={<ModuleGate module="learn"><ArticlePage /></ModuleGate>} />
                          <Route path="/collections" element={<ModuleGate module="collections" canonical="/collections"><CollectionsPage /></ModuleGate>} />
                          <Route path="/collections/:slug" element={<ModuleGate module="collections"><CollectionDetailPage /></ModuleGate>} />
                          <Route path="/glossary" element={<GlossaryPage />} />
                          <Route path="/glossary/:id" element={<GlossaryTermPage />} />
                          <Route path="/changelog" element={<ChangelogPage />} />
                          <Route path="/guides" element={<GuidesPage />} />
                          <Route path="/guides/nutrition" element={<NutritionGuidePage />} />
                          <Route path="/guides/race-prep" element={<RacePrepGuidePage />} />
                          <Route path="/guides/warmup" element={<WarmupGuidePage />} />
                          <Route path="/nutrition" element={<NutritionHubPage />} />
                          <Route path="/plans" element={<PlansPage />} />
                          <Route path="/plans/methodology" element={<PlanMethodologyPage />} />
                          <Route path="/plan/new" element={<PlanCreatePage />} />
                          {/* Les deux couloirs d'avant le 20 septembre 2026 : la pratique, puis le mode. Les liens partagés retombent sur la première question. */}
                          <Route path="/plan/new/mode" element={<Navigate to="/plan/new" replace />} />
                          <Route path="/plan/new/assisted" element={<Navigate to="/plan/new" replace />} />
                          <Route path="/plan/new/free" element={<FreePlanCreatePage />} />
                          <Route path="/plan/new/prebuilt" element={<PrebuiltPlansPage />} />
                          <Route path="/plan/prebuilt/:slug" element={<PrebuiltPlanDetailPage />} />
                          <Route path="/plan/shared" element={<SharedPlanPage />} />
                          <Route path="/plan/:id" element={<PlanViewPage />} />
                          <Route path="/race-simulator" element={<ModuleGate module="raceSimulator" canonical="/race-simulator"><RaceSimulatorPage /></ModuleGate>} />
                          <Route path="/race-simulator/shared" element={<RaceSimulatorPage />} />
                          <Route path="/compare" element={<CompareHubPage />} />
                          <Route path="/compare/:slug" element={<CompareDetailPage />} />
                          <Route path="*" element={<NotFoundPage />} />
                        </Routes>
                    </ErrorBoundary>
                  </div>
                </main>

                <ConditionalFooter />
                </Suspense>
                </ErrorBoundary>
              </div>
            </div>
            <DeferredCommandPalette />
          </CommandPaletteProvider>
          </GlossaryMatcherProvider>
          <Analytics />
          <StorageWarning />
          {/* Mounted once, outside <Routes>, so the banners survive navigation.
              The update comes first in the DOM because it comes first in
              importance: offering to install a version we already know is
              stale is the wrong order. The stack puts it on top by itself. */}
          <div className="zn-prompts">
            <UpdatePrompt />
            {canInstall && <PWAInstallPrompt onInstall={promptInstall} onDismiss={dismissInstall} />}
          </div>
          {/* The wrapper is what gets promoted into the top layer while a
              <dialog> is open, see native-dialog.tsx. A modal dialog paints
              over everything the document can stack, z-index 999999999
              included, so without it the "Lien copié" of an open share sheet
              would land behind its own backdrop. It is a zero-size box: sonner
              keeps placing and sizing its own list. */}
          <div className="zn-toast-layer">
            <Toaster
              position={isMobile ? "top-center" : "bottom-right"}
              /* Two at once, not three: the newest and, behind it, the one
                 pinned notice the app keeps (offline). A burst of
                 confirmations replaces itself instead of piling up. */
              visibleToasts={2}
            />
          </div>
          </BrowserRouter>
        </FavoritesProvider>
      </ThemeProvider>
    </SettingsProvider>
  );
}

export default App;
