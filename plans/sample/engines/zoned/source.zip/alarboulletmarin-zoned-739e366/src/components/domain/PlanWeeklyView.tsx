import { useState, useRef, useMemo, useCallback, memo } from "react";
import { useTranslation } from "react-i18next";
import { Star, Flag, Clock, Trash2, Eye, ChevronLeft, ChevronRight, ChevronDown, ChevronUp, Dumbbell, Dices, Lock, LockOpen, Copy, Plus, Run, Bike, Pool } from "@/components/icons";
import { PHASE_META, RACE_DISTANCE_META } from "@/types/plan";
import type { PlanSession, TrainingPlan } from "@/types/plan";
import { computeWeekKm, computeWeekDuration } from "@/lib/planStats";
import { formatDurationMinutes } from "@/components/visualization/transforms";
import { ZoneScale, ZoneBar, type ZoneBarBlock } from "@/components/visualization";
import { IntensityMeter } from "@/components/domain/StrengthWorkoutCard";
import type { StrengthIntensity } from "@/types/strength";
import { sessionDiscipline } from "@/lib/planStats";
import { dayStep, staysInPlace } from "@/lib/dayOrder";
import { usePickLang } from "@/lib/i18n-utils";
import { toast } from "@/components/ui/toast";
import { WeekGuidancePanel } from "@/components/domain/WeekGuidancePanel";
import {
  SessionActionMenu,
  type SessionActionMenuItem,
} from "@/components/domain/SessionActionMenu";
import { SESSION_ZONE, sessionColor } from "@/lib/sessionColors";
import {
  activityKindOf,
  activitySessionTss,
  activitySessionZone,
  isActivitySession,
} from "@/lib/activitySession";
import { isLooseSession } from "@/lib/sessionPrecision";

/** Placeholder sessions (race day, cross-training activities) have no catalog
 *  workout behind them, so there is nothing to draw a replacement from. */
function isRedrawable(workoutId: string): boolean {
  return !workoutId.startsWith("__");
}

/** A session type with no aerobic zone gets the hollow mark, never a hue. */
function isZoned(sessionType: string): boolean {
  return SESSION_ZONE[sessionType as keyof typeof SESSION_ZONE] != null;
}

// ── Props ───────────────────────────────────────────────────────────

/** Per-workout badge data shown on the card (zone + session load). */
export interface WorkoutCardMeta {
  zone?: number;
  tss?: number | null;
}

/**
 * The little picture of a session, the one the library's compact card draws:
 * the zone profile of a run, a ride or a swim, the intensity steps of a
 * strength session. Handed in by the page, which owns the catalogue, so the
 * board never walks a workout's structure itself.
 */
export type WorkoutCardProfile =
  | { kind: "zones"; blocks: ZoneBarBlock[] }
  | { kind: "strength"; intensity: StrengthIntensity };

/** The sport a card names, as an icon: the library's own vocabulary. */
const DISCIPLINE_ICON = {
  running: Run,
  cycling: Bike,
  swimming: Pool,
  strength: Dumbbell,
} as const;

/**
 * The sport of a session, or null when it has none to name (yoga, cross
 * training, a loose rest): those keep the dot and nothing more, an icon
 * naming a sport they are not would be worse than none.
 */
function cardDiscipline(session: PlanSession): keyof typeof DISCIPLINE_ICON | null {
  if (session.sessionType === "strength" || session.workoutId.startsWith("STR-")) return "strength";
  const d = sessionDiscipline(session);
  return d === "other" ? null : d;
}

/**
 * Where, inside a day, a session held at `clientY` would land: in front of the
 * first session whose middle is under the pointer, at the end of the day when
 * none is. Read off the day's own cards, which are the only thing that knows
 * how tall they are: a mobile row stacks them, a desktop column too, and the
 * dragged card is left out, it is the one being placed.
 */
function slotInDay(day: Element, clientY: number, draggedIndex: number): number | undefined {
  for (const el of day.querySelectorAll<HTMLElement>("[data-session-index]")) {
    const index = Number(el.dataset.sessionIndex);
    if (index === draggedIndex) continue;
    const box = el.getBoundingClientRect();
    if (clientY < box.top + box.height / 2) return index;
  }
  return undefined;
}

/** Where a drag is hovering: a day, and the place in it (end of day if absent). */
interface DropSlot {
  weekNumber: number;
  day: number;
  before?: number;
}

function sameSlot(a: DropSlot | null, b: DropSlot | null): boolean {
  return a?.weekNumber === b?.weekNumber && a?.day === b?.day && a?.before === b?.before;
}

interface PlanWeeklyViewProps {
  plan: TrainingPlan;
  workoutNames: Record<string, string>;
  /** Optional zone/TSS per workout id, adds a meta line to each card. */
  workoutMeta?: Record<string, WorkoutCardMeta>;
  /** Optional profile per workout id: the card's small picture of the session. */
  workoutProfiles?: Record<string, WorkoutCardProfile>;
  currentWeek: number;
  initialWeek?: number;
  isEn: boolean;
  planStartDate?: string;
  onSessionClick?: (weekNumber: number, sessionIndex: number, workoutId: string) => void;
  /**
   * `beforeSessionIndex` is the session of `toDay` the moved one lands in
   * front of (its index in the week before the move); absent, it closes the day.
   */
  onSessionMove?: (
    fromWeek: number,
    fromSessionIndex: number,
    toWeek: number,
    toDay: number,
    beforeSessionIndex?: number,
  ) => void;
  onSessionDelete?: (weekNumber: number, sessionIndex: number) => void;
  /** "Ma semaine": copy a session onto its day, to be dragged where it goes. */
  onSessionDuplicate?: (weekNumber: number, sessionIndex: number) => void;
  onToggleComplete?: (weekNumber: number, sessionIndex: number) => void;
  /** "Ma semaine": lock a session so it survives week (re)generation. */
  onToggleLock?: (weekNumber: number, sessionIndex: number) => void;
  /** "Ma semaine": draw another workout for this session only. */
  onRedraw?: (weekNumber: number, sessionIndex: number) => void;
  /** Replaces a day's content while the draw animation runs (null = untouched). */
  renderScanCell?: (day: number) => React.ReactNode | null;
  onValidateWeek?: (weekNumber: number) => void;
  onWorkoutAdd?: (workoutId: string, weekNumber: number, day: number) => void;
  onAddToDay?: (weekNumber: number, day: number) => void;
  /** Plan : ajouter une de mes semaines, ou une du catalogue, à cette semaine-ci. */
  onAddWeek?: (weekNumber: number) => void;
  onWeekChange?: (week: number) => void;
  blockedDays?: Set<string>;
  /** Standalone "Ma semaine": hide week nav + free-plan guide, rest cards on empty days. */
  singleWeek?: boolean;
  /**
   * A short tap on a card calls `onSessionClick` instead of opening the
   * context menu at the finger: the week page opens the session's own sheet
   * there, which is what a thumb can read and aim at.
   */
  tapOpensSession?: boolean;
}

// ── Component ───────────────────────────────────────────────────────

export const PlanWeeklyView = memo(function PlanWeeklyView({
  plan,
  workoutNames,
  workoutMeta,
  workoutProfiles,
  currentWeek,
  initialWeek,
  isEn,
  planStartDate,
  onSessionClick,
  onSessionMove,
  onSessionDelete,
  onSessionDuplicate,
  onToggleComplete,
  onToggleLock,
  onRedraw,
  renderScanCell,
  onValidateWeek,
  onWorkoutAdd,
  onAddToDay,
  onAddWeek,
  onWeekChange,
  blockedDays,
  singleWeek = false,
  tapOpensSession = false,
}: PlanWeeklyViewProps) {
  const { t } = useTranslation(["plan", "library", "common"]);
  const pickLang = usePickLang();
  // ── Week navigation state ──────────────────────────────────────
  const [selectedWeek, setSelectedWeek] = useState(Math.max(1, initialWeek ?? currentWeek));

  const weekData = useMemo(
    () => plan.weeks.find((w) => w.weekNumber === selectedWeek),
    [plan.weeks, selectedWeek],
  );

  const parsedStartDate = useMemo(() => {
    if (!planStartDate) return null;
    const dateOnly = planStartDate.split("T")[0];
    const [y, m, d] = dateOnly.split("-").map(Number);
    const date = new Date(y, m - 1, d);
    // Normalize to Monday of that week (same logic as PlanCalendar)
    const jsDay = date.getDay();
    const offset = jsDay === 0 ? -6 : 1 - jsDay;
    date.setDate(date.getDate() + offset);
    return date;
  }, [planStartDate]);

  // ── Native drag state ─────────────────────────────────────────
  const [draggedSession, setDraggedSession] = useState<{
    weekNumber: number;
    sessionIndex: number;
  } | null>(null);
  const [dropTarget, setDropTarget] = useState<DropSlot | null>(null);
  // The session in the air, readable the instant the drag starts: the state
  // above is set a frame later (the browser needs the card to keep its
  // drag image), and the first dragover does not wait for it.
  const draggedRef = useRef<{ weekNumber: number; sessionIndex: number } | null>(null);

  // Trash drop zone, surfaced only while a session is being dragged, so
  // "remove a session" is discoverable without a right-click.
  const [overTrash, setOverTrash] = useState(false);
  const overTrashRef = useRef(false);

  // Touch-specific refs
  const touchDragRef = useRef<{
    weekNumber: number;
    sessionIndex: number;
  } | null>(null);
  const touchGhostRef = useRef<HTMLElement | null>(null);
  const dropTargetRef = useRef<DropSlot | null>(null);

  // Long-press / context menu state
  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    weekNumber: number;
    sessionIndex: number;
    workoutId: string;
  } | null>(null);
  const longPressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const touchStartPosRef = useRef<{ x: number; y: number } | null>(null);
  const isDraggingRef = useRef(false);
  const longPressFiredRef = useRef(false);
  // Store session info for touchend tap detection
  const touchSessionRef = useRef<{
    weekNumber: number;
    sessionIndex: number;
    workoutId: string;
    target: HTMLElement | null;
  } | null>(null);

  /* La fermeture, clic à côté et Échap, appartient désormais à
     SessionActionMenu : son voile couvre la fenêtre, donc il ne peut pas rater
     un pointerdown qu'un autre gestionnaire aurait arrêté en chemin, là où
     l'écouteur posé sur `document` qui vivait ici le pouvait. */

  // Lock state of the session the context menu targets (drives lock/unlock label).
  const contextWeek =
    contextMenu != null ? plan.weeks.find((w) => w.weekNumber === contextMenu.weekNumber) : undefined;
  const contextSession = contextMenu != null ? contextWeek?.sessions[contextMenu.sessionIndex] : undefined;
  const contextSessionLocked = contextSession?.locked === true;
  // One place up or down its day, when there is a place to go: the way to
  // order a day without a drag, for a keyboard, a thumb or a tired hand.
  const contextStepUp =
    contextWeek && contextMenu ? dayStep(contextWeek.sessions, contextMenu.sessionIndex, "up") : null;
  const contextStepDown =
    contextWeek && contextMenu ? dayStep(contextWeek.sessions, contextMenu.sessionIndex, "down") : null;

  // ── Desktop drag handlers (HTML5 Drag and Drop) ───────────────

  const handleDragStart = useCallback(
    (e: React.DragEvent, weekNumber: number, sessionIndex: number) => {
      e.stopPropagation();
      e.dataTransfer.effectAllowed = "move";
      draggedRef.current = { weekNumber, sessionIndex };
      requestAnimationFrame(() => {
        setDraggedSession({ weekNumber, sessionIndex });
      });
    },
    [],
  );

  const handleDragOver = useCallback(
    (e: React.DragEvent, weekNumber: number, day: number) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      // Over a day, the pointer also says WHERE in it: a card dragged from the
      // library has no place to keep, a session of the board does.
      const dragged = draggedRef.current;
      const next: DropSlot = { weekNumber, day };
      if (dragged && dragged.weekNumber === weekNumber) {
        next.before = slotInDay(e.currentTarget, e.clientY, dragged.sessionIndex);
      }
      setDropTarget((prev) => (sameSlot(prev, next) ? prev : next));
    },
    [],
  );

  const handleDragLeave = useCallback(() => {
    setDropTarget(null);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent, weekNumber: number, day: number) => {
      e.preventDefault();
      setDropTarget(null);

      const dragged = draggedRef.current;
      draggedRef.current = null;

      // Block drop on unavailable days
      if (blockedDays?.has(`${weekNumber}-${day}`)) {
        toast.error(t("reschedule.blockedDrop"));
        setDraggedSession(null);
        return;
      }

      // Check if this is a drop from the workout library panel
      const workoutId = e.dataTransfer.getData("workout-id");
      if (workoutId && onWorkoutAdd) {
        onWorkoutAdd(workoutId, weekNumber, day);
        setDraggedSession(null);
        return;
      }

      const held = dragged ?? draggedSession;
      if (!held || !onSessionMove) return;

      // Where in the day: the pointer's place among its cards, as the hover
      // showed it. Another week has no cards of the dragged session to
      // compare with, it simply closes the day.
      const before =
        held.weekNumber === weekNumber
          ? slotInDay(e.currentTarget as Element, e.clientY, held.sessionIndex)
          : undefined;

      // Don't move to same position
      const week = plan.weeks.find((w) => w.weekNumber === held.weekNumber);
      if (
        week &&
        held.weekNumber === weekNumber &&
        staysInPlace(week.sessions, held.sessionIndex, day, before)
      ) {
        setDraggedSession(null);
        return;
      }

      onSessionMove(held.weekNumber, held.sessionIndex, weekNumber, day, before);
      setDraggedSession(null);
    },
    [draggedSession, onSessionMove, onWorkoutAdd, plan.weeks, blockedDays, t],
  );

  const handleDragEnd = useCallback(() => {
    draggedRef.current = null;
    setDraggedSession(null);
    setDropTarget(null);
  }, []);

  // ── Mobile touch handlers (long press + drag) ─────────────────

  const startDrag = useCallback(
    (touch: React.Touch, weekNumber: number, sessionIndex: number, target: HTMLElement | null) => {
      isDraggingRef.current = true;
      touchDragRef.current = { weekNumber, sessionIndex };
      setDraggedSession({ weekNumber, sessionIndex });

      // Clone the dragged element as ghost
      const ghost = target
        ? (target.cloneNode(true) as HTMLElement)
        : document.createElement("div");

      ghost.style.cssText = `
        position: fixed; z-index: 9999; pointer-events: none;
        width: ${target?.offsetWidth || 80}px;
        opacity: 0.85;
        box-shadow: 0 8px 24px rgba(0,0,0,0.2);
        transform: translate(-50%, -50%);
      `;
      ghost.style.left = `${touch.clientX}px`;
      ghost.style.top = `${touch.clientY}px`;
      document.body.appendChild(ghost);
      touchGhostRef.current = ghost;
    },
    [],
  );

  const handleTouchStart = useCallback(
    (e: React.TouchEvent, weekNumber: number, sessionIndex: number, workoutId: string) => {
      // If the tap is on a button (checkbox, delete), let it handle itself
      const tappedEl = e.target as HTMLElement;
      if (tappedEl.closest("button")) return;

      e.stopPropagation();
      const touch = e.touches[0];
      const target = (e.target as HTMLElement).closest("[draggable]") as HTMLElement | null;

      // Reset state
      isDraggingRef.current = false;
      longPressFiredRef.current = false;
      touchStartPosRef.current = { x: touch.clientX, y: touch.clientY };
      touchSessionRef.current = { weekNumber, sessionIndex, workoutId, target };

      // Start long-press timer (400ms)
      longPressTimerRef.current = setTimeout(() => {
        if (!isDraggingRef.current) {
          longPressFiredRef.current = true;
          // Haptic feedback
          if (navigator.vibrate) navigator.vibrate(50);
          setContextMenu({
            x: touch.clientX,
            y: touch.clientY,
            weekNumber,
            sessionIndex,
            workoutId,
          });
        }
      }, 400);
    },
    [],
  );

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      const touch = e.touches[0];
      const startPos = touchStartPosRef.current;

      // If long press already fired (context menu open), ignore movement
      if (longPressFiredRef.current) {
        e.preventDefault();
        return;
      }

      // Check if we've moved enough to start a drag (>10px)
      if (!isDraggingRef.current && startPos) {
        const dx = touch.clientX - startPos.x;
        const dy = touch.clientY - startPos.y;
        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
          // Cancel long-press timer, start drag
          if (longPressTimerRef.current) {
            clearTimeout(longPressTimerRef.current);
            longPressTimerRef.current = null;
          }
          const sessionInfo = touchSessionRef.current;
          if (sessionInfo) {
            startDrag(touch, sessionInfo.weekNumber, sessionInfo.sessionIndex, sessionInfo.target);
          }
        }
      }

      // If dragging, move the ghost
      if (isDraggingRef.current && touchGhostRef.current) {
        e.preventDefault();
        touchGhostRef.current.style.left = `${touch.clientX}px`;
        touchGhostRef.current.style.top = `${touch.clientY}px`;

        // Find drop target using document.elementsFromPoint
        const elements = document.elementsFromPoint(touch.clientX, touch.clientY);
        const overTrashNow = elements.some((el) => el.hasAttribute("data-trash-drop"));
        if (overTrashNow !== overTrashRef.current) {
          overTrashRef.current = overTrashNow;
          setOverTrash(overTrashNow);
        }
        if (overTrashNow) {
          dropTargetRef.current = null;
          setDropTarget(null);
          return;
        }
        const dropCell = elements.find((el) => el.hasAttribute("data-drop-id"));

        if (dropCell) {
          const [weekStr, dayStr] = (dropCell.getAttribute("data-drop-id") || "").split("-");
          const newTarget: DropSlot = { weekNumber: Number(weekStr), day: Number(dayStr) };
          // The finger says the place in the day as the mouse does.
          const held = touchDragRef.current;
          if (held && held.weekNumber === newTarget.weekNumber) {
            newTarget.before = slotInDay(dropCell, touch.clientY, held.sessionIndex);
          }
          if (!sameSlot(dropTargetRef.current, newTarget)) {
            dropTargetRef.current = newTarget;
            setDropTarget(newTarget);
          }
        } else {
          dropTargetRef.current = null;
          setDropTarget(null);
        }
      }
    },
    [startDrag],
  );

  const handleTouchEnd = useCallback(() => {
    // Cancel long-press timer
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }

    const wasDragging = isDraggingRef.current;
    const wasLongPress = longPressFiredRef.current;
    const sessionInfo = touchSessionRef.current;

    // Clean up ghost if dragging
    if (touchGhostRef.current) {
      document.body.removeChild(touchGhostRef.current);
      touchGhostRef.current = null;
    }

    if (wasDragging) {
      // Handle drop
      const dragState = touchDragRef.current;
      const target = dropTargetRef.current;
      const droppedOnTrash = overTrashRef.current;
      touchDragRef.current = null;
      dropTargetRef.current = null;
      overTrashRef.current = false;
      setOverTrash(false);
      setDraggedSession(null);
      setDropTarget(null);

      if (dragState && droppedOnTrash && onSessionDelete) {
        onSessionDelete(dragState.weekNumber, dragState.sessionIndex);
      } else if (dragState && target && onSessionMove) {
        // Block drop on unavailable days
        if (blockedDays?.has(`${target.weekNumber}-${target.day}`)) {
          toast.error(t("reschedule.blockedDrop"));
        } else {
          const week = plan.weeks.find((w) => w.weekNumber === dragState.weekNumber);
          if (
            !(
              week &&
              dragState.weekNumber === target.weekNumber &&
              staysInPlace(week.sessions, dragState.sessionIndex, target.day, target.before)
            )
          ) {
            onSessionMove(
              dragState.weekNumber,
              dragState.sessionIndex,
              target.weekNumber,
              target.day,
              target.before,
            );
          }
        }
      }
    } else if (!wasLongPress && sessionInfo && tapOpensSession && onSessionClick) {
      // Short tap on the week board: the session's own sheet, not a menu at
      // the finger. The long press still opens the menu, and drags.
      onSessionClick(sessionInfo.weekNumber, sessionInfo.sessionIndex, sessionInfo.workoutId);
    } else if (!wasLongPress && sessionInfo) {
      // Short tap: open context menu (easier than hitting the small checkbox)
      setContextMenu({
        x: touchStartPosRef.current?.x ?? 0,
        y: touchStartPosRef.current?.y ?? 0,
        weekNumber: sessionInfo.weekNumber,
        sessionIndex: sessionInfo.sessionIndex,
        workoutId: sessionInfo.workoutId,
      });
    }
    // If wasLongPress: context menu is already open, do nothing

    // Reset refs
    isDraggingRef.current = false;
    longPressFiredRef.current = false;
    touchStartPosRef.current = null;
    touchSessionRef.current = null;
  }, [onSessionMove, onSessionDelete, onSessionClick, tapOpensSession, plan.weeks]);

  // ── Derived data ──────────────────────────────────────────────

  const isCurrent =
    currentWeek === selectedWeek && currentWeek >= 1 && currentWeek <= plan.totalWeeks;

  const phaseMeta = weekData ? PHASE_META[weekData.phase] : null;

  const dayHeadersShort = useMemo(
    () => [0, 1, 2, 3, 4, 5, 6].map((i) => t(`daysShort.${i}`)),
    [t],
  );
  const dayHeadersFull = useMemo(
    () => [0, 1, 2, 3, 4, 5, 6].map((i) => t(`days.${i}`)),
    [t],
  );

  // ── Render ────────────────────────────────────────────────────

  return (
    <>
      <div className="zn-planweek">
        {/* ── Week navigation ── */}
        {!singleWeek && (
        <div className="zn-planweek__nav">
          <button
            type="button"
            onClick={() => {
              const newWeek = Math.max(1, selectedWeek - 1);
              setSelectedWeek(newWeek);
              onWeekChange?.(newWeek);
            }}
            disabled={selectedWeek <= 1}
            className="zn-planweek__nav-btn"
          >
            <ChevronLeft />
          </button>

          <div className="zn-planweek__heading">
            <div className="zn-planweek__title-row">
              <span className="zn-planweek__title">
                {t("weeklyView.weekTitle", { week: selectedWeek })}
              </span>
              {isCurrent && (
                <span className="zn-planweek__now">{t("calendar.now")}</span>
              )}
            </div>
            {weekData && phaseMeta && (
              <>
                <span className="zn-planweek__sub">
                  {pickLang(phaseMeta, "label")}
                </span>
                {parsedStartDate && (() => {
                  const shortMonths = isEn
                    ? ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
                    : ["Jan","Fév","Mar","Avr","Mai","Juin","Juil","Août","Sep","Oct","Nov","Déc"];
                  const weekStart = new Date(parsedStartDate);
                  weekStart.setDate(weekStart.getDate() + (selectedWeek - 1) * 7);
                  const weekEnd = new Date(parsedStartDate);
                  weekEnd.setDate(weekEnd.getDate() + (selectedWeek - 1) * 7 + 6);
                  const label = weekStart.getMonth() === weekEnd.getMonth()
                    ? `${weekStart.getDate()} - ${weekEnd.getDate()} ${shortMonths[weekStart.getMonth()]}`
                    : `${weekStart.getDate()} ${shortMonths[weekStart.getMonth()]} - ${weekEnd.getDate()} ${shortMonths[weekEnd.getMonth()]}`;
                  return <span className="zn-planweek__sub">{label}</span>;
                })()}
                {weekData.sessions.length > 0 && (
                  <span className="zn-planweek__sub">
                    ~{Math.round(computeWeekKm(weekData))}km ·{" "}
                    {formatDurationMinutes(computeWeekDuration(weekData))}
                  </span>
                )}
              </>
            )}
          </div>

          <button
            type="button"
            onClick={() => {
              const newWeek = Math.min(plan.totalWeeks, selectedWeek + 1);
              setSelectedWeek(newWeek);
              onWeekChange?.(newWeek);
            }}
            disabled={selectedWeek >= plan.totalWeeks}
            className="zn-planweek__nav-btn"
          >
            <ChevronRight />
          </button>
        </div>
        )}

        {/* ── Week completion stats ── */}
        {weekData && (() => {
          const total = weekData.sessions.length;
          if (total === 0) return null;
          const done = weekData.sessions.filter((s) => s.status === "completed" || s.status === "modified").length;
          const skipped = weekData.sessions.filter((s) => s.status === "skipped").length;
          const resolved = done + skipped;
          const allResolved = resolved === total;

          if (allResolved && resolved > 0) {
            return (
              <div className="zn-planweek__banner">
                <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M2 6l3 3 5-5" />
                </svg>
                {done}/{total} {t("weeklyView.completed")}
              </div>
            );
          }

          if (resolved > 0 && !allResolved && onValidateWeek) {
            return (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onValidateWeek(selectedWeek);
                }}
                className="zn-planweek__pill"
                title={t("calendar.validateWeek")}
              >
                {t("calendar.validateCount", { done, total })}
              </button>
            );
          }

          return null;
        })()}

        {/* Ajouter une semaine ICI : le geste vivait dans la feuille du
            cockpit, où l'on ne va pas quand on travaille son plan. */}
        {weekData && onAddWeek && !singleWeek && (
          <button
            type="button"
            className="zn-planweek__pill"
            onClick={() => onAddWeek(selectedWeek)}
          >
            <Plus size={14} />
            {t("view.addWeek.button")}
          </button>
        )}

        {/* ── Week guidance (free plans only) ── */}
        {weekData && plan.config.planMode === "free" && !singleWeek && (
          <WeekGuidancePanel
            week={weekData}
            daysPerWeek={plan.config.daysPerWeek}
          />
        )}

        {/* ── Day grid ── */}
        {weekData && (
          <div
            className="zn-planweek__board"
            data-recovery={weekData.isRecoveryWeek || undefined}
          >
            {/* Mobile: 4+3 grid layout */}
            {[
                [0, 1, 2, 3],
                [4, 5, 6],
              ].map((row, rowIdx) => (
                <div
                  key={rowIdx}
                  className="zn-planweek__row"
                  /* Le nombre de colonnes est une donnée, pas un style : un
                     style inline bat toute feuille de style, et la CSS doit
                     pouvoir retomber à une colonne sous 640px. */
                  data-cols={row.length}
                >
                  {row.map((dayIndex) => {
                    let dayOfMonth: number | null = null;
                    let monthLabel = "";
                    let isToday = false;
                    if (parsedStartDate) {
                      const cellDate = new Date(parsedStartDate);
                      cellDate.setDate(cellDate.getDate() + (selectedWeek - 1) * 7 + dayIndex);
                      dayOfMonth = cellDate.getDate();
                      const now = new Date();
                      isToday = cellDate.getFullYear() === now.getFullYear()
                        && cellDate.getMonth() === now.getMonth()
                        && cellDate.getDate() === now.getDate();
                      if (dayOfMonth === 1) {
                        const shortMonths = isEn
                          ? ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
                          : ["Jan","Fév","Mar","Avr","Mai","Juin","Juil","Août","Sep","Oct","Nov","Déc"];
                        monthLabel = shortMonths[cellDate.getMonth()];
                      }
                    }
                    return (
                      <DayCell
                        key={dayIndex}
                        dayIndex={dayIndex}
                        weekData={weekData}
                        selectedWeek={selectedWeek}
                        dayLabel={dayHeadersShort[dayIndex]}
                        dayOfMonth={dayOfMonth}
                        monthLabel={monthLabel}
                        isToday={isToday}
                        workoutNames={workoutNames}
                        workoutMeta={workoutMeta}
                        workoutProfiles={workoutProfiles}
                        dropTarget={dropTarget}
                        draggedSession={draggedSession}
                        singleWeek={singleWeek}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        onDragStart={handleDragStart}
                        onDragEnd={handleDragEnd}
                        onTouchStart={handleTouchStart}
                        onTouchMove={handleTouchMove}
                        onTouchEnd={handleTouchEnd}
                        onSessionClick={onSessionClick}
                        onToggleComplete={onToggleComplete}
                        onToggleLock={onToggleLock}
                        onRedraw={onRedraw}
                        onSessionDelete={onSessionDelete}
                        onSessionDuplicate={onSessionDuplicate}
                        renderScanCell={renderScanCell}
                        onAddToDay={onAddToDay}
                        setContextMenu={setContextMenu}
                        isBlockedDay={blockedDays?.has(`${selectedWeek}-${dayIndex}`) ?? false}
                      />
                    );
                  })}
                </div>
              ))}

            {/* Desktop: single 7-column row */}
            <div className="zn-planweek__week-row">
              {Array.from({ length: 7 }, (_, dayIndex) => {
                let dayOfMonth: number | null = null;
                let monthLabel = "";
                let isToday = false;
                if (parsedStartDate) {
                  const cellDate = new Date(parsedStartDate);
                  cellDate.setDate(cellDate.getDate() + (selectedWeek - 1) * 7 + dayIndex);
                  dayOfMonth = cellDate.getDate();
                  const now = new Date();
                  isToday = cellDate.getFullYear() === now.getFullYear()
                    && cellDate.getMonth() === now.getMonth()
                    && cellDate.getDate() === now.getDate();
                  if (dayOfMonth === 1) {
                    const shortMonths = isEn
                      ? ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
                      : ["Jan","Fév","Mar","Avr","Mai","Juin","Juil","Août","Sep","Oct","Nov","Déc"];
                    monthLabel = shortMonths[cellDate.getMonth()];
                  }
                }
                return (
                  <DayCell
                    key={dayIndex}
                    dayIndex={dayIndex}
                    weekData={weekData}
                    selectedWeek={selectedWeek}
                    dayLabel={dayHeadersFull[dayIndex]}
                    dayOfMonth={dayOfMonth}
                    monthLabel={monthLabel}
                    isToday={isToday}
                    workoutNames={workoutNames}
                    workoutMeta={workoutMeta}
                    workoutProfiles={workoutProfiles}
                    dropTarget={dropTarget}
                    draggedSession={draggedSession}
                    isDesktop
                    singleWeek={singleWeek}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    onDragStart={handleDragStart}
                    onDragEnd={handleDragEnd}
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                    onSessionClick={onSessionClick}
                    onToggleComplete={onToggleComplete}
                    onToggleLock={onToggleLock}
                    onRedraw={onRedraw}
                    onSessionDelete={onSessionDelete}
                    onSessionDuplicate={onSessionDuplicate}
                    renderScanCell={renderScanCell}
                    onAddToDay={onAddToDay}
                    setContextMenu={setContextMenu}
                    isBlockedDay={blockedDays?.has(`${selectedWeek}-${dayIndex}`) ?? false}
                  />
                );
              })}
            </div>
          </div>
        )}

        {/* The board paints zone ink, so it carries the ramp's legend once,
            repliée, parce qu'on l'apprend une fois et qu'elle coûtait 131px
            au-dessus du pli chaque jour. */}
        {weekData && (
          <details className="zn-disclosure">
            <summary className="zn-disclosure__summary">
              <span className="zn-kicker zn-kicker--xs zn-fill">{t("common:zones.scaleTitle")}</span>
              <ChevronDown className="zn-disclosure__chevron" />
            </summary>
            <div className="zn-disclosure__panel">
              <ZoneScale showTitle={false} />
            </div>
          </details>
        )}
      </div>

      {/* ── Trash drop zone (appears while dragging a session) ── */}
      {draggedSession && onSessionDelete && (
        <div
          data-trash-drop=""
          onDragOver={(e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = "move";
            setOverTrash(true);
          }}
          onDragLeave={() => setOverTrash(false)}
          onDrop={(e) => {
            e.preventDefault();
            e.stopPropagation();
            setOverTrash(false);
            if (draggedSession) {
              onSessionDelete(draggedSession.weekNumber, draggedSession.sessionIndex);
              setDraggedSession(null);
              setDropTarget(null);
            }
          }}
          className="zn-plan-trash"
          data-armed={overTrash || undefined}
        >
          <Trash2 />
          {t("calendar.dropToDelete")}
        </div>
      )}

      {/* ── Le menu d'une séance (appui long ou court sur téléphone, clic
              droit sur bureau) ──

          Il était écrit ici, en JSX inline, et n'existait donc que pour cette
          vue : la vue liste du même plan n'avait rien à ouvrir. Il vit
          maintenant dans SessionActionMenu, que les deux vues rendent, mêmes
          entrées, même forme, même placement. Ce qui reste ici est la seule
          chose que cette vue soit seule à savoir : ce qu'on peut faire à une
          séance d'un tableau de semaine. */}
      {contextMenu && (
        <SessionActionMenu
          x={contextMenu.x}
          y={contextMenu.y}
          onClose={() => setContextMenu(null)}
          items={([
            /* An activity has no session page to open: the same gesture
               opens its duration and effort instead, and says so. */
            onSessionClick && {
              key: "view",
              icon: tapOpensSession || isActivitySession(contextMenu.workoutId) ? <Clock /> : <Eye />,
              label: tapOpensSession
                ? t("library:weekly.slot.adjust")
                : isActivitySession(contextMenu.workoutId)
                  ? t("activitySession.menu")
                  : t("calendar.viewSession"),
              onSelect: () =>
                onSessionClick(
                  contextMenu.weekNumber,
                  contextMenu.sessionIndex,
                  contextMenu.workoutId,
                ),
            },
            onToggleComplete && {
              key: "done",
              icon: (
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12l5 5 9-9" />
                </svg>
              ),
              label: t("completion.toggleDone"),
              onSelect: () => onToggleComplete(contextMenu.weekNumber, contextMenu.sessionIndex),
            },
            onRedraw &&
              isRedrawable(contextMenu.workoutId) &&
              !contextSessionLocked && {
                key: "redraw",
                icon: <Dices />,
                label: t("library:weekly.slot.reroll"),
                onSelect: () => onRedraw(contextMenu.weekNumber, contextMenu.sessionIndex),
              },
            onToggleLock && {
              key: "lock",
              icon: contextSessionLocked ? <LockOpen /> : <Lock />,
              label: contextSessionLocked
                ? t("library:weekly.slot.unlock")
                : t("library:weekly.slot.lock"),
              onSelect: () => onToggleLock(contextMenu.weekNumber, contextMenu.sessionIndex),
            },
            onSessionDuplicate && {
              key: "duplicate",
              icon: <Copy />,
              label: t("library:weekly.slot.duplicate"),
              onSelect: () => onSessionDuplicate(contextMenu.weekNumber, contextMenu.sessionIndex),
            },
            onSessionMove &&
              contextSession &&
              contextStepUp && {
                key: "up",
                icon: <ChevronUp />,
                label: t("library:weekly.slot.moveUp"),
                onSelect: () =>
                  onSessionMove(
                    contextMenu.weekNumber,
                    contextMenu.sessionIndex,
                    contextMenu.weekNumber,
                    contextSession.dayOfWeek,
                    contextStepUp.before,
                  ),
              },
            onSessionMove &&
              contextSession &&
              contextStepDown && {
                key: "down",
                icon: <ChevronDown />,
                label: t("library:weekly.slot.moveDown"),
                onSelect: () =>
                  onSessionMove(
                    contextMenu.weekNumber,
                    contextMenu.sessionIndex,
                    contextMenu.weekNumber,
                    contextSession.dayOfWeek,
                    contextStepDown.before,
                  ),
              },
            onSessionDelete && {
              key: "delete",
              icon: <Trash2 />,
              label: t("calendar.deleteSession"),
              variant: "destructive" as const,
              onSelect: () => onSessionDelete(contextMenu.weekNumber, contextMenu.sessionIndex),
            },
          ] as (SessionActionMenuItem | false | undefined)[]).filter(
            (item): item is SessionActionMenuItem => Boolean(item),
          )}
        />
      )}
    </>
  );
});

// ── DayCell sub-component ──────────────────────────────────────────

interface DayCellProps {
  dayIndex: number;
  weekData: TrainingPlan["weeks"][number];
  selectedWeek: number;
  dayLabel: string;
  dayOfMonth?: number | null;
  monthLabel?: string;
  isToday?: boolean;
  workoutNames: Record<string, string>;
  workoutMeta?: Record<string, WorkoutCardMeta>;
  workoutProfiles?: Record<string, WorkoutCardProfile>;
  dropTarget: DropSlot | null;
  draggedSession: { weekNumber: number; sessionIndex: number } | null;
  isDesktop?: boolean;
  /** Standalone "Ma semaine" board: rest cards on empty days, taller mobile cells. */
  singleWeek?: boolean;
  onDragOver: (e: React.DragEvent, weekNumber: number, day: number) => void;
  onDragLeave: () => void;
  onDrop: (e: React.DragEvent, weekNumber: number, day: number) => void;
  onDragStart: (e: React.DragEvent, weekNumber: number, sessionIndex: number) => void;
  onDragEnd: () => void;
  onTouchStart: (
    e: React.TouchEvent,
    weekNumber: number,
    sessionIndex: number,
    workoutId: string,
  ) => void;
  onTouchMove: (e: React.TouchEvent) => void;
  onTouchEnd: () => void;
  onSessionClick?: (weekNumber: number, sessionIndex: number, workoutId: string) => void;
  onToggleComplete?: (weekNumber: number, sessionIndex: number) => void;
  onToggleLock?: (weekNumber: number, sessionIndex: number) => void;
  onRedraw?: (weekNumber: number, sessionIndex: number) => void;
  onSessionDelete?: (weekNumber: number, sessionIndex: number) => void;
  onSessionDuplicate?: (weekNumber: number, sessionIndex: number) => void;
  renderScanCell?: (day: number) => React.ReactNode | null;
  onAddToDay?: (weekNumber: number, day: number) => void;
  setContextMenu: (
    menu: {
      x: number;
      y: number;
      weekNumber: number;
      sessionIndex: number;
      workoutId: string;
    } | null,
  ) => void;
  isBlockedDay?: boolean;
}

const DayCell = memo(function DayCell({
  dayIndex,
  weekData,
  selectedWeek,
  dayLabel,
  dayOfMonth,
  monthLabel,
  isToday,
  workoutNames,
  workoutMeta,
  workoutProfiles,
  dropTarget,
  draggedSession,
  isDesktop,
  singleWeek,
  onDragOver,
  onDragLeave,
  onDrop,
  onDragStart,
  onDragEnd,
  onTouchStart,
  onTouchMove,
  onTouchEnd,
  onSessionClick,
  onToggleComplete,
  onToggleLock,
  onRedraw,
  onSessionDelete,
  onSessionDuplicate,
  renderScanCell,
  onAddToDay,
  setContextMenu,
  isBlockedDay,
}: DayCellProps) {
  const { t } = useTranslation(["plan", "library"]);
  const pickLang = usePickLang();
  const sessions = weekData.sessions.filter((s) => s.dayOfWeek === dayIndex);
  // While the draw animation runs, this day shows the spinning card instead of
  // its own content, same cell, same position, so nothing can drift.
  const scanContent = renderScanCell?.(dayIndex) ?? null;
  const isDropHere = dropTarget?.weekNumber === selectedWeek && dropTarget?.day === dayIndex;
  // The line of the place a held session would take: above the card it lands
  // in front of, or under the last card of the day when it lands at the end.
  // A day with no other card has no line to draw, the day's own ring says it.
  const heldIndex =
    draggedSession?.weekNumber === selectedWeek ? draggedSession.sessionIndex : null;
  const lastOfDay = isDropHere && dropTarget?.before === undefined
    ? sessions.map((s) => weekData.sessions.indexOf(s)).filter((i) => i !== heldIndex).pop()
    : undefined;

  return (
    <div
      data-drop-id={`${selectedWeek}-${dayIndex}`}
      onDragOver={(e) => onDragOver(e, selectedWeek, dayIndex)}
      onDragLeave={onDragLeave}
      onDrop={(e) => onDrop(e, selectedWeek, dayIndex)}
      className="zn-planweek__day"
      data-today={isToday || undefined}
      aria-current={isToday ? "date" : undefined}
      data-desktop={isDesktop || undefined}
      data-single-week={singleWeek || undefined}
      data-drop={isDropHere || undefined}
      data-blocked={isBlockedDay || undefined}
    >
      {isBlockedDay && (
        <span className="zn-planweek__blocked-label">
          {t("unavailability.blocked")}
        </span>
      )}
      {/* Le jour et son quantième forment une seule colonne quand la journée
          devient une ligne (sous 640px) ; au-dessus, `display: contents`
          rend ce div transparent et les deux spans restent empilés comme
          avant. */}
      <div className="zn-planweek__dayhead">
        <span className="zn-planweek__daylabel">{dayLabel}</span>
        {dayOfMonth != null && (
          <span
            className="zn-planweek__date"
            data-today={isToday || undefined}
            data-month-label={monthLabel ? "true" : undefined}
          >
            {monthLabel ? `${dayOfMonth} ${monthLabel}` : dayOfMonth}
          </span>
        )}
      </div>

      {scanContent && (
        <div className="zn-planweek__scan" aria-hidden="true">
          {scanContent}
        </div>
      )}

      {!scanContent && sessions.length === 0 ? (
        onAddToDay && !isBlockedDay ? (
          <button
            type="button"
            onClick={() => onAddToDay(selectedWeek, dayIndex)}
            className="zn-planweek__add"
          >
            {singleWeek && (
              <span className="zn-planweek__add-kind">
                {t("library:weekly.kinds.rest")}
              </span>
            )}
            <span className="zn-planweek__add-plus">+</span>
          </button>
        ) : (
          /* A read-only week names its rest day, as the editor does: a shared
             week is looked at, and three dashes say nothing about a Sunday. */
          <span className="zn-planweek__empty">
            {singleWeek && !isBlockedDay ? t("library:weekly.kinds.rest") : "---"}
          </span>
        )
      ) : null}

      {!scanContent && sessions.map((session, sIdx) => {
        const isRaceDay = session.workoutId === "__race_day__";
        const isIntermediateRace = session.workoutId === "__intermediate_race__";
        const isSpecialSession = isRaceDay || isIntermediateRace;
        const originalIndex = weekData.sessions.indexOf(session);
        const isDragging =
          draggedSession?.weekNumber === selectedWeek &&
          draggedSession?.sessionIndex === originalIndex;
        const sessionName = workoutNames[session.workoutId] || session.workoutId;
        const isStrength = session.sessionType === "strength" || session.workoutId?.startsWith("STR-");
        const isActivity = isActivitySession(session.workoutId);
        const discipline = cardDiscipline(session);
        const DisciplineIcon = discipline ? DISCIPLINE_ICON[discipline] : null;
        const profile = workoutProfiles?.[session.workoutId];
        // An activity carries its own zone and load, from its planned effort,
        // so its card reads like the others: Z2 · 45 min · 33 TSS.
        const meta: WorkoutCardMeta | undefined = isActivity
          ? {
              zone: activitySessionZone(session) ?? undefined,
              tss: activitySessionTss(session) || null,
            }
          : workoutMeta?.[session.workoutId];

        return (
          <div
            key={sIdx}
            draggable={!isSpecialSession}
            onDragStart={
              isSpecialSession ? undefined : (e) => onDragStart(e, selectedWeek, originalIndex)
            }
            onDragEnd={isSpecialSession ? undefined : onDragEnd}
            onTouchStart={
              isSpecialSession
                ? undefined
                : (e) => onTouchStart(e, selectedWeek, originalIndex, session.workoutId)
            }
            onTouchMove={isSpecialSession ? undefined : onTouchMove}
            onTouchEnd={isSpecialSession ? undefined : onTouchEnd}
            onContextMenu={
              isSpecialSession
                ? undefined
                : (e: React.MouseEvent) => {
                    e.preventDefault();
                    setContextMenu({
                      x: e.clientX,
                      y: e.clientY,
                      weekNumber: selectedWeek,
                      sessionIndex: originalIndex,
                      workoutId: session.workoutId,
                    });
                  }
            }
            style={isSpecialSession ? undefined : { touchAction: "none", WebkitUserSelect: "none", userSelect: "none" }}
            className={isSpecialSession ? undefined : "zn-plan-drag"}
            data-dragging={isDragging || undefined}
            data-session-index={originalIndex}
            data-drop-before={(isDropHere && dropTarget?.before === originalIndex) || undefined}
            data-drop-after={originalIndex === lastOfDay || undefined}
          >
            <div
              className="zn-sess"
              data-density="card"
              data-kind={isRaceDay ? "race" : isIntermediateRace ? "intermediate" : undefined}
              data-status={isSpecialSession ? undefined : session.status}
              data-unzoned={isSpecialSession || isZoned(session.sessionType) ? undefined : "true"}
              data-locked={session.locked || undefined}
            >
              {isRaceDay ? (
                <>
                  <Flag className="zn-sess__flag" />
                  <span className="zn-sess__race-label">{t("calendar.race")}</span>
                </>
              ) : isIntermediateRace ? (
                <>
                  <Flag className="zn-sess__flag" />
                  <span className="zn-sess__race-label">
                    {weekData?.intermediateRace?.raceDistance
                      ? pickLang(RACE_DISTANCE_META[weekData.intermediateRace.raceDistance], "label")
                      : t("intermediateGoals.raceDayLabel")}
                  </span>
                  {weekData?.intermediateRace?.priority && (
                    <span
                      className="zn-sess__priority"
                      data-priority={weekData.intermediateRace.priority}
                    >
                      {t(`intermediateGoals.badge.${weekData.intermediateRace.priority}`)}
                    </span>
                  )}
                </>
              ) : (
                <>
                  {/* Card actions, top-right. Hover-only on desktop; the lock
                      stays visible once set. Touch users reach them through the
                      long-press context menu. */}
                  <div className="zn-sess__actions">
                    {onRedraw && isRedrawable(session.workoutId) && !session.locked && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRedraw(selectedWeek, originalIndex);
                        }}
                        className="zn-sess__action"
                        title={t("library:weekly.slot.reroll")}
                        aria-label={t("library:weekly.slot.reroll")}
                      >
                        <Dices />
                      </button>
                    )}
                    {onSessionDuplicate && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSessionDuplicate(selectedWeek, originalIndex);
                        }}
                        className="zn-sess__action"
                        title={t("library:weekly.slot.duplicate")}
                        aria-label={t("library:weekly.slot.duplicate")}
                      >
                        <Copy />
                      </button>
                    )}
                    {onSessionDelete && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSessionDelete(selectedWeek, originalIndex);
                        }}
                        className="zn-sess__action"
                        data-variant="destructive"
                        title={t("calendar.deleteSession")}
                        aria-label={t("calendar.deleteSession")}
                      >
                        <Trash2 />
                      </button>
                    )}
                    {onToggleLock && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleLock(selectedWeek, originalIndex);
                        }}
                        aria-pressed={session.locked === true}
                        className="zn-sess__action"
                        title={
                          session.locked
                            ? t("library:weekly.slot.lockedHint")
                            : t("library:weekly.slot.lock")
                        }
                        aria-label={
                          session.locked
                            ? t("library:weekly.slot.unlock")
                            : t("library:weekly.slot.lock")
                        }
                      >
                        {session.locked ? <Lock /> : <LockOpen />}
                      </button>
                    )}
                  </div>
                  <div className="zn-sess__head">
                    {onToggleComplete && (
                      <button
                        type="button"
                        data-completion-key={`${selectedWeek}-${originalIndex}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleComplete(selectedWeek, originalIndex);
                        }}
                        className="zn-sess__check"
                        data-status={session.status}
                        title={
                          session.status === "completed"
                            ? t("completion.completed")
                            : session.status === "modified"
                              ? t("completion.modified")
                              : session.status === "skipped"
                                ? t("completion.skipped")
                                : t("completion.markDone")
                        }
                      >
                        {session.status === "completed" && (
                          <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M2 6l3 3 5-5" />
                          </svg>
                        )}
                        {session.status === "modified" && (
                          <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M9 2l1.5 1.5L5 9 2 9l0-3L7.5 0.5z" />
                          </svg>
                        )}
                        {session.status === "skipped" && (
                          <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M3 3l6 6M9 3l-6 6" />
                          </svg>
                        )}
                      </button>
                    )}
                    {/* The sport, named the way the library names it: the dot
                        says how hard, this says what. Left of the dot, so the
                        two read as one mark, "run, zone 2". */}
                    {discipline && DisciplineIcon && (
                      <span
                        role="img"
                        className="zn-sess__sport"
                        aria-label={t(`library:activityToggle.${discipline}`)}
                        title={t(`library:activityToggle.${discipline}`)}
                      >
                        <DisciplineIcon className="zn-sess__icon" />
                      </span>
                    )}
                    {!isStrength && (
                      <span
                        className="zn-sess__dot"
                        style={
                          isZoned(session.sessionType)
                            ? ({ "--zn-dot": sessionColor(session.sessionType) } as React.CSSProperties)
                            : undefined
                        }
                      />
                    )}
                    {/* The zone label is the dot's legend, the ink ramp orders
                        the zones, it does not name them. */}
                    {meta?.zone != null && (
                      <span
                        className="zn-sess__zone"
                        title={t("library:weekly.card.zone", { zone: meta.zone })}
                      >
                        Z{meta.zone}
                      </span>
                    )}
                    {session.isKeySession && (
                      <span className="zn-sess__key" title={t("view.keySession")}>
                        <Star filled />
                      </span>
                    )}
                  </div>
                  <span
                    role="button"
                    tabIndex={onSessionClick ? 0 : undefined}
                    onClick={
                      onSessionClick
                        ? () => onSessionClick(selectedWeek, originalIndex, session.workoutId)
                        : undefined
                    }
                    onKeyDown={
                      onSessionClick
                        ? (e) => {
                            if (e.key === "Enter")
                              onSessionClick(selectedWeek, originalIndex, session.workoutId);
                          }
                        : undefined
                    }
                    className="zn-sess__name"
                    data-clickable={onSessionClick ? "true" : undefined}
                    /* The single-week board has room for a third line. */
                    style={{ "--lines": singleWeek ? 3 : 2 } as React.CSSProperties}
                    title={sessionName}
                  >
                    {sessionName}
                  </span>
                  {/* The shape of the session, small, as the library's compact
                      card draws it. The name says which session, this says
                      what it asks: a 30/30 and a steady ride no longer wear
                      the same card. */}
                  {profile?.kind === "zones" && profile.blocks.length > 0 && (
                    <ZoneBar
                      condense
                      blocks={profile.blocks}
                      className="zn-profile-mini zn-sess__profile"
                      label={t("library:zoneBar.of", { name: sessionName })}
                    />
                  )}
                  {profile?.kind === "strength" && (
                    <IntensityMeter
                      intensity={profile.intensity}
                      className="zn-profile-mini zn-sess__profile"
                    />
                  )}
                  {/* An activity of the week board without a duration is a
                      card that weighs nothing yet: say so, where the duration
                      would be, rather than leave the line blank. */}
                  {isActivity &&
                    singleWeek &&
                    activityKindOf(session.workoutId)?.timed &&
                    session.estimatedDurationMin <= 0 && (
                    <span className="zn-sess__facts">
                      <Clock />
                      <span className="zn-sess__facts-text">
                        {t("activitySession.noDuration")}
                      </span>
                    </span>
                  )}
                  {session.estimatedDurationMin > 0 && (
                      <span className="zn-sess__facts">
                        <Clock />
                        <span className="zn-sess__facts-text">
                          {/* A loose session is "about" its middle: the tilde
                              says so, and the word says why. */}
                          {isLooseSession(session) && "~"}
                          {formatDurationMinutes(session.estimatedDurationMin)}
                          {session.targetDistanceKm != null && session.targetDistanceKm > 0 && (
                            <span className="zn-sess__fact-wide"> · {session.sessionType !== "long_run" && session.precision !== "fixed" && "~"}{session.targetDistanceKm}km</span>
                          )}
                          {singleWeek && !isActivity && session.precision && (
                            <span className="zn-sess__fact-wide"> · {t(`library:weekly.slot.${session.precision}`)}</span>
                          )}
                          {meta?.tss != null && meta.tss > 0 && (
                            <span className="zn-sess__fact-wide"> · {meta.tss} TSS</span>
                          )}
                          {session.rpe && (
                            <span className="zn-sess__fact-wide"> · RPE {session.rpe}</span>
                          )}
                        </span>
                      </span>
                    )}
                </>
              )}
            </div>
          </div>
        );
      })}

      {!scanContent && sessions.length > 0 && onAddToDay && !isBlockedDay && (
        <button
          type="button"
          onClick={() => onAddToDay(selectedWeek, dayIndex)}
          className="zn-planweek__add"
          data-slot="tail"
        >
          <span className="zn-planweek__add-plus">+</span>
        </button>
      )}
    </div>
  );
});
