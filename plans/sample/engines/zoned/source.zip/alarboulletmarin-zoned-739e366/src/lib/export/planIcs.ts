/**
 * Plan ICS Export - Calendar format
 *
 * Creates calendar events for every session across all weeks of a training plan.
 */

import { createEvents, type EventAttributes } from "ics";
import type { TrainingPlan } from "@/types/plan";
import type { AnyWorkoutTemplate } from "@/types";
import { getDominantZone } from "@/types";
import { isRunningWorkout, isStrengthWorkout } from "@/lib/workoutTemplate";
import { RACE_DISTANCE_META } from "@/types/plan";
import { DAY_LABELS } from "@/lib/planGenerator/constants";
import i18n from "@/i18n";
import { isEnglish, pickLang, pickLangArray } from "@/lib/i18n-utils";
import { activityKindOf, activitySessionZone } from "@/lib/activitySession";
import { triggerDownload } from "./download";
import { exportSessionName } from "./sessionName";
import { planFilename } from "./planFilename";

/**
 * Get the Monday of the week that contains the given date.
 * Monday = start of week (ISO convention).
 */
function getMondayOfWeek(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
  const diff = day === 0 ? -6 : 1 - day; // Shift to Monday
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

/**
 * Calculate the date for a specific session given plan start Monday,
 * week number (1-based), and day of week (0=Mon ... 6=Sun).
 */
function getSessionDate(planMonday: Date, weekNumber: number, dayOfWeek: number): Date {
  const d = new Date(planMonday);
  d.setDate(d.getDate() + (weekNumber - 1) * 7 + dayOfWeek);
  return d;
}

/**
 * Export a training plan as ICS calendar file.
 * Creates one event per training session across all weeks.
 * Uses each session's dayOfWeek directly for calendar placement.
 */
export function exportPlanToICS(
  plan: TrainingPlan,
  workoutNames: Record<string, string>,
  workoutTemplates: Record<string, AnyWorkoutTemplate>,
): void {
  try {
    const isEn = isEnglish();
    const t = (key: string, opts?: Record<string, unknown>) => i18n.t(`common:export.planIcs.${key}`, opts);
    const planMonday = getMondayOfWeek(new Date(plan.config.startDate || plan.config.createdAt));
    const dayLabels = isEn ? DAY_LABELS.en : DAY_LABELS.fr;

    const events: EventAttributes[] = [];

    for (const week of plan.weeks) {
      for (const session of week.sessions) {
        const sessionDate = getSessionDate(planMonday, week.weekNumber, session.dayOfWeek);
        const isRaceDay = session.workoutId === "__race_day__";

        const isIntermediateRace = session.workoutId === "__intermediate_race__";

        if (isRaceDay) {
          // Race day: all-day event
          const raceDistMeta = plan.config.raceDistance ? RACE_DISTANCE_META[plan.config.raceDistance] : null;
          const raceName = plan.config.raceName
            || (raceDistMeta ? pickLang(raceDistMeta, "label") : t("race"));

          events.push({
            start: [
              sessionDate.getFullYear(),
              sessionDate.getMonth() + 1,
              sessionDate.getDate(),
            ],
            end: [
              sessionDate.getFullYear(),
              sessionDate.getMonth() + 1,
              sessionDate.getDate(),
            ],
            title: `${t("raceDay")} - ${raceName}`,
            description: plan.raceTimePrediction
              ? `${t("targetTime")}: ${plan.raceTimePrediction}`
              : "",
            categories: ["Running", "Race"],
            status: "CONFIRMED" as const,
            transp: "TRANSPARENT" as const,
            productId: "zoned-app",
          });
        } else if (isIntermediateRace) {
          // Intermediate race: all-day event
          const ir = week.intermediateRace;
          const distMeta = ir?.raceDistance ? RACE_DISTANCE_META[ir.raceDistance] : null;
          const distLabel = distMeta ? pickLang(distMeta, "label") : ir?.raceDistance ?? "";
          const raceName = ir?.raceName || distLabel;
          const priorityLabel = ir?.priority
            ? i18n.t(`plan:intermediateGoals.badge.${ir.priority}`)
            : "";

          events.push({
            start: [
              sessionDate.getFullYear(),
              sessionDate.getMonth() + 1,
              sessionDate.getDate(),
            ],
            end: [
              sessionDate.getFullYear(),
              sessionDate.getMonth() + 1,
              sessionDate.getDate(),
            ],
            title: `${i18n.t("plan:intermediateGoals.raceDayLabel")} - ${raceName}`,
            description: [
              distLabel,
              priorityLabel,
            ].filter(Boolean).join(" · "),
            categories: ["Running", "Race"],
            status: "CONFIRMED" as const,
            transp: "TRANSPARENT" as const,
            productId: "zoned-app",
          });
        } else {
          // Regular training session: all-day event
          const workoutName = exportSessionName(session.workoutId, workoutNames);
          const activity = activityKindOf(session.workoutId);
          const dayLabel = dayLabels[session.dayOfWeek];
          const weekLabel = isEn
            ? (week.weekLabelEn || `W${week.weekNumber}`)
            : (week.weekLabel || `S${week.weekNumber}`);

          const descriptionLines: string[] = [];
          descriptionLines.push(`${t("week")}: ${weekLabel}`);
          descriptionLines.push(`${t("dayLabel")}: ${dayLabel}`);
          if (session.estimatedDurationMin > 0) {
            descriptionLines.push(`${t("durationLabel")}: ${session.estimatedDurationMin} min`);
          }
          if (session.isKeySession) {
            descriptionLines.push(t("keySession"));
          }
          const notes = pickLang(session, "notes");
          if (notes) {
            descriptionLines.push("");
            descriptionLines.push(notes);
          }

          const template = workoutTemplates[session.workoutId];
          const isStrength = template ? isStrengthWorkout(template) : false;
          // An activity has no template; its zone is the effort it was planned at.
          const activityZone = activity ? activitySessionZone(session) : null;
          const primaryZone = template && isRunningWorkout(template)
            ? `Z${getDominantZone(template)}`
            : activityZone !== null ? `Z${activityZone}` : "";
          const zoneTag = primaryZone ? ` [${primaryZone}]` : isStrength ? " [Renfo]" : "";

          if (template && isStrengthWorkout(template)) {
            const desc = pickLang(template, "description");
            descriptionLines.push("");
            descriptionLines.push(desc);

            // Coaching tips
            const tips = pickLangArray<string>(template, "coachingTips");
            if (tips?.length) {
              descriptionLines.push("");
              descriptionLines.push(`--- ${t("tips")} ---`);
              for (const tip of tips) {
                descriptionLines.push(`• ${tip}`);
              }
            }
          } else if (template && isRunningWorkout(template)) {
            const running = template;
            const desc = pickLang(running, "description");
            descriptionLines.push("");
            descriptionLines.push(desc);

            // Warmup
            if (running.warmupTemplate?.length) {
              descriptionLines.push("");
              descriptionLines.push(t("warmupSep"));
              for (const block of running.warmupTemplate) {
                const blockDesc = pickLang(block, "description");
                const dur = block.durationMin ? ` (${block.durationMin}min)` : "";
                const zone = block.zone ? ` [${block.zone}]` : "";
                descriptionLines.push(`• ${blockDesc}${dur}${zone}`);
              }
            }

            // Main set
            if (running.mainSetTemplate?.length) {
              descriptionLines.push("");
              descriptionLines.push(t("mainSetSep"));
              for (const block of running.mainSetTemplate) {
                const blockDesc = pickLang(block, "description");
                const dur = block.durationMin ? ` (${block.durationMin}min)` : "";
                const zone = block.zone ? ` [${block.zone}]` : "";
                const reps = block.repetitions && block.repetitions > 1 ? `${block.repetitions}x ` : "";
                const rest = block.rest || block.recovery;
                const restStr = rest ? `, ${t("rest")}: ${rest}` : "";
                descriptionLines.push(`• ${reps}${blockDesc}${dur}${zone}${restStr}`);
              }
            }

            // Cooldown
            if (running.cooldownTemplate?.length) {
              descriptionLines.push("");
              descriptionLines.push(t("cooldownSep"));
              for (const block of running.cooldownTemplate) {
                const blockDesc = pickLang(block, "description");
                const dur = block.durationMin ? ` (${block.durationMin}min)` : "";
                const zone = block.zone ? ` [${block.zone}]` : "";
                descriptionLines.push(`• ${blockDesc}${dur}${zone}`);
              }
            }

            // Coaching tips
            const tips = pickLangArray<string>(running, "coachingTips");
            if (tips?.length) {
              descriptionLines.push("");
              descriptionLines.push(`--- ${t("tips")} ---`);
              for (const tip of tips) {
                descriptionLines.push(`• ${tip}`);
              }
            }
          }

          events.push({
            start: [
              sessionDate.getFullYear(),
              sessionDate.getMonth() + 1,
              sessionDate.getDate(),
            ],
            end: [
              sessionDate.getFullYear(),
              sessionDate.getMonth() + 1,
              sessionDate.getDate(),
            ],
            // A rest day has no duration to announce: "Repos actif", not "- 0min".
            title: session.estimatedDurationMin > 0
              ? `${workoutName} - ${session.estimatedDurationMin}min${zoneTag}`
              : `${workoutName}${zoneTag}`,
            description: descriptionLines.join("\n"),
            categories: [
              isStrength ? "Strength"
                : session.discipline === "cycling" ? "Cycling"
                : session.discipline === "swimming" ? "Swimming"
                : "Running",
              "Workout",
              session.sessionType,
            ],
            status: "CONFIRMED" as const,
            transp: "TRANSPARENT" as const,
            productId: "zoned-app",
          });
        }
      }
    }

    if (events.length === 0) return;

    const { error, value } = createEvents(events);

    if (error || !value) {
      throw new Error(error?.message || "Failed to create ICS events");
    }

    triggerDownload(
      new Blob([value], { type: "text/calendar;charset=utf-8" }),
      planFilename(plan, "ics"),
    );
  } catch (error) {
    console.error("Export failed:", error);
    throw error;
  }
}
