import { useState, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { Download, Calendar, FileText, Loader2 } from "@/components/icons";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { exportPlanToICS, exportPlanToPDF } from "@/lib/export";
import { exportWeekToPDF } from "@/lib/export/weekPdf";
import { triggerDownload } from "@/lib/export/download";
import { planFilename } from "@/lib/export/planFilename";
import { getWorkoutById } from "@/data/workouts";
import { preparePlanForStorage } from "@/lib/planSchema";
import { toast } from "@/components/ui/toast";
import type { TrainingPlan } from "@/types/plan";
import type { AnyWorkoutTemplate } from "@/types";
import { pickLang } from "@/lib/i18n-utils";

interface PlanExportMenuProps {
  plan: TrainingPlan;
  /** Pre-loaded workout names (optional, loaded on demand if absent) */
  workoutNames?: Record<string, string>;
  /** Pre-loaded workout templates (optional, loaded on demand if absent) */
  workoutTemplates?: Record<string, AnyWorkoutTemplate>;
  size?: "sm" | "default";
  /** Visual weight. Use "outline" where another filled CTA already leads. */
  variant?: "default" | "outline";
}

/**
 * Collects all unique workout IDs from a plan and resolves names + templates.
 */
async function resolvePlanWorkouts(plan: TrainingPlan) {
  const names: Record<string, string> = {};
  const templates: Record<string, AnyWorkoutTemplate> = {};

  const ids = new Set<string>();
  for (const week of plan.weeks) {
    for (const session of week.sessions) {
      if (session.workoutId && !session.workoutId.startsWith("__")) {
        ids.add(session.workoutId);
      }
    }
  }

  for (const id of ids) {
    const w = await getWorkoutById(id);
    if (w) {
      names[id] = pickLang(w, "name");
      templates[id] = w;
    }
  }

  return { names, templates };
}

export function PlanExportMenu({
  plan,
  workoutNames: preloadedNames,
  workoutTemplates: preloadedTemplates,
  size = "default",
  variant = "default",
}: PlanExportMenuProps) {
  const { t } = useTranslation("common");
  const [isExporting, setIsExporting] = useState(false);

  const getWorkoutData = useCallback(async () => {
    if (preloadedNames && preloadedTemplates && Object.keys(preloadedNames).length > 0) {
      return { names: preloadedNames, templates: preloadedTemplates };
    }
    // The names the page hands over win: they name the activities too (a
    // bike commute, a swim), which no catalogue lookup can, and which the
    // exports printed by their internal id without them.
    const resolved = await resolvePlanWorkouts(plan);
    return { names: { ...resolved.names, ...preloadedNames }, templates: resolved.templates };
  }, [plan, preloadedNames, preloadedTemplates]);

  const handleExportPDF = useCallback(async () => {
    if (isExporting) return;
    setIsExporting(true);
    const toastId = toast.loading(t("export.loading.pdf", t("export.title")));
    try {
      const { names, templates } = await getWorkoutData();
      // A standalone week has its own sheet; the plan's document is drawn
      // for a programme of many weeks.
      if (plan.config.isSingleWeek) await exportWeekToPDF(plan, names, templates);
      else await exportPlanToPDF(plan, names, templates);
      toast.success(t("export.success.pdf"), { id: toastId });
    } catch (error) {
      toast.failure(t("export.error.pdf"), error, { id: toastId });
    } finally {
      setIsExporting(false);
    }
  }, [plan, isExporting, getWorkoutData, t]);

  const handleExportICS = useCallback(async () => {
    setIsExporting(true);
    const toastId = toast.loading(t("export.loading.calendar", t("export.title")));
    try {
      const { names, templates } = await getWorkoutData();
      exportPlanToICS(plan, names, templates);
      toast.success(t("export.success.calendar"), { id: toastId });
    } catch (error) {
      toast.failure(t("export.error.calendar"), error, { id: toastId });
    } finally {
      setIsExporting(false);
    }
  }, [plan, getWorkoutData, t]);

  const handleExportJSON = useCallback(() => {
    const json = JSON.stringify(preparePlanForStorage(plan), null, 2);
    const blob = new Blob([json], { type: "application/json" });
    triggerDownload(blob, planFilename(plan, "json"));
    toast.success(t("plans.planExported"));
  }, [plan, t]);

  const isSmall = size === "sm";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant={variant}
          size={isSmall ? "sm" : "default"}
          disabled={isExporting}
        >
          {isExporting ? <Loader2 className="zn-spin" /> : <Download />}
          <span>{t("export.title")}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handleExportPDF}>
          <FileText />
          {t("export.pdf")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleExportICS}>
          <Calendar />
          {t("export.calendar")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleExportJSON}>
          <Download />
          {t("export.json")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
