export { SEOHead } from "./SEOHead";
