/**
 * Workout Export Module
 *
 * Exports workouts to various formats:
 * - ICS (Calendar)
 * - PNG (Image)
 * - PDF (Document)
 * - FIT (Garmin)
 *
 * Training Plan exports:
 * - Plan ICS (Calendar for full plan)
 * - Plan PDF (Document for full plan)
 */

export { exportToICS } from "./ics";
export { exportToPNG } from "./png";
export { exportToPDF } from "./pdf";
export { exportToFIT } from "./fit";
export { exportPlanToICS } from "./planIcs";
export { exportPlanToPDF } from "./planPdf";

// Social share pipeline (download / copy / Web Share API).
export {
  downloadImage,
  copyImage,
  shareImage,
  isCopySupported,
  type ShareMethod,
} from "./share";
export { getWorkoutHero, type WorkoutHero } from "./workoutHero";

// Strava share text (copy-to-clipboard for activity descriptions).
export { buildStravaShareText } from "./strava";
