import { useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "@/components/ui/toast";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { WorkoutTemplate } from "@/types";
import { usePickLang } from "@/lib/i18n-utils";

function getOS(): "windows" | "macos" | "linux" | "other" {
  const ua = navigator.userAgent.toLowerCase();
  if (ua.includes("cros")) return "other";
  if (ua.includes("mac")) return "macos";
  if (ua.includes("win")) return "windows";
  if (ua.includes("linux")) return "linux";
  return "other";
}

interface FitTransferGuideProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  workout: WorkoutTemplate;
}

export function FitTransferGuide({ open, onOpenChange, workout }: FitTransferGuideProps) {
  const { t } = useTranslation("common");
  const pickLang = usePickLang();
  const [showOtherBrands, setShowOtherBrands] = useState(false);
  const os = getOS();
  const filename = `${workout.id}.fit`;

  const osPath = t(`fitTransfer.osPath.${os}`);

  const steps = [
    t("fitTransfer.step1"),
    t("fitTransfer.step2OsPath", { path: osPath }),
    t("fitTransfer.step3"),
    t("fitTransfer.step4", { filename }),
    t("fitTransfer.step5"),
  ];

  function formatWorkoutAsText(): string {
    const lines: string[] = [];
    const name = pickLang(workout, "name");
    lines.push(name);
    lines.push("");

    const sections = [
      { label: t("fitTransfer.warmup"), blocks: workout.warmupTemplate },
      { label: t("fitTransfer.mainSet"), blocks: workout.mainSetTemplate },
      { label: t("fitTransfer.cooldown"), blocks: workout.cooldownTemplate },
    ];

    for (const section of sections) {
      if (!section.blocks?.length) continue;
      lines.push(`${section.label} :`);
      for (const block of section.blocks) {
        const desc = pickLang(block, "description");
        const rep = block.repetitions ? `${block.repetitions}x ` : "";
        lines.push(`  ${rep}${desc} (${block.durationMin}min, ${block.zone})`);
      }
      lines.push("");
    }

    return lines.join("\n");
  }

  async function copyInstructions() {
    try {
      await navigator.clipboard.writeText(formatWorkoutAsText());
      toast.success(t("fitTransfer.instructionsCopied"));
    } catch (err) {
      toast.failure(t("fitTransfer.copyFailed"), err);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="zn-fit-guide">
        <DialogHeader>
          <DialogTitle>
            {t("fitTransfer.workoutDownloaded")}
          </DialogTitle>
          <DialogDescription>
            {t("fitTransfer.fileDownloaded", { filename })}
          </DialogDescription>
        </DialogHeader>

        <ol
          className="zn-stack zn-steps"
          style={{ "--gap": "var(--sp-6)" } as React.CSSProperties}
        >
          {steps.map((step, i) => (
            <li
              key={i}
              className="zn-row zn-row--start"
              style={{ "--gap": "var(--sp-6)" } as React.CSSProperties}
            >
              <span aria-hidden="true" className="zn-steps__num">
                {i + 1}
              </span>
              <span className="zn-body zn-body--sm zn-muted">{step}</span>
            </li>
          ))}
        </ol>

        <p className="zn-caption zn-faint">{t("fitTransfer.compatible")}</p>

        {/* Other brands toggle */}
        <Button
          variant="link"
          size="sm"
          aria-expanded={showOtherBrands}
          onClick={() => setShowOtherBrands(!showOtherBrands)}
        >
          {t("fitTransfer.noGarmin")}
        </Button>

        {showOtherBrands && (
          <div
            className="zn-stack zn-fit-brands"
            style={{ "--gap": "var(--sp-6)" } as React.CSSProperties}
          >
            <p className="zn-body zn-body--sm zn-muted">
              {t("fitTransfer.fitGarminOnly")}
            </p>
            <Button variant="outline" size="sm" onClick={copyInstructions}>
              {t("fitTransfer.copyInstructions")}
            </Button>
            <ul
              className="zn-stack zn-fit-brands__list"
              style={{ "--gap": "var(--sp-3)" } as React.CSSProperties}
            >
              <li className="zn-source">Polar : Polar Flow → {t("domain.fitTransfer.polarPath")}</li>
              <li className="zn-source">Suunto : Suunto App → {t("domain.fitTransfer.suuntoPath")}</li>
              <li className="zn-source">COROS : COROS App → Workout → {t("domain.fitTransfer.corosPath")}</li>
              <li className="zn-source">Apple Watch : {t("domain.fitTransfer.applePath")}</li>
            </ul>
          </div>
        )}

        <DialogFooter>
          <Button onClick={() => onOpenChange(false)}>
            {t("fitTransfer.gotIt")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
